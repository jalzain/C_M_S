#!/usr/bin/env python3
"""Run the regression / uncertainty / ablation / curve experiments.  Resumable: finished tasks are cached in
results/csv/raw/ and skipped on re-run.

    python scripts/run_all_experiments.py [--stages main protocol restarts learning ablation curves scaling screen]
                                          [--jobs 2] [--config config/experiment_config.yaml] [--quick]
Bayesian-optimisation experiments live in scripts/run_bo_experiments.py (called by scripts/run_everything.sh).
"""
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(v, "1")
import argparse, sys, time, warnings
from pathlib import Path
import numpy as np, pandas as pd, yaml
from joblib import Parallel, delayed

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
from evaluation import run_cv, holdout_split, regression_metrics, make_splits
from registry import get_dataset, regression_models, ablation_models, curve_models
from improved_models import ImprovedGP, timed_fit
from baseline_models import BaselineGP
from data_preprocessing import build_features

RAW = Path(os.environ.get("LMR_RAW", ROOT / "results" / "csv" / "raw"))   # env var so joblib workers agree
RAW.mkdir(parents=True, exist_ok=True)


def cached(path, fn):
    if path.exists():
        return
    out = fn()
    for k, df in out.items():
        df.to_csv(str(path).replace(".csv", f"__{k}.csv"), index=False)
    path.write_text("done\n")


# ------------------------------------------------------------------ generic CV task
def cv_task(tag, dataset, model_name, factory, scheme, n_splits, n_repeats, seed):
    path = RAW / f"{tag}__{dataset}__{model_name.replace(' ', '_').replace('/', '-')}__{scheme}.csv"

    def fn():
        warnings.filterwarnings("ignore")
        ds = get_dataset(dataset)
        P, F = run_cv(ds, factory, scheme, n_splits, n_repeats, seed, model_name=model_name)
        for d in (P, F):
            d.insert(0, "dataset", dataset)
        return {"pred": P, "folds": F}
    cached(path, fn)


def stage_main(cfg, jobs):
    c = cfg["regression"]
    tasks = []
    for d in c["datasets"]:
        for name, fac in regression_models(d, cfg["improved_restarts"], cfg["baseline_restarts"]).items():
            tasks.append(("main", d, name, fac, "grouped_canonical", c["n_splits"], c["n_repeats"], c["seed"]))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(cv_task)(*t) for t in tasks)


def stage_protocol(cfg, jobs):
    c = cfg["regression"]
    keep = ["GP-original", "GP-comp-ARD-M15", "ET-comp", "Mean-predictor"]
    tasks = []
    for d in c["datasets"]:
        ms = regression_models(d, cfg["improved_restarts"], cfg["baseline_restarts"])
        for sch in ("random", "grouped_composition"):
            for name in keep:
                tasks.append(("protocol", d, name, ms[name], sch, c["n_splits"], c["protocol_repeats"], c["seed"] + 1))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(cv_task)(*t) for t in tasks)


def stage_restarts(cfg, jobs):
    c = cfg["regression"]
    tasks = []
    for d in c["datasets"]:
        clip = 0.0 if d == "band_gap" else None
        for r in cfg["restart_study"]["baseline"]:
            tasks.append(("restarts", d, f"GP-original|restarts={r}", (lambda r=r: BaselineGP("maxval", n_restarts=r)),
                          "grouped_canonical", c["n_splits"], c["restart_repeats"], c["seed"] + 2))
        for r in cfg["restart_study"]["improved"]:
            tasks.append(("restarts", d, f"GP-comp-ARD-M15|restarts={r}",
                          (lambda r=r, clip=clip: ImprovedGP("matern15_ard", "composition", "none", clip_min=clip, n_restarts=r)),
                          "grouped_canonical", c["n_splits"], c["restart_repeats"], c["seed"] + 2))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(cv_task)(*t) for t in tasks)


def stage_ablation(cfg, jobs):
    c = cfg["regression"]
    tasks = []
    for d in c["datasets"]:
        for name, fac in ablation_models(d, cfg["improved_restarts"], cfg["baseline_restarts"]).items():
            tasks.append(("ablation", d, name, fac, "grouped_canonical", c["n_splits"], c["ablation_repeats"], c["seed"] + 3))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(cv_task)(*t) for t in tasks)


# ------------------------------------------------------------------ learning curves
def learning_task(dataset, model_name, factory, fractions, reps, seed):
    path = RAW / f"learning__{dataset}__{model_name}.csv"

    def fn():
        warnings.filterwarnings("ignore")
        ds = get_dataset(dataset)
        rows = []
        for frac in fractions:
            for rep in range(reps):
                tr, te = holdout_split(ds, "grouped_canonical", frac, seed * 1000 + rep)
                if len(tr) < 5 or len(te) < 5:
                    continue
                m = factory()
                t0 = time.perf_counter()
                m.fit(ds.frame.iloc[tr].reset_index(drop=True), ds.y[tr])
                tf = time.perf_counter() - t0
                mu, sd = m.predict(ds.frame.iloc[te].reset_index(drop=True), return_std=True)
                met = regression_metrics(ds.y[te], mu, sd, prob=getattr(m, "calibrated_uncertainty", True))
                met.update(dataset=dataset, model=model_name, train_fraction=frac, rep=rep, n_train=len(tr),
                           n_test=len(te), fit_time_s=tf)
                rows.append(met)
        return {"learning": pd.DataFrame(rows)}
    cached(path, fn)


def stage_learning(cfg, jobs):
    L = cfg["learning"]
    tasks = []
    for d in cfg["regression"]["datasets"]:
        ms = regression_models(d, cfg["improved_restarts"], cfg["baseline_restarts"])
        for name in L["models"]:
            tasks.append((d, name, ms[name], L["fractions"], L["reps"], cfg["regression"]["seed"] + 4))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(learning_task)(*t) for t in tasks)


# ------------------------------------------------------------------ band-structure curves
def gap_from_curves(Y):
    return np.maximum(0.0, Y[:, :30].min(1) - Y[:, 30:].max(1))


def curve_task(name, factory, n_splits, n_repeats, seed):
    path = RAW / f"curves__{name}.csv"

    def fn():
        warnings.filterwarnings("ignore")
        ds = get_dataset("band_structure")
        Y = ds.y
        frames, pw, preds, P = [], [], [], []
        for rep in range(n_repeats):
            for fold, (tr, te) in enumerate(make_splits(ds, "grouped_canonical", n_splits, rep, seed)):
                m = factory()
                t0 = time.perf_counter()
                m.fit(ds.frame.iloc[tr].reset_index(drop=True), Y[tr])
                tf = time.perf_counter() - t0
                Yp = m.predict(ds.frame.iloc[te].reset_index(drop=True))
                E = Yp - Y[te]
                gp_, gt_ = gap_from_curves(Yp), gap_from_curves(Y[te])
                frames.append(dict(model=name, repeat=rep, fold=fold, n_train=len(tr), n_test=len(te),
                                   RMSE=np.sqrt((E ** 2).mean()), MAE=np.abs(E).mean(),
                                   RMSE_CBM=np.sqrt((E[:, :30] ** 2).mean()), RMSE_VBM=np.sqrt((E[:, 30:] ** 2).mean()),
                                   gap_MAE=np.abs(gp_ - gt_).mean(), gap_RMSE=np.sqrt(((gp_ - gt_) ** 2).mean()),
                                   gap_R2=1 - ((gp_ - gt_) ** 2).sum() / max(((gt_ - gt_.mean()) ** 2).sum(), 1e-12),
                                   R2=1 - (E ** 2).sum() / ((Y[te] - Y[te].mean(0)) ** 2).sum(),
                                   fit_time_s=tf))
                for j in range(60):
                    pw.append(dict(model=name, repeat=rep, fold=fold, point=j, sq_err=(E[:, j] ** 2).mean()))
                if rep == 0:
                    for k, i in enumerate(te):
                        for j in range(60):
                            P.append((name, ds.frame["structure"].values[i], "CBM" if j < 30 else "VBM", j % 30,
                                      Y[i, j], Yp[k, j]))
        return {"folds": pd.DataFrame(frames), "pointwise": pd.DataFrame(pw),
                "pred": pd.DataFrame(P, columns=["model", "structure", "branch", "k_index", "y_true_eV", "y_pred_eV"])}
    cached(path, fn)


def stage_curves(cfg, jobs):
    c = cfg["curves"]
    tasks = [(n, f, c["n_splits"], c["n_repeats"], cfg["regression"]["seed"] + 5)
             for n, f in curve_models(c["restarts"]).items()]
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(curve_task)(*t) for t in tasks)


# ------------------------------------------------------------------ scalability
def stage_scaling(cfg, jobs):
    path = RAW / "scaling.csv"
    if path.exists():
        return
    rows = []
    ds = get_dataset("band_gap")
    rs = np.random.RandomState(0)
    perm = rs.permutation(len(ds.frame))
    ms = regression_models("band_gap", cfg["improved_restarts"], cfg["baseline_restarts"])
    for n in cfg["scaling"]["sizes"]:
        idx = perm[:n]
        for name in cfg["scaling"]["models"]:
            for rep in range(cfg["scaling"]["reps"]):
                m = ms[name]()
                t0 = time.perf_counter()
                m.fit(ds.frame.iloc[idx].reset_index(drop=True), ds.y[idx])
                tf = time.perf_counter() - t0
                t0 = time.perf_counter()
                m.predict(ds.frame.iloc[perm[-30:]].reset_index(drop=True))
                rows.append(dict(model=name, n_train=n, rep=rep, fit_time_s=tf, predict_time_s=time.perf_counter() - t0))
    pd.DataFrame(rows).to_csv(path, index=False)


# ------------------------------------------------------------------ screening predictions (model-generated)
def stage_screen(cfg, jobs):
    from data_preprocessing import load_dataset
    import itertools
    path = RAW / "screening_predictions.csv"
    if path.exists():
        return
    M, X = ("Mo", "W"), ("S", "Se", "Te")
    layers = [f"{m}{x}" for m in M for x in X]
    canon = sorted({min("-".join(c), "-".join(c[::-1])) for c in itertools.product(layers, repeat=3)})
    rows = []
    for c in canon:
        parts = c.split("-")
        rec = {}
        for i, p in enumerate(parts):
            m = "Mo" if p.startswith("Mo") else "W"
            rec[f"M{i+1}"], rec[f"X{i+1}"] = m, p[len(m):]
        rec["structure"] = c
        rows.append(rec)
    design = pd.DataFrame(rows)
    out = design[["structure"]].copy()
    for d in ("eff_p", "eff_n", "band_gap"):
        ds = get_dataset(d)
        can = ds.frame["canonical"].values
        known = dict(zip(can, ds.y))   # twins (band gap): last wins; irrelevant for membership flag
        m = ImprovedGP("matern15_ard", "composition", "none", clip_min=0.0 if d == "band_gap" else None,
                       n_restarts=cfg["improved_restarts"]).fit(ds.frame, ds.y)
        mu, sd = m.predict(design, return_std=True)
        out[f"{d}_pred"], out[f"{d}_sigma"] = mu, sd
        out[f"{d}_in_dataset"] = design["structure"].isin(set(can))
        out[f"{d}_reference"] = [known.get(s, np.nan) for s in design["structure"]]
    out.to_csv(path, index=False)


STAGES = dict(main=stage_main, protocol=stage_protocol, restarts=stage_restarts, learning=stage_learning,
              ablation=stage_ablation, curves=stage_curves, scaling=stage_scaling, screen=stage_screen)


def consolidate():
    """Merge cached per-task files into tidy tables under results/csv/."""
    out = ROOT / "results" / "csv"
    for tag in ("main", "protocol", "restarts", "ablation"):
        for kind in ("pred", "folds"):
            fs = sorted(RAW.glob(f"{tag}__*__{kind}.csv"))
            if fs:
                pd.concat([pd.read_csv(f) for f in fs], ignore_index=True).to_csv(out / f"regression_{tag}_{kind}.csv", index=False)
    fs = sorted(RAW.glob("learning__*__learning.csv"))
    if fs:
        pd.concat([pd.read_csv(f) for f in fs], ignore_index=True).to_csv(out / "learning_curves.csv", index=False)
    for kind, nm in (("folds", "curves_folds"), ("pointwise", "curves_pointwise_mse"), ("pred", "curves_oof_predictions")):
        fs = sorted(RAW.glob(f"curves__*__{kind}.csv"))
        if fs:
            pd.concat([pd.read_csv(f) for f in fs], ignore_index=True).to_csv(out / f"{nm}.csv", index=False)
    for nm in ("scaling", "screening_predictions"):
        if (RAW / f"{nm}.csv").exists():
            pd.read_csv(RAW / f"{nm}.csv").to_csv(out / f"{nm}.csv", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", nargs="+", default=list(STAGES))
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--config", default=str(ROOT / "config" / "experiment_config.yaml"))
    ap.add_argument("--quick", action="store_true", help="tiny smoke-test configuration")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    if a.quick:
        cfg["regression"].update(n_repeats=1, protocol_repeats=1, restart_repeats=1, ablation_repeats=1, datasets=["eff_p"])
        cfg["learning"].update(fractions=[0.3, 0.6], reps=2, models=["GP-comp-ARD-M15", "ET-comp"])
        cfg["curves"].update(n_repeats=1)
        cfg["scaling"].update(sizes=[20, 40], reps=1, models=["GP-comp-ARD-M15"])
        cfg["restart_study"] = dict(baseline=[0], improved=[0])
        if "LMR_RAW" not in os.environ:
            sys.exit("--quick needs LMR_RAW=<scratch dir> so that smoke-test outputs never mix with real results")
    for s in a.stages:
        t0 = time.time()
        print(f"=== stage {s}", flush=True)
        STAGES[s](cfg, a.jobs)
        print(f"=== stage {s} done in {time.time()-t0:.0f}s", flush=True)
    if not a.quick:
        consolidate()


if __name__ == "__main__":
    main()
