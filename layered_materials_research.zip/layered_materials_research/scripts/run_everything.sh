#!/usr/bin/env bash
# Full pipeline: original-baseline runs -> regression/curve experiments -> BO experiments -> tables -> figures -> manuscript.
# All stages are resumable (cached per task in results/csv/raw*).
# Usage: bash scripts/run_everything.sh [JOBS] [quick]
#   quick: tiny smoke test; caches go to a scratch directory and the real results are NOT touched.
set -euo pipefail
cd "$(dirname "$0")/.."
JOBS=${1:-2}
MODE=${2:-full}
export PYTHONWARNINGS=ignore
if [ "$MODE" = "quick" ]; then
  SCRATCH=$(mktemp -d)
  export LMR_RAW="$SCRATCH/raw" LMR_RAW_BO="$SCRATCH/raw_bo"
  python -W ignore scripts/run_all_experiments.py --jobs "$JOBS" --quick
  python -W ignore scripts/run_bo_experiments.py --jobs "$JOBS" --quick
  echo "quick smoke test finished (scratch: $SCRATCH)"; exit 0
fi
python -W ignore scripts/run_original_baseline.py --seeds 0 1 2
python -W ignore scripts/run_all_experiments.py --jobs "$JOBS"
python -W ignore scripts/run_bo_experiments.py --jobs "$JOBS"
python -W ignore scripts/run_extension_experiments.py --jobs "$JOBS"
python -W ignore scripts/analyze_results.py
python -W ignore scripts/extra_analysis.py
python -W ignore scripts/analyze_extensions.py
python -W ignore scripts/make_figures.py
python -W ignore scripts/make_figures_extra.py
cp results/tables/*.tex manuscript/tables/
# the Elsevier manuscript places floats in the text flow
sed -i -E 's/\\begin\{table\}\[[a-zA-Z!]*\]/\\begin{table}[H]/' manuscript/tables/*.tex
if command -v latexmk >/dev/null; then (cd manuscript && latexmk -pdf -interaction=nonstopmode main_elsarticle.tex); fi
