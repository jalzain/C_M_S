#!/usr/bin/env python3
"""Extension experiments: additive/censored/two-task GPs, conformal intervals and nested model selection.

    python scripts/run_extension_experiments.py [--stages cv conformal nested] [--jobs 2] [--quick]
Results are cached per task in results/csv/ext/ (resumable).
"""
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(v, "1")
import argparse, sys, warnings
from pathlib import Path
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
from evaluation import make_splits, regression_metrics
from registry import get_dataset, regression_models
from extension_models import AdditiveGP, CensoredGP, TwoTaskGP, ConformalWrapper

EXT = ROOT / "results" / "csv" / "ext"
EXT.mkdir(parents=True, exist_ok=True)
DATASETS = ["band_gap", "eff_p", "eff_n"]
SCHEMES = {"grouped_canonical": dict(seed=0, repeats=5), "grouped_composition": dict(seed=1, repeats=3)}


def ext_models(dataset):
    clip = 0.0 if dataset == "band_gap" else None
    m = {"GP-additive": lambda: AdditiveGP(clip_min=clip)}
    if dataset == "band_gap":
        m["GP-censored"] = lambda: CensoredGP()
    else:   # the band gap is used as auxiliary property, so it cannot be the target here
        for s in ("none", "train", "all"):
            m[f"GP-2task-{s}"] = (lambda s=s: TwoTaskGP(s))
    return m


def cv_task(dataset, name, factory, scheme, quick):
    out = EXT / f"cv__{dataset}__{name}__{scheme}.csv"
    if out.exists():
        return
    cfg = SCHEMES[scheme]
    ds = get_dataset(dataset)
    rows, preds = [], []
    for rep in range(1 if quick else cfg["repeats"]):
        for fold, (tr, te) in enumerate(make_splits(ds, scheme, 5, rep, cfg["seed"])):
            m = factory().fit(ds.frame.iloc[tr].reset_index(drop=True), ds.y[tr])
            mu, sd = m.predict(ds.frame.iloc[te].reset_index(drop=True), return_std=True)
            r = regression_metrics(ds.y[te], mu, sd); r.update(dataset=dataset, model=name, scheme=scheme, repeat=rep, fold=fold)
            rows.append(r)
            preds.append(pd.DataFrame(dict(dataset=dataset, model=name, scheme=scheme, structure=ds.frame["structure"].values[te],
                                           repeat=rep, fold=fold, y_true=ds.y[te], y_pred=mu, y_sigma=sd)))
    pd.concat(preds).to_csv(str(out).replace(".csv", "__pred.csv"), index=False)
    pd.DataFrame(rows).to_csv(out, index=False)


def stage_cv(jobs, quick):
    tasks = [(d, n, f, s, quick) for d in DATASETS for n, f in ext_models(d).items() for s in SCHEMES]
    Parallel(n_jobs=jobs, verbose=5)(delayed(cv_task)(*t) for t in tasks)


# ------------------------------------------------------------------ conformal
def conformal_task(dataset, name, scheme, quick):
    out = EXT / f"conformal__{dataset}__{name}__{scheme}.csv"
    if out.exists():
        return
    cfg = SCHEMES[scheme]
    ds = get_dataset(dataset)
    fac = regression_models(dataset)[name]
    rows = []
    for rep in range(1 if quick else 2):
        for fold, (tr, te) in enumerate(make_splits(ds, scheme, 5, rep, cfg["seed"])):
            ftr, fte = ds.frame.iloc[tr].reset_index(drop=True), ds.frame.iloc[te].reset_index(drop=True)
            for norm_ in (True, False):
                cw = ConformalWrapper(fac, normalised=norm_).fit(ftr, ds.y[tr])
                mu = cw.predict(fte)
                for alpha in (0.05, 0.32):
                    hw = cw.half_width(fte, alpha)
                    rows.append(dict(dataset=dataset, model=name, scheme=scheme, repeat=rep, fold=fold, method="conformal-normalised" if norm_ else "conformal-absolute",
                                     alpha=alpha, coverage=np.mean(np.abs(ds.y[te] - mu) <= hw), mean_halfwidth=float(np.mean(hw)), n_test=len(te)))
            _, sd = cw.predict(fte, return_std=True)
            for alpha, zc in ((0.05, 1.959964), (0.32, 1.0)):
                hw = zc * sd
                rows.append(dict(dataset=dataset, model=name, scheme=scheme, repeat=rep, fold=fold, method="gaussian", alpha=alpha,
                                 coverage=np.mean(np.abs(ds.y[te] - mu) <= hw), mean_halfwidth=float(np.mean(hw)), n_test=len(te)))
    pd.DataFrame(rows).to_csv(out, index=False)


def stage_conformal(jobs, quick):
    tasks = [(d, n, s, quick) for d in DATASETS for n in ("GP-original", "GP-comp-ARD-M15") for s in SCHEMES]
    Parallel(n_jobs=jobs, verbose=5)(delayed(conformal_task)(*t) for t in tasks)


# ------------------------------------------------------------------ nested selection
def candidates(dataset):
    ms = regression_models(dataset, restarts=1)
    clip = 0.0 if dataset == "band_gap" else None
    c = {k: ms[k] for k in ("GP-original", "GP-comp-ARD-M15", "GP-comp-iso-M25", "ET-comp", "Ridge-comp")}
    c["GP-additive"] = lambda: AdditiveGP(n_restarts=1, clip_min=clip)
    return c


def nested_task(dataset, quick):
    out = EXT / f"nested__{dataset}.csv"
    if out.exists():
        return
    ds = get_dataset(dataset)
    cands = candidates(dataset)
    rows = []
    for rep in range(1 if quick else 2):
        for fold, (tr, te) in enumerate(make_splits(ds, "grouped_canonical", 5, rep, 7)):
            ftr, fte = ds.frame.iloc[tr].reset_index(drop=True), ds.frame.iloc[te].reset_index(drop=True)
            ytr, yte = ds.y[tr], ds.y[te]
            g = ftr["canonical"].astype("category").cat.codes.values
            inner = {k: [] for k in cands}
            for itr, ite in GroupKFold(4).split(ftr, groups=g):
                for k, fac in cands.items():
                    mm = fac().fit(ftr.iloc[itr].reset_index(drop=True), ytr[itr])
                    p = mm.predict(ftr.iloc[ite].reset_index(drop=True))
                    inner[k].append(np.abs(p - ytr[ite]))
            inner_mae = {k: np.mean(np.concatenate(v)) for k, v in inner.items()}
            chosen = min(inner_mae, key=inner_mae.get)
            for k, fac in cands.items():
                p = fac().fit(ftr, ytr).predict(fte)
                rows.append(dict(dataset=dataset, repeat=rep, fold=fold, candidate=k, outer_MAE=np.mean(np.abs(p - yte)),
                                 inner_MAE=inner_mae[k], chosen=(k == chosen), n_test=len(te)))
    pd.DataFrame(rows).to_csv(out, index=False)


def stage_nested(jobs, quick):
    Parallel(n_jobs=jobs, verbose=5)(delayed(nested_task)(d, quick) for d in DATASETS)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", nargs="+", default=["cv", "conformal", "nested"])
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    for s in a.stages:
        {"cv": stage_cv, "conformal": stage_conformal, "nested": stage_nested}[s](a.jobs, a.quick)
    print("done")
