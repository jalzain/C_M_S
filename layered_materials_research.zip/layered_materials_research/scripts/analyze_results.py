#!/usr/bin/env python3
"""Turn raw experiment CSVs into summary tables, statistical tests and LaTeX tables.
Writes results/csv/*.csv and results/tables/*.tex.  Run after run_all_experiments.py and run_bo_experiments.py."""
import sys, warnings
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
from statistical_analysis import (summarise_folds, paired_model_comparison, friedman_ranks, bootstrap_ci, wilson_interval,
                                  holm_correction)
from data_preprocessing import audit_all, twin_consistency, bandstructure_gap_consistency, overlap_between_datasets
from scipy import stats

CSV = ROOT / "results" / "csv"
TAB = ROOT / "results" / "tables"
TAB.mkdir(parents=True, exist_ok=True)
BASE = "GP-original"
PROP = "GP-comp-ARD-M15"


def tex(df, name, caption, label, float_fmt="%.3f", index=False, colfmt=None):
    s = df.to_latex(index=index, float_format=lambda v: float_fmt % v, escape=True, na_rep="--", column_format=colfmt)
    # column headers that contain maths were escaped by pandas; restore them
    for bad, good in {"\\$R\\textasciicircum 2\\$": "$R^2$", "\\$\\textbackslash Delta\\$MAE": "$\\Delta$MAE",
                      "\\$p\\_\\{\\textbackslash mathrm\\{Holm\\}\\}\\$": "$p_{\\mathrm{Holm}}$",
                      "\\$p\\_\\{\\textbackslash mathrm\\{NB\\}\\}\\$": "$p_{\\mathrm{NB}}$"}.items():
        s = s.replace(bad, good)
    s = s.replace("\\textbackslash \\%", "\\%")
    s = s.replace("\\begin{tabular}", "\\adjustbox{max width=\\textwidth}{\\begin{tabular}", 1).replace("\\end{tabular}", "\\end{tabular}}", 1)
    (TAB / f"{name}.tex").write_text(
        "\\begin{table}[t]\n\\centering\\small\n\\caption{" + caption + "}\n\\label{" + label + "}\n" + s + "\\end{table}\n")


def pm(m, lo, hi, d=3):
    return f"{m:.{d}f} [{lo:.{d}f}, {hi:.{d}f}]"


def main():
    # ---------------- data audit
    audit = audit_all(); audit.to_csv(CSV / "data_audit_summary.csv", index=False)
    twin_consistency().to_csv(CSV / "data_audit_twin_consistency.csv", index=False)
    bandstructure_gap_consistency().to_csv(CSV / "data_audit_bandstructure_vs_gap.csv", index=False)
    overlap_between_datasets().to_csv(CSV / "data_audit_dataset_overlap.csv")

    # flat-CBM audit of the band-structure file
    from data_preprocessing import load_dataset as _ld
    _b = _ld("band_structure"); _Y = _b.y
    pd.DataFrame(dict(structure=_b.frame.structure.values, cbm_sd_eV=_Y[:, :30].std(1), cbm_mean_eV=_Y[:, :30].mean(1), cbm_min_eV=_Y[:, :30].min(1),
                      vbm_max_eV=_Y[:, 30:].max(1))).sort_values("cbm_sd_eV").to_csv(CSV / "data_audit_cbm_flatness.csv", index=False)

    # ---------------- main regression study
    F = pd.read_csv(CSV / "regression_main_folds.csv")
    S = summarise_folds(F, metrics=("MAE", "RMSE", "R2"))
    S.to_csv(CSV / "metrics_main_summary.csv", index=False)
    comp = paired_model_comparison(F, BASE, "MAE")
    comp.to_csv(CSV / "stats_main_paired_vs_original_MAE.csv", index=False)
    paired_model_comparison(F, BASE, "RMSE").to_csv(CSV / "stats_main_paired_vs_original_RMSE.csv", index=False)
    paired_model_comparison(F, PROP, "MAE").to_csv(CSV / "stats_main_paired_vs_proposed_MAE.csv", index=False)
    friedman_ranks(F, "MAE").to_csv(CSV / "stats_main_friedman_ranks.csv", index=False)

    # table: main performance
    rows = []
    order = [BASE, PROP, "GP-comp-ARD-M25", "GP-comp-iso-M25", "RF-comp", "ET-comp", "GBR-comp", "SVR-comp", "KRR-comp",
             "Ridge-comp", "Mean-predictor"]
    for d in ("band_gap", "eff_p", "eff_n"):
        for m in order:
            r = S[(S.dataset == d) & (S.model == m)]
            if r.empty: continue
            r = r.iloc[0]
            rows.append({"Dataset": d, "Model": m, "MAE": pm(r.MAE_mean, r.MAE_ci_lo, r.MAE_ci_hi),
                         "RMSE": f"{r.RMSE_mean:.3f}", "$R^2$": f"{r.R2_mean:.3f}",
                         "NLL": "--" if pd.isna(r.get("NLL_mean", np.nan)) else f"{r.NLL_mean:.2f}",
                         "Fit time (s)": f"{r.fit_time_s_mean:.2f}"})
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_main_performance.csv", index=False)
    tex(T, "table_main_performance", "Out-of-fold performance under twin-aware $5\\times5$ cross-validation (mean, bootstrap 95\\% CI over 25 folds). "
        "MAE and RMSE are in eV (band gap) or EFF units. NLL: Gaussian negative log-likelihood (GP only).", "tab:main", colfmt="llcccrr")

    # table: paired tests
    rows = []
    for d in ("band_gap", "eff_p", "eff_n"):
        for m in [PROP, "GP-comp-ARD-M25", "GP-comp-iso-M25", "RF-comp", "ET-comp", "GBR-comp", "GP-sym-ARD-M25"]:
            r = comp[(comp.dataset == d) & (comp.model == m)]
            if r.empty: continue
            r = r.iloc[0]
            rows.append({"Dataset": d, "Model": m, "$\\Delta$MAE": f"{r.mean_diff:+.3f}",
                         "95\\% CI": f"[{r.ci95_lo:+.3f}, {r.ci95_hi:+.3f}]", "Rel. (\\%)": f"{r.rel_change_pct:+.1f}",
                         "$p_{\\mathrm{Holm}}$": f"{r.p_wilcoxon_holm:.1e}", "$p_{\\mathrm{NB}}$": f"{r.p_corrected_t:.2f}"})
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_paired_tests.csv", index=False)
    tex(T, "table_paired_tests", "Paired comparison with the original GP (reference) on identical folds. $\\Delta$MAE = model $-$ original "
        "(negative is better); $p_{\\mathrm{Holm}}$: Wilcoxon signed-rank, Holm-adjusted within dataset; $p_{\\mathrm{NB}}$: Nadeau--Bengio corrected resampled $t$-test.",
        "tab:paired", colfmt="llcccrr")

    # kernel table
    kn = ["GP-comp-ARD-M15", "GP-comp-ARD-M25", "GP-comp-ARD-RBF", "GP-comp-iso-M25", "GP-comp-iso-RBF", "GP-comp-iso-RQ",
          "GP-sym-ARD-M25", "GP-pos-ARD-M25", BASE]
    rows = []
    for m in kn:
        rec = {"Model": m}
        for d in ("band_gap", "eff_p", "eff_n"):
            r = S[(S.dataset == d) & (S.model == m)].iloc[0]
            rec[f"{d} MAE"] = f"{r.MAE_mean:.3f}"; rec[f"{d} NLL"] = f"{r.NLL_mean:.2f}"; rec[f"{d} cov95"] = f"{r.coverage95_mean:.2f}"
        rows.append(rec)
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_kernels.csv", index=False)
    T2 = T.copy(); T2.columns = ["Model"] + [f"{c.split()[1]}" for c in T.columns[1:]]
    T2.insert(0, " ", "")
    tex(T, "table_kernels", "GP kernel and representation study (grouped CV). For each dataset: MAE, NLL and empirical 95\\% coverage.",
        "tab:kernels", colfmt="l" + "ccc" * 3)

    # ---------------- protocol / leakage
    P = pd.read_csv(CSV / "regression_protocol_folds.csv")
    G = F[F.model.isin(["GP-original", PROP, "ET-comp", "Mean-predictor"])].copy()
    G = G[G.repeat < 3]
    allp = pd.concat([P, G], ignore_index=True)
    PS = summarise_folds(allp, metrics=("MAE", "RMSE", "R2"), group_cols=("dataset", "scheme", "model"))
    PS.to_csv(CSV / "metrics_protocol_summary.csv", index=False)
    rows = []
    for d in ("band_gap", "eff_p", "eff_n"):
        for m in ["GP-original", PROP, "ET-comp"]:
            rec = {"Dataset": d, "Model": m}
            for sch, nm in (("random", "Random K-fold"), ("grouped_canonical", "Twin-aware"), ("grouped_composition", "Composition-held-out")):
                r = PS[(PS.dataset == d) & (PS.model == m) & (PS.scheme == sch)]
                rec[nm] = f"{r.MAE_mean.iloc[0]:.3f}" if len(r) else "--"
            rows.append(rec)
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_protocol.csv", index=False)
    tex(T, "table_protocol", "MAE under three validation protocols (identical models). `Random K-fold' mixes stack-reversed twins across train/test; "
        "`Twin-aware' keeps them together; `Composition-held-out' keeps all stacks with the same multiset of layers together.", "tab:protocol", colfmt="llccc")

    # ---------------- ablation
    A = pd.read_csv(CSV / "regression_ablation_folds.csv")
    AS = summarise_folds(A, metrics=("MAE", "RMSE", "R2"))
    AS.to_csv(CSV / "metrics_ablation_summary.csv", index=False)
    rows = []
    for m in sorted(A.model.unique()):
        rec = {"Step": m}
        for d in ("band_gap", "eff_p", "eff_n"):
            r = AS[(AS.dataset == d) & (AS.model == m)]
            base = AS[(AS.dataset == d) & (AS.model.str.startswith("A0"))].MAE_mean.iloc[0]
            rec[d] = f"{r.MAE_mean.iloc[0]:.3f} ({100*(r.MAE_mean.iloc[0]/base-1):+.0f}\\%)"
        rows.append(rec)
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_ablation.csv", index=False)
    tex(T, "table_ablation", "Ablation chain for the GP surrogate (MAE, relative change versus A0 in parentheses; $5\\times3$ twin-aware CV).",
        "tab:ablation", colfmt="lccc")

    # ---------------- restarts / cost
    R = pd.read_csv(CSV / "regression_restarts_folds.csv")
    R["family"] = R.model.str.split("|").str[0]; R["restarts"] = R.model.str.extract(r"restarts=(\d+)").astype(int)
    RS = R.groupby(["dataset", "family", "restarts"]).agg(MAE=("MAE", "mean"), RMSE=("RMSE", "mean"), NLL=("NLL", "mean"),
                                                         fit_time_s=("fit_time_s", "mean")).reset_index()
    RS.to_csv(CSV / "metrics_restart_study.csv", index=False)
    rows = []
    for fam in ("GP-original", PROP):
        for r_ in sorted(RS[RS.family == fam].restarts.unique()):
            rec = {"Model": fam, "Restarts": r_}
            for d in ("band_gap", "eff_p", "eff_n"):
                x = RS[(RS.family == fam) & (RS.restarts == r_) & (RS.dataset == d)].iloc[0]
                rec[f"{d} MAE"] = f"{x.MAE:.3f}"; rec[f"{d} time (s)"] = f"{x.fit_time_s:.2f}"
            rows.append(rec)
    T = pd.DataFrame(rows); T.to_csv(CSV / "table_restarts.csv", index=False)
    tex(T, "table_restarts", "Effect of the number of optimiser restarts on accuracy and mean fit time per model (twin-aware $5\\times2$ CV).",
        "tab:restarts", colfmt="lrcccccc")

    # ---------------- calibration summary
    P_ = pd.read_csv(CSV / "regression_main_pred.csv")
    rows = []
    for (d, m), g in P_[P_.model.isin([BASE, PROP, "GP-comp-iso-M25", "GP-sym-ARD-M25"])].groupby(["dataset", "model"]):
        z = (g.y_pred - g.y_true) / g.y_sigma.clip(lower=1e-9)
        rows.append(dict(dataset=d, model=m, coverage68=(z.abs() <= 1).mean(), coverage95=(z.abs() <= 1.96).mean(), z_std=z.std(),
                         spearman_sigma_abserr=stats.spearmanr(g.y_sigma, (g.y_pred - g.y_true).abs())[0],
                         mean_sigma=g.y_sigma.mean(), mae=(g.y_pred - g.y_true).abs().mean()))
    pd.DataFrame(rows).to_csv(CSV / "calibration_summary.csv", index=False)

    # ---------------- learning curves
    L = pd.read_csv(CSV / "learning_curves.csv")
    LS = L.groupby(["dataset", "model", "train_fraction"]).agg(n_train=("n_train", "mean"), MAE=("MAE", "mean"), MAE_sd=("MAE", "std"),
                                                               RMSE=("RMSE", "mean"), fit_time_s=("fit_time_s", "mean")).reset_index()
    LS.to_csv(CSV / "metrics_learning_curves_summary.csv", index=False)

    # ---------------- curves
    C = pd.read_csv(CSV / "curves_folds.csv")
    CS = C.groupby("model").agg(RMSE=("RMSE", "mean"), MAE=("MAE", "mean"), RMSE_CBM=("RMSE_CBM", "mean"), RMSE_VBM=("RMSE_VBM", "mean"),
                                gap_MAE=("gap_MAE", "mean"), gap_RMSE=("gap_RMSE", "mean"), gap_R2=("gap_R2", "mean"), R2=("R2", "mean"),
                                fit_time_s=("fit_time_s", "mean")).reset_index().sort_values("RMSE")
    CS.to_csv(CSV / "metrics_curves_summary.csv", index=False)
    T = CS[["model", "RMSE", "RMSE_CBM", "RMSE_VBM", "gap_MAE", "gap_R2", "fit_time_s"]].copy()
    T.columns = ["Model", "RMSE", "RMSE CBM", "RMSE VBM", "Gap MAE", "Gap $R^2$", "Fit (s)"]
    tex(T, "table_curves", "Band-structure curve prediction (60 outputs: 30 CBM + 30 VBM points, eV), twin-aware $5\\times3$ CV. "
        "Gap is $\\max(0,\\min\\mathrm{CBM}-\\max\\mathrm{VBM})$ computed from the predicted curves.", "tab:curves", colfmt="lcccccc")
    C_ = C.copy()
    pc = paired_model_comparison(C_.assign(dataset="curves", scheme="grouped_canonical"), "Indep-GP-original", "RMSE")
    pc.to_csv(CSV / "stats_curves_paired_vs_original_RMSE.csv", index=False)

    # ---------------- original scripts
    if (CSV / "original_baseline_runs.csv").exists():
        O = pd.read_csv(CSV / "original_baseline_runs.csv"); O.to_csv(CSV / "table_original_script_runs.csv", index=False)

    # ---------------- BO
    if (CSV / "bo_run_summaries.csv").exists():
        B = pd.read_csv(CSV / "bo_run_summaries.csv")
        M = B[B.tag == "main"]
        rows = []
        for (d, m), g in M.groupby(["dataset", "label"]):
            n = len(g)
            k1, k5 = int(g.found_global.sum()), int(g["hit_top5pct"].sum())
            lo1, hi1 = wilson_interval(k1, n); lo5, hi5 = wilson_interval(k5, n)
            e5 = g["evals_to_top5pct"]
            rows.append(dict(dataset=d, method=m, n_runs=n, pool=int(g.N_pool.iloc[0]), n_evaluated=int(g.n_evaluated.iloc[0]),
                             p_global=k1 / n, p_global_lo=lo1, p_global_hi=hi1, p_top5=k5 / n, p_top5_lo=lo5, p_top5_hi=hi5,
                             median_final_rank=g.final_rank.median(), mean_final_rank=g.final_rank.mean(),
                             median_evals_to_top5=e5.median(),
                             mean_evals_to_optimum_censored=g.evals_to_global.fillna(g.n_evaluated).mean(), mean_final_best=g.final_best.mean(),
                             runtime_s_mean=g.runtime_s.mean(), surrogate_fit_s_mean=g.surrogate_fit_s.mean()))
        BS = pd.DataFrame(rows); BS.to_csv(CSV / "metrics_bo_summary.csv", index=False)
        # paired tests vs random and vs original (Mann-Whitney on final rank; Fisher on success)
        rows = []
        for d, g in M.groupby("dataset"):
            for ref in ("random", "orig_ei"):
                r = g[g.label == ref]
                for m, h in g.groupby("label"):
                    if m == ref: continue
                    u = stats.mannwhitneyu(h.final_rank, r.final_rank, alternative="less")
                    f5 = stats.fisher_exact([[int(h.hit_top5pct.sum()), len(h) - int(h.hit_top5pct.sum())],
                                             [int(r.hit_top5pct.sum()), len(r) - int(r.hit_top5pct.sum())]])[1]
                    rows.append(dict(dataset=d, method=m, reference=ref, n_method=len(h), n_ref=len(r),
                                     median_rank_method=h.final_rank.median(), median_rank_ref=r.final_rank.median(),
                                     p_mannwhitney_rank_lower=u.pvalue, p_fisher_top5=f5))
        TT = pd.DataFrame(rows)
        TT["p_mw_holm"] = TT.groupby(["dataset", "reference"]).p_mannwhitney_rank_lower.transform(lambda s: holm_correction(s.values))
        TT.to_csv(CSV / "stats_bo_tests.csv", index=False)
        # tex table
        rows = []
        for d in ("band_gap", "eff_p", "eff_n_full"):
            for m in ("random", "orig_ei", "ei", "pi", "ucb", "greedy", "ts"):
                r = BS[(BS.dataset == d) & (BS.method == m)]
                if r.empty: continue
                r = r.iloc[0]
                rows.append({"Dataset": d, "Method": m, "Runs": int(r.n_runs), "P(top-5 %)": f"{r.p_top5:.2f}",
                             "P(optimum)": f"{r.p_global:.2f}", "Median rank": f"{r.median_final_rank:.0f}",
                             "Evals to top-5\\%": "--" if pd.isna(r.median_evals_to_top5) else f"{r.median_evals_to_top5:.0f}",
                             "Evals to optimum": f"{r.mean_evals_to_optimum_censored:.1f}",
                             "Time/run (s)": f"{r.runtime_s_mean:.0f}"})
        T = pd.DataFrame(rows); T.to_csv(CSV / "table_bo.csv", index=False)
        tex(T, "table_bo", "Bayesian optimisation after the full budget (10\\% random initial design + 30 sequential evaluations). "
            "P(top-5\\%): fraction of runs whose best evaluated structure is among the best 5\\% of the pool; P(optimum): fraction that found the global optimum; "
            "median rank of the best evaluated structure (1 = optimum); median number of evaluations until a top-5\\% structure was first evaluated; mean number of evaluations until the optimum was evaluated (runs that never found it count with the full budget, so this is a lower bound).",
            "tab:bo", colfmt="llrccccrr")
        # ablation of BO
        Ab = B[B.tag == "abl"]
        if len(Ab):
            rows = []
            allr = pd.concat([M[M.label.isin(["ei", "orig_ei", "random", "ucb", "ts"])], Ab])
            for (d, m), g in allr.groupby(["dataset", "label"]):
                rows.append(dict(dataset=d, variant=m, n_runs=len(g), p_top5=g.hit_top5pct.mean(), p_optimum=g.found_global.mean(),
                                 median_rank=g.final_rank.median(), runtime_s=g.runtime_s.mean()))
            pd.DataFrame(rows).to_csv(CSV / "metrics_bo_ablation.csv", index=False)
        Se = B[B.tag == "sens"]
        if len(Se):
            Se.groupby(["dataset", "label"]).agg(n_runs=("seed", "count"), p_top5=("hit_top5pct", "mean"), p_optimum=("found_global", "mean"),
                                                 median_rank=("final_rank", "median")).reset_index().to_csv(CSV / "metrics_bo_sensitivity.csv", index=False)
        # reporting discrepancy of the original BO
        o = M[M.label == "orig_ei"]
        if len(o):
            o.groupby("dataset").agg(n_runs=("seed", "count"), mean_reported_minus_evaluated=("reported_minus_evaluated", "mean"),
                                     max_reported_minus_evaluated=("reported_minus_evaluated", "max"),
                                     frac_runs_reported_ne_evaluated=("reported_minus_evaluated", lambda s: (s.abs() > 1e-6).mean())).reset_index().to_csv(
                CSV / "metrics_bo_original_reporting_discrepancy.csv", index=False)

    # ---------------- calibration + original-script tables for the manuscript
    if (CSV / "calibration_summary.csv").exists():
        Cb = pd.read_csv(CSV / "calibration_summary.csv")
        Cb = Cb[["dataset", "model", "coverage68", "coverage95", "z_std", "spearman_sigma_abserr", "mae"]]
        Cb.columns = ["Dataset", "Model", "Cov. 68\\%", "Cov. 95\\%", "Std of z", "Spearman $\\sigma$-error", "MAE"]
        tex(Cb, "table_calibration", "Calibration of GP predictive distributions under twin-aware CV: empirical coverage of nominal 68\\% and 95\\% intervals, "
            "standard deviation of standardised residuals $z$ (ideal 1), and Spearman correlation between predicted $\\sigma$ and absolute error.", "tab:calib")
    if (CSV / "original_baseline_runs.csv").exists():
        O = pd.read_csv(CSV / "original_baseline_runs.csv")
        keep = [c for c in ["job", "seed", "status", "test_MAE", "test_RMSE", "init_value", "final_value"] if c in O.columns]
        O = O[keep].copy()
        O["status"] = O["status"].astype(str).map(lambda v: "ok" if v == "ok" else "error (no header)")
        tex(O, "table_original_script_runs", "Outcome of the unmodified original scripts under fixed seeds (our runner, \\texttt{results/csv/original\\_baseline\\_runs.csv}); "
            "single-run outputs, not statistical estimates. \\texttt{BO\\_N\\_as\\_shipped} fails because the N-doped file lacks the count header; \\texttt{BO\\_N} uses a copy with the header added. "
            "BO\\_* values are the initial and final best evaluated values.", "tab:orig_runs", colfmt=None)

    # ---------------- additional manuscript tables (cost, BO sensitivity, BO ablation, feature sensitivity)
    if (CSV / "scaling.csv").exists():
        Sc = pd.read_csv(CSV / "scaling.csv")
        g = Sc.groupby(["model", "n_train"]).agg(fit=("fit_time_s", "mean"), pred=("predict_time_s", "mean")).reset_index()
        T = g[g.n_train.isin([20, 60, 140])].pivot(index="model", columns="n_train", values=["fit", "pred"])
        T.columns = [f"{'Fit' if a == 'fit' else 'Predict'} $n$={b} (s)" for a, b in T.columns]
        T = T.reset_index().rename(columns={"model": "Model"}); T.to_csv(CSV / "table_scaling.csv", index=False)
        tex(T, "table_scaling", "Computational cost versus training-set size (mean over three repeats; single CPU core; GPs with two optimiser restarts). "
            "Fit times of the GPs are dominated by the marginal-likelihood optimisation.", "tab:scaling", float_fmt="%.3f")
    if (CSV / "metrics_bo_sensitivity.csv").exists():
        Bs = pd.read_csv(CSV / "metrics_bo_sensitivity.csv")
        Bs["Dataset"] = Bs.dataset.map({"band_gap": "Band gap", "eff_p": "P-doped", "eff_n_full": "N-doped (full)"})
        Bt = Bs.pivot(index="label", columns="Dataset", values="p_optimum").reset_index().rename(columns={"label": "Setting"})
        Bt["Setting"] = Bt.Setting.str.replace("ei_xi", "EI, $\\xi$=", regex=False).str.replace("ucb_beta", "UCB, $\\beta$=", regex=False)
        Bt.to_csv(CSV / "table_bo_sensitivity.csv", index=False)
        Bt2 = Bt.copy(); Bt2["Setting"] = Bt2.Setting.str.replace("$", "", regex=False).str.replace("\\", "", regex=False)
        s_ = Bt.to_latex(index=False, float_format=lambda v: "%.2f" % v, escape=False, column_format="lccc")
        (TAB / "table_bo_sensitivity.tex").write_text("\\begin{table}[t]\n\\centering\\small\n\\caption{Sensitivity of the probability of evaluating the global optimum to the EI offset $\\xi$ (fraction of the standard deviation of observed values) and the UCB parameter $\\beta$ (30 runs per setting, 30 iterations).}\n\\label{tab:bosens}\n" + s_ + "\\end{table}\n")
    if (CSV / "metrics_bo_ablation.csv").exists():
        Ba = pd.read_csv(CSV / "metrics_bo_ablation.csv")
        nm = {"random": "Random search", "orig_ei": "Original logic + original surrogate", "origacq_on_improvedGP": "Original logic + improved surrogate", "ei": "EI, improved surrogate",
              "ei_positionalARD": "EI, positional ARD surrogate", "ei_compARD": "EI, composition ARD surrogate", "ucb_compARD": "UCB, composition ARD surrogate",
              "ts_compARD": "Thompson, composition ARD surrogate"}
        Ba = Ba[Ba.variant.isin(nm)].copy(); Ba["Variant"] = Ba.variant.map(nm); Ba["Dataset"] = Ba.dataset.map({"band_gap": "Band gap", "eff_p": "P-doped", "eff_n_full": "N-doped (full)"})
        Bp = Ba.pivot(index="Variant", columns="Dataset", values="p_optimum").reindex(list(nm.values())).reset_index()
        Bn = Ba.groupby("Variant").n_runs.first().reindex(list(nm.values())).values; Bp.insert(1, "Runs", Bn.astype(int))
        Bp.to_csv(CSV / "table_bo_ablation.csv", index=False)
        tex(Bp, "table_bo_ablation", "BO ablation: probability that the global optimum was evaluated within the budget. Runs: number of paired seeds per variant (identical for all pools).", "tab:boabl", float_fmt="%.2f")
    if (CSV / "feature_sensitivity.csv").exists():
        Fs = pd.read_csv(CSV / "feature_sensitivity.csv")
        Ft = Fs.pivot(index="feature", columns="dataset", values=["gp_inverse_length_scale_normalised", "rf_permutation_importance_MAE_increase"])
        Ft.columns = [("GP $1/\\ell$ " if a.startswith("gp") else "RF $\\Delta$MAE ") + {"band_gap": "gap", "eff_p": "P", "eff_n": "N"}[b] for a, b in Ft.columns]
        Ft = Ft.reset_index().rename(columns={"feature": "Descriptor"}); Ft.to_csv(CSV / "table_features.csv", index=False)
        s_ = Ft.to_latex(index=False, float_format=lambda v: "%.3f" % v, escape=False, column_format="l" + "r" * 6)
        (TAB / "table_features.tex").write_text("\\begin{table}[t]\n\\centering\\scriptsize\n\\caption{Descriptor sensitivity: normalised inverse ARD length scales of the composition GP (fit to all data) and random-forest permutation importance (increase of held-out MAE, averaged over five twin-aware folds). Descriptors are correlated (Fig.~\\ref{fig:corr}), so values indicate model usage, not mechanism.}\n\\label{tab:features}\n\\adjustbox{max width=\\textwidth}{" + s_ + "}\n\\end{table}\n")
    print("analysis done")


if __name__ == "__main__":
    main()
