#!/usr/bin/env python3
"""Supplementary analysis added in the revision: effective dimensionality of the 11 composition descriptors.

Writes results/csv/descriptor_effective_dimension.csv (one row per data set).  Run: python scripts/extra_analysis.py
"""
import sys, warnings
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src")); warnings.filterwarnings("ignore")
from registry import get_dataset
from data_preprocessing import build_features

rows = []
for d in ("band_gap", "eff_p", "eff_n"):
    ds = get_dataset(d); f = ds.frame.drop_duplicates("canonical") if d == "band_gap" else ds.frame
    X = build_features(f.reset_index(drop=True), "composition"); keep = X.std(0) > 1e-12
    Z = (X[:, keep] - X[:, keep].mean(0)) / X[:, keep].std(0)
    ev = np.clip(np.linalg.eigvalsh(np.corrcoef(Z.T))[::-1], 0, None); ev = ev / ev.sum()
    cum = np.cumsum(ev)
    rows.append(dict(dataset=d, n_stacks=len(f), n_descriptors=X.shape[1], n_nonconstant=int(keep.sum()),
                     numerical_rank=int((ev > 1e-10).sum()), pcs_for_95pct=int(np.searchsorted(cum, 0.95) + 1),
                     pcs_for_99pct=int(np.searchsorted(cum, 0.99) + 1), n_distinct_values_per_descriptor_max=int(max(len(np.unique(X[:, k])) for k in range(X.shape[1])))))
pd.DataFrame(rows).to_csv(ROOT / "results" / "csv" / "descriptor_effective_dimension.csv", index=False)
print(pd.DataFrame(rows).to_string())
