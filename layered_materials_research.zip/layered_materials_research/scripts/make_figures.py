#!/usr/bin/env python3
"""Generate all publication figures (PNG + PDF) from the exported CSV files.  Run after analyze_results.py."""
import sys, warnings, importlib.util
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
from plotting import *
from statistical_analysis import wilson_interval
from registry import get_dataset
from improved_models import ImprovedGP, TreeEnsemble
from data_preprocessing import build_features
from evaluation import make_splits

style()
CSV = ROOT / "results" / "csv"
BASE, PROP = "GP-original", "GP-comp-ARD-M15"
DS = ("band_gap", "eff_p", "eff_n")
BO_COL = {"random": GREY, "orig_ei": ORANGE, "ei": BLUE, "pi": VIOLET, "ucb": AQUA, "greedy": YELLOW, "ts": MAGENTA}
BO_NAME = {"random": "Random search", "orig_ei": "Original EI logic", "ei": "EI (proposed)", "pi": "PI", "ucb": "UCB ($\\beta$=2)",
           "greedy": "Greedy mean", "ts": "Thompson"}
BO_DS = ("band_gap", "eff_p", "eff_n_full")
BO_DS_TITLE = {"band_gap": "Band gap (105 unique stacks)", "eff_p": "P-doped EFF (115)", "eff_n_full": "N-doped EFF (116, incl. outliers)"}

F = pd.read_csv(CSV / "regression_main_folds.csv")
P = pd.read_csv(CSV / "regression_main_pred.csv")
S = pd.read_csv(CSV / "metrics_main_summary.csv")


def lab(m, c=None):
    return {"GP-original": "GP, original", PROP: "GP, composition (proposed)"}.get(m, m)


# ----------------------------------------------------------------------------- 01 parity
def fig01():
    fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.6)); rows = []
    for ax, d in zip(axs, DS):
        for m, col, mk in ((BASE, ORANGE, "o"), (PROP, BLUE, "s")):
            g = P[(P.dataset == d) & (P.model == m)].groupby("structure").agg(y=("y_true", "first"), p=("y_pred", "mean")).reset_index()
            rows.append(g.assign(dataset=d, model=m)[["dataset", "model", "structure", "y", "p"]].rename(columns={"y": "reference", "p": "oof_prediction_mean"}))
            mae = (g.p - g.y).abs().mean(); r2 = 1 - ((g.p - g.y) ** 2).sum() / ((g.y - g.y.mean()) ** 2).sum()
            ax.scatter(g.y, g.p, s=16, marker=mk, color=col, alpha=0.75, edgecolor="white", linewidth=0.3,
                       label=f"{lab(m)}: MAE {mae:.2f}, $R^2$ {r2:.2f}")
        lim = [min(ax.get_xlim()[0], ax.get_ylim()[0]), max(ax.get_xlim()[1], ax.get_ylim()[1])]
        ax.plot(lim, lim, color=INK2, lw=0.8, ls="--"); ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal")
        ax.set_title(DATASET_SHORT[d]); ax.set_xlabel("Reference value" + (" (eV)" if d == "band_gap" else ""))
        ax.legend(loc="upper left", bbox_to_anchor=(-0.02, -0.17), fontsize=6.5)
    axs[0].set_ylabel("Out-of-fold prediction (mean of 5 repeats)")
    for ax, s in zip(axs, "abc"): panel_label(ax, s)
    export("fig01_parity_predicted_vs_reference", pd.concat(rows)); save(fig, "fig01_parity_predicted_vs_reference")


# ----------------------------------------------------------------------------- 02 model comparison
def fig02():
    fig, axs = plt.subplots(1, 3, figsize=(11, 4.6))
    for ax, d in zip(axs, DS):
        s = S[S.dataset == d].sort_values("MAE_mean", ascending=False)
        y = np.arange(len(s))
        for i, (_, r) in enumerate(s.iterrows()):
            col = ORANGE if r.model == BASE else BLUE if r.model == PROP else "#9a9993"
            ax.errorbar(r.MAE_mean, i, xerr=[[r.MAE_mean - r.MAE_ci_lo], [r.MAE_ci_hi - r.MAE_mean]], fmt="o", color=col, ms=5, capsize=2)
        ax.set_yticks(y); ax.set_yticklabels([m for m in s.model], fontsize=7)
        for t, m in zip(ax.get_yticklabels(), s.model):
            if m in (BASE, PROP): t.set_fontweight("bold")
        ax.set_xlabel("MAE (twin-aware CV, 95% CI)"); ax.set_title(DATASET_SHORT[d]); panel_label(ax, "abc"[DS.index(d)])
    fig.legend(handles=[Line2D([], [], marker="o", color=ORANGE, ls="", label="Original GP"), Line2D([], [], marker="o", color=BLUE, ls="", label="Proposed GP"),
                        Line2D([], [], marker="o", color="#9a9993", ls="", label="Other")], loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.04))
    fig.tight_layout()
    export("fig02_model_accuracy_comparison", S[S.dataset.isin(DS)][["dataset", "model", "MAE_mean", "MAE_ci_lo", "MAE_ci_hi"]])
    save(fig, "fig02_model_accuracy_comparison")


# ----------------------------------------------------------------------------- 03 kernels
def fig03():
    gps = ["GP-original", "GP-pos-ARD-M25", "GP-sym-ARD-M25", "GP-comp-iso-M25", "GP-comp-iso-RBF", "GP-comp-iso-RQ", "GP-comp-ARD-RBF", "GP-comp-ARD-M25", PROP]
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.6), sharey="row"); rows = []
    for j, d in enumerate(DS):
        for i, met in enumerate(("MAE", "NLL")):
            ax = axs[i, j]
            for k, m in enumerate(gps):
                r = S[(S.dataset == d) & (S.model == m)].iloc[0]
                col, mk = ROLE.get(m, (GREY, "o"))
                if met == "MAE":
                    ax.errorbar(k, r.MAE_mean, yerr=[[r.MAE_mean - r.MAE_ci_lo], [r.MAE_ci_hi - r.MAE_mean]], fmt=mk, color=col, ms=6, capsize=2)
                else:
                    v = F[(F.dataset == d) & (F.model == m)]["NLL"].dropna().values
                    from statistical_analysis import bootstrap_ci
                    lo, hi = bootstrap_ci(v); rows.append(dict(dataset=d, model=m, NLL_mean=v.mean(), NLL_ci_lo=lo, NLL_ci_hi=hi))
                    ax.errorbar(k, v.mean(), yerr=[[v.mean() - lo], [hi - v.mean()]], fmt=mk, color=col, ms=6, capsize=2)
            ax.set_xticks(range(len(gps))); ax.set_xticklabels([g.replace("GP-", "") for g in gps], rotation=60, ha="right", fontsize=7)
            ax.set_ylabel("MAE" if met == "MAE" else "NLL (lower = better)") if j == 0 else None
            if i == 0: ax.set_title(DATASET_SHORT[d])
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout()
    K = S[S.dataset.isin(DS) & S.model.isin(gps)][["dataset", "model", "MAE_mean", "MAE_ci_lo", "MAE_ci_hi"]].merge(pd.DataFrame(rows), on=["dataset", "model"])
    export("fig03_gp_kernel_comparison", K); save(fig, "fig03_gp_kernel_comparison")


# ----------------------------------------------------------------------------- 04 learning curves
def fig04():
    L = pd.read_csv(CSV / "learning_curves.csv")
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.6)); rows = []
    for ax, d in zip(axs, DS):
        for m in ("GP-original", PROP, "GP-comp-iso-M25", "ET-comp", "RF-comp", "Mean-predictor"):
            mm = "GP-comp-ARD-M15" if m == PROP else m
            g = L[(L.dataset == d) & (L.model == mm)]
            if g.empty: continue
            agg = g.groupby("train_fraction").agg(n=("n_train", "mean"), mu=("MAE", "mean"), se=("MAE", lambda x: x.std() / np.sqrt(len(x)))).reset_index()
            col, mk = ROLE.get(m, (GREY, "o")); rows.append(agg.assign(dataset=d, model=mm))
            ax.plot(agg.n, agg.mu, marker=mk, color=col, ms=4, label=lab(m))
            ax.fill_between(agg.n, agg.mu - 1.96 * agg.se, agg.mu + 1.96 * agg.se, color=col, alpha=0.15, lw=0)
        ax.set_xlabel("Training structures"); ax.set_title(DATASET_SHORT[d]); panel_label(ax, "abc"[DS.index(d)])
        ax.set_yscale("log")
    axs[0].set_ylabel("Hold-out MAE (log scale)"); axs[0].legend(fontsize=6.5)
    fig.tight_layout(); export("fig04_learning_curves", pd.concat(rows).rename(columns={"n": "n_train_mean", "mu": "MAE_mean", "se": "MAE_se"})); save(fig, "fig04_learning_curves")


# ----------------------------------------------------------------------------- BO helpers
def load_bo():
    spec = importlib.util.spec_from_file_location("bo_exp", ROOT / "scripts" / "run_bo_experiments.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    H = pd.read_csv(CSV / "bo_histories.csv")
    pools = {d: mod.get_pool(d)[1] for d in BO_DS}
    return H, pools


def fig05_06():
    H, pools = load_bo()
    H = H[H.tag == "main"]
    fig5, axs5 = plt.subplots(1, 3, figsize=(11, 3.7))
    fig6, axs6 = plt.subplots(1, 3, figsize=(11, 3.7)); r5, r6 = [], []
    for j, d in enumerate(BO_DS):
        y = np.sort(pools[d])[::-1]
        for m in ("random", "orig_ei", "ei", "pi", "ucb", "greedy", "ts"):
            h = H[(H.dataset == d) & (H.label == m)]
            if h.empty: continue
            piv = h.pivot_table(index="n_evaluated", columns="seed", values="best_so_far")
            n0 = int(h[h.phase == "init"].groupby("seed").size().iloc[0])
            piv = piv.loc[n0:]
            ranks = piv.apply(lambda c: 1 + (y[:, None] > c.values[None, :] + 1e-12).sum(0))
            med, q1, q3 = ranks.median(1), ranks.quantile(0.25, axis=1), ranks.quantile(0.75, axis=1)
            ls = "-" if m in ("ei", "orig_ei", "random") else "--"
            r5.append(pd.DataFrame(dict(dataset=d, method=m, n_evaluated=med.index, rank_median=med.values, rank_q1=q1.values, rank_q3=q3.values)))
            axs5[j].plot(med.index, med.values, color=BO_COL[m], ls=ls, label=BO_NAME[m], lw=1.8 if m in ("ei", "orig_ei", "random") else 1.2)
            if m in ("ei", "orig_ei", "random"):
                axs5[j].fill_between(med.index, q1.values, q3.values, color=BO_COL[m], alpha=0.12, lw=0)
            if m in ("random", "orig_ei", "ei", "ucb"):
                v = np.log10(piv) if d == "eff_n_full" else piv
                mu = v.mean(1); se = v.std(1) / np.sqrt(v.shape[1])
                r6.append(pd.DataFrame(dict(dataset=d, method=m, n_evaluated=mu.index, best_value_mean=mu.values, best_value_se=se.values, log10_scale=(d == "eff_n_full"))))
                axs6[j].plot(mu.index, mu.values, color=BO_COL[m], label=BO_NAME[m])
                axs6[j].fill_between(mu.index, mu - 1.96 * se, mu + 1.96 * se, color=BO_COL[m], alpha=0.15, lw=0)
        axs5[j].set_yscale("log"); axs5[j].set_xlabel("Structures evaluated"); axs5[j].set_title(BO_DS_TITLE[d], fontsize=9)
        axs6[j].set_xlabel("Structures evaluated"); axs6[j].set_title(BO_DS_TITLE[d], fontsize=9)
        opt = np.log10(y[0]) if d == "eff_n_full" else y[0]
        axs6[j].axhline(opt, color=INK2, lw=0.8, ls=":")
        axs6[j].text(axs6[j].get_xlim()[0], opt, " pool optimum", va="bottom", fontsize=7, color=INK2)
        panel_label(axs5[j], "abc"[j]); panel_label(axs6[j], "abc"[j])
    axs5[0].set_ylabel("Rank of best evaluated structure\n(1 = optimum; median, IQR)"); axs5[0].legend(fontsize=6.5, ncol=1)
    axs6[0].set_ylabel("Best value found (eV)"); axs6[1].set_ylabel("Best EFF found"); axs6[2].set_ylabel("Best log$_{10}$ EFF found")
    axs6[0].legend(fontsize=7, loc="lower right")
    fig5.tight_layout(); fig6.tight_layout()
    export("fig05_bo_convergence_rank", pd.concat(r5)); export("fig06_best_value_vs_evaluations", pd.concat(r6))
    save(fig5, "fig05_bo_convergence_rank"); save(fig6, "fig06_best_value_vs_evaluations")


def fig07():
    BS = pd.read_csv(CSV / "metrics_bo_summary.csv")
    H, pools = load_bo(); H = H[H.tag == "main"]
    fig, axs = plt.subplots(2, 3, figsize=(11, 6.6))
    ms = ["random", "orig_ei", "ei", "pi", "ucb", "greedy", "ts"]; hits = []
    for j, d in enumerate(BO_DS):
        ax = axs[0, j]
        for k, m in enumerate(ms):
            r = BS[(BS.dataset == d) & (BS.method == m)]
            if r.empty: continue
            r = r.iloc[0]
            ax.bar(k - 0.18, r.p_top5, 0.34, color=BO_COL[m], yerr=[[r.p_top5 - r.p_top5_lo], [r.p_top5_hi - r.p_top5]], capsize=2, ecolor=INK2)
            ax.bar(k + 0.18, r.p_global, 0.34, color=BO_COL[m], alpha=0.45, hatch="///", edgecolor="white",
                   yerr=[[r.p_global - r.p_global_lo], [r.p_global_hi - r.p_global]], capsize=2, ecolor=INK2)
        ax.set_xticks(range(len(ms))); ax.set_xticklabels([BO_NAME[m].split(" (")[0] for m in ms], rotation=55, ha="right", fontsize=7)
        ax.set_ylim(0, 1.3); ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0]); ax.set_title(BO_DS_TITLE[d], fontsize=9)
        ax = axs[1, j]
        ymax = pools[d].max()
        for m in ms:
            h = H[(H.dataset == d) & (H.label == m)]
            if h.empty: continue
            piv = h.pivot_table(index="n_evaluated", columns="seed", values="best_so_far")
            n0 = int(h[h.phase == "init"].groupby("seed").size().iloc[0]); piv = piv.loc[n0:]
            hit = (piv >= ymax - 1e-12).mean(1)
            hits.append(pd.DataFrame(dict(dataset=d, method=m, n_evaluated=hit.index, p_optimum_evaluated=hit.values)))
            ax.plot(hit.index, hit.values, color=BO_COL[m], label=BO_NAME[m], lw=1.8 if m in ("ei", "orig_ei", "random") else 1.1,
                    ls="-" if m in ("ei", "orig_ei", "random") else "--")
        ax.set_xlabel("Structures evaluated"); ax.set_ylim(0, 1.05)
    axs[0, 0].set_ylabel("Fraction of runs (Wilson 95% CI)"); axs[1, 0].set_ylabel("P(global optimum already evaluated)")
    axs[0, 2].legend(handles=[plt.Rectangle((0, 0), 1, 1, color=GREY), plt.Rectangle((0, 0), 1, 1, color=GREY, alpha=0.45, hatch="///")],
                     labels=["best evaluated in top 5%", "global optimum found"], fontsize=7, loc="upper left", ncol=1)
    axs[1, 0].legend(fontsize=6.5, loc="upper left")
    for a, s in zip(axs.ravel(), "abcdef"): panel_label(a, s)
    fig.tight_layout(); export("fig07_acquisition_summary_bars", BS); export("fig07_acquisition_hit_curves", pd.concat(hits)); save(fig, "fig07_acquisition_function_comparison")


# ----------------------------------------------------------------------------- 08 uncertainty
def fig08():
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.6), sharex="col"); rows = []
    for j, d in enumerate(DS):
        for i, (m, col) in enumerate(((BASE, ORANGE), (PROP, BLUE))):
            g = P[(P.dataset == d) & (P.model == m) & (P.repeat == 0)].sort_values("y_true").reset_index(drop=True)
            ax = axs[i, j]
            x = np.arange(len(g)); rows.append(g.assign(order=x)[["dataset", "model", "structure", "order", "y_true", "y_pred", "y_sigma"]])
            ax.fill_between(x, g.y_pred - 1.96 * g.y_sigma, g.y_pred + 1.96 * g.y_sigma, color=col, alpha=0.22, lw=0, label="95% interval")
            ax.plot(x, g.y_pred, ".", color=col, ms=3.5, label="Prediction")
            ax.plot(x, g.y_true, "-", color=INK, lw=1.0, label="Reference")
            cov = ((g.y_pred - g.y_true).abs() <= 1.96 * g.y_sigma).mean()
            ax.set_title(f"{DATASET_SHORT[d]} – {lab(m)}\ncoverage {cov:.2f}, mean width {2*1.96*g.y_sigma.mean():.2f}", fontsize=8)
            if i == 1: ax.set_xlabel("Structures sorted by reference value")
            if j == 0: ax.set_ylabel("Value")
    axs[0, 0].legend(fontsize=7, loc="upper left")
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout(); export("fig08_predictive_uncertainty_confidence_intervals", pd.concat(rows)); save(fig, "fig08_predictive_uncertainty_confidence_intervals")


def fig09():
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.6))
    levels = np.linspace(0.05, 0.99, 30); rows = []
    for j, d in enumerate(DS):
        for m, col in ((BASE, ORANGE), (PROP, BLUE)):
            g = P[(P.dataset == d) & (P.model == m)]
            r = g.y_pred - g.y_true
            axs[0, j].hist(r, bins=np.linspace(-6 if d != "band_gap" else -0.8, 6 if d != "band_gap" else 0.8, 41), color=col, alpha=0.5, label=f"{lab(m)} (sd {r.std():.2f})", density=True)
            z = np.abs(r / g.y_sigma.clip(lower=1e-9))
            cov = [(z <= stats.norm.ppf(0.5 + l / 2)).mean() for l in levels]
            rows.append(pd.DataFrame(dict(dataset=d, model=m, nominal_level=levels, empirical_coverage=cov, residual_sd=r.std())))
            axs[1, j].plot(levels, cov, color=col, label=lab(m))
        axs[1, j].plot([0, 1], [0, 1], color=INK2, ls="--", lw=0.8)
        axs[0, j].set_title(DATASET_SHORT[d]); axs[0, j].set_xlabel("Residual (prediction − reference)")
        axs[1, j].set_xlabel("Nominal central-interval level"); axs[0, j].legend(fontsize=6.5)
    axs[0, 0].set_ylabel("Density"); axs[1, 0].set_ylabel("Empirical coverage")
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout(); export("fig09_calibration_curves", pd.concat(rows))
    export("fig09_residuals", P[P.dataset.isin(DS) & P.model.isin([BASE, PROP])].assign(residual=lambda x: x.y_pred - x.y_true)[["dataset", "model", "structure", "repeat", "residual", "y_sigma"]])
    save(fig, "fig09_residuals_and_calibration")


def fig10():
    fr = {d: get_dataset(d).frame.assign(nTe=lambda f: (f[["X1", "X2", "X3"]] == "Te").sum(1)) for d in DS}
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.4))
    models = [BASE, PROP, "RF-comp"]; rows = []
    for j, d in enumerate(DS):
        info = fr[d].set_index("structure")
        g = P[(P.dataset == d) & P.model.isin(models)].copy()
        g["ndl"] = g.structure.map(info.n_distinct_layers); g["nTe"] = g.structure.map(info.nTe)
        g["ae"] = (g.y_pred - g.y_true).abs()
        for i, (col_, nm) in enumerate((("ndl", "Number of distinct TMD layers in the stack"), ("nTe", "Number of Te-containing layers"))):
            ax = axs[i, j]
            cats = sorted(g[col_].dropna().unique())
            for k, m in enumerate(models):
                vals = [g[(g.model == m) & (g[col_] == c)].ae.mean() for c in cats]
                rows += [dict(dataset=d, grouping=col_, group_value=c, model=m, MAE=v) for c, v in zip(cats, vals)]
                ax.bar(np.arange(len(cats)) + (k - 1) * 0.27, vals, 0.26, color=[ORANGE, BLUE, AQUA][k], label=lab(m) if (i, j) == (0, 0) else None)
            ax.set_xticks(range(len(cats))); ax.set_xticklabels([f"{int(c)}\n(n={int((info[col_.replace('ndl','n_distinct_layers')] == c).sum())})" if col_ == "ndl" else f"{int(c)}\n(n={int((info.nTe == c).sum())})" for c in cats], fontsize=7)
            ax.set_xlabel(nm, fontsize=8)
            if j == 0: ax.set_ylabel("MAE")
            if i == 0: ax.set_title(DATASET_SHORT[d])
    axs[0, 0].legend(fontsize=6.5)
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout(); export("fig10_error_by_material_configuration", pd.DataFrame(rows)); save(fig, "fig10_error_by_material_configuration")


def fig11():
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.7))
    for ax, d in zip(axs, DS):
        s = S[(S.dataset == d) & (S.model != "Mean-predictor")]
        for _, r in s.iterrows():
            col, mk = ROLE.get(r.model, (GREY, "o"))
            ax.scatter(r.fit_time_s_mean, r.MAE_mean, color=col, marker=mk, s=38 if r.model in (BASE, PROP) else 22, edgecolor="white", lw=0.4, zorder=3)
            if r.model in (BASE, PROP, "RF-comp", "GBR-comp", "GP-comp-iso-M25", "Ridge-comp", "ET-comp"):
                ax.annotate(r.model, (r.fit_time_s_mean, r.MAE_mean), xytext=(4, 3), textcoords="offset points", fontsize=6.5)
        ax.set_xscale("log"); ax.set_xlabel("Mean fit time per model (s)"); ax.set_title(DATASET_SHORT[d]); panel_label(ax, "abc"[DS.index(d)])
    axs[0].set_ylabel("MAE (twin-aware CV)")
    fig.tight_layout(); export("fig11_runtime_vs_accuracy", S[S.dataset.isin(DS)][["dataset", "model", "fit_time_s_mean", "MAE_mean"]]); save(fig, "fig11_runtime_vs_accuracy")


COMP_NAMES = ["metal mean EN", "metal mean IP", "metal range EN", "metal range IP", "chalc. mean EN", "chalc. mean IP",
              "chalc. range EN", "chalc. range IP", "frac. W", "frac. S", "frac. Se"]


def fig12():
    rows = []
    for d in DS:
        ds = get_dataset(d)
        X = build_features(ds.frame, "composition")
        gp = ImprovedGP("matern15_ard", "composition", "none", clip_min=0.0 if d == "band_gap" else None, n_restarts=3).fit(ds.frame, ds.y)
        inv = 1.0 / gp.length_scales; inv = inv / inv.sum()
        # permutation importance on held-out folds (RF)
        imp = np.zeros(X.shape[1]); nf = 0
        rs = np.random.RandomState(0)
        for tr, te in make_splits(ds, "grouped_canonical", 5, 0, 0):
            rf = TreeEnsemble("rf", "composition", "none", n_estimators=200).fit(ds.frame.iloc[tr].reset_index(drop=True), ds.y[tr])
            Xte = build_features(ds.frame.iloc[te].reset_index(drop=True), "composition")
            base = np.abs(rf.m.predict(Xte) - ds.y[te]).mean()
            for k in range(X.shape[1]):
                inc = []
                for _ in range(10):
                    Xp = Xte.copy(); Xp[:, k] = Xp[rs.permutation(len(Xp)), k]
                    inc.append(np.abs(rf.m.predict(Xp) - ds.y[te]).mean() - base)
                imp[k] += np.mean(inc)
            nf += 1
        imp = imp / nf
        for k, nm in enumerate(COMP_NAMES):
            rows.append(dict(dataset=d, feature=nm, gp_inverse_length_scale_normalised=inv[k], rf_permutation_importance_MAE_increase=imp[k]))
    R = pd.DataFrame(rows); R.to_csv(CSV / "feature_sensitivity.csv", index=False)
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.4), sharey=True)
    for j, d in enumerate(DS):
        g = R[R.dataset == d]
        axs[0, j].barh(g.feature, g.gp_inverse_length_scale_normalised, color=BLUE); axs[0, j].set_title(DATASET_SHORT[d])
        axs[1, j].barh(g.feature, g.rf_permutation_importance_MAE_increase, color=AQUA)
        axs[0, j].set_xlabel("GP ARD relevance $1/\\ell_i$ (normalised)"); axs[1, j].set_xlabel("RF permutation importance (ΔMAE)")
        axs[0, j].invert_yaxis()
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout(); export("fig12_feature_importance_sensitivity", R); save(fig, "fig12_feature_importance_sensitivity")


def fig13():
    A = pd.read_csv(CSV / "metrics_ablation_summary.csv")
    fig, axs = plt.subplots(1, 3, figsize=(12, 3.9), sharey=True)
    steps = sorted(A.model.unique())
    for ax, d in zip(axs, DS):
        s = A[A.dataset == d].set_index("model").loc[steps]
        y = np.arange(len(steps))[::-1]
        ax.errorbar(s.MAE_mean, y, xerr=[s.MAE_mean - s.MAE_ci_lo, s.MAE_ci_hi - s.MAE_mean], fmt="o", color=BLUE, capsize=2, ms=5)
        ax.axvline(s.MAE_mean.iloc[0], color=ORANGE, ls="--", lw=0.9)
        ax.set_yticks(y); ax.set_yticklabels([t[:44] for t in steps], fontsize=6.5); ax.set_xlabel("MAE (95% CI)")
        ax.set_title(DATASET_SHORT[d]); panel_label(ax, "abc"[DS.index(d)])
    fig.tight_layout(); export("fig13_ablation_study", A[["dataset", "model", "MAE_mean", "MAE_ci_lo", "MAE_ci_hi"]]); save(fig, "fig13_ablation_study")


def fig14():
    PS = pd.read_csv(CSV / "metrics_protocol_summary.csv")
    fig, axs = plt.subplots(2, 3, figsize=(11, 5.6))
    keys = [BASE, PROP, "RF-comp", "ET-comp", "GBR-comp"]
    for j, d in enumerate(DS):
        ax = axs[0, j]
        rep = F[(F.dataset == d) & F.model.isin(keys)].groupby(["model", "repeat"]).MAE.mean().reset_index()
        for k, m in enumerate(keys):
            v = rep[rep.model == m].MAE.values
            ax.scatter(np.full(len(v), k) + np.random.RandomState(k).uniform(-0.12, 0.12, len(v)), v, color=ROLE[m][0], s=16, zorder=3)
            ax.plot([k - 0.25, k + 0.25], [v.mean()] * 2, color=INK, lw=1.2)
        ax.set_xticks(range(len(keys))); ax.set_xticklabels([k.replace("GP-", "GP\n").replace("-comp", "\ncomp") for k in keys], fontsize=7)
        ax.set_title(DATASET_SHORT[d]); ax.set_ylabel("MAE per repeat (5 repeats)") if j == 0 else None
        ax = axs[1, j]
        for k, m in enumerate([BASE, PROP, "ET-comp"]):
            for q, (sch, hatch, al) in enumerate((("random", "", 0.35), ("grouped_canonical", "", 0.75), ("grouped_composition", "///", 0.55))):
                r = PS[(PS.dataset == d) & (PS.model == m) & (PS.scheme == sch)]
                if r.empty: continue
                r = r.iloc[0]
                ax.bar(k + (q - 1) * 0.27, r.MAE_mean, 0.26, color=ROLE[m][0], alpha=al, hatch=hatch, edgecolor="white",
                       yerr=[[r.MAE_mean - r.MAE_ci_lo], [r.MAE_ci_hi - r.MAE_mean]], capsize=2, ecolor=INK2)
        ax.set_xticks(range(3)); ax.set_xticklabels(["GP original", "GP proposed", "ExtraTrees"], fontsize=7)
        ax.set_ylabel("MAE by validation protocol") if j == 0 else None
    axs[1, 2].legend(handles=[plt.Rectangle((0, 0), 1, 1, color=GREY, alpha=0.35), plt.Rectangle((0, 0), 1, 1, color=GREY, alpha=0.75),
                              plt.Rectangle((0, 0), 1, 1, color=GREY, alpha=0.55, hatch="///")],
                     labels=["random K-fold (leaky)", "twin-aware", "composition held out"], fontsize=6.5, loc="upper left")
    for ax, s in zip(axs.ravel(), "abcdef"): panel_label(ax, s)
    fig.tight_layout(); export("fig14_per_repeat_mae", F[F.dataset.isin(DS) & F.model.isin(keys)].groupby(["dataset", "model", "repeat"]).MAE.mean().reset_index())
    export("fig14_protocol_summary", PS[PS.dataset.isin(DS)]); save(fig, "fig14_robustness_repeats_and_protocols")


def fig15():
    sc = pd.read_csv(CSV / "screening_predictions.csv")
    fig, axs = plt.subplots(1, 3, figsize=(11.5, 3.9))
    for ax, d, nm in zip(axs[:2], ("eff_p", "eff_n"), ("P-doped", "N-doped")):
        g = P[(P.dataset == d) & (P.model == PROP)].groupby("structure").agg(y=("y_true", "first"), p=("y_pred", "mean"), s=("y_sigma", "mean")).reset_index()
        ax.errorbar(g.y, g.p, yerr=1.96 * g.s, fmt="s", color=BLUE, ms=3.5, alpha=0.7, elinewidth=0.5, capsize=0)
        lim = [0, max(g.y.max(), g.p.max()) * 1.05]; ax.plot(lim, lim, ls="--", color=INK2, lw=0.8)
        ax.set_xlabel(f"Reference EFF$_{{max}}$ ({nm})"); ax.set_ylabel("Out-of-fold prediction ± 95% interval"); ax.set_title(f"{nm}: held-out predictions")
    ax = axs[2]
    seen = sc.eff_p_in_dataset & sc.eff_n_in_dataset
    ax.errorbar(sc[seen].eff_n_pred, sc[seen].eff_p_pred, xerr=1.96 * sc[seen].eff_n_sigma, yerr=1.96 * sc[seen].eff_p_sigma, fmt="o", color="#9a9993", ms=3, elinewidth=0.4, label="in both datasets")
    un = sc[~seen]
    ax.errorbar(un.eff_n_pred, un.eff_p_pred, xerr=1.96 * un.eff_n_sigma, yerr=1.96 * un.eff_p_sigma, fmt="D", color=ORANGE, ms=5, elinewidth=0.8, label="no reference value (model-generated)")
    for _, r in un.nlargest(3, "eff_p_pred").iterrows():
        ax.annotate(r.structure, (r.eff_n_pred, r.eff_p_pred), xytext=(3, 3), textcoords="offset points", fontsize=6)
    ax.set_xlabel("Predicted N-doped EFF$_{max}$"); ax.set_ylabel("Predicted P-doped EFF$_{max}$"); ax.set_title("All 126 unique stacks (predictions)")
    ax.legend(fontsize=6.5, loc="lower right")
    for a, s in zip(axs, "abc"): panel_label(a, s)
    fig.tight_layout(); export("fig15_screening_predictions", sc)
    export("fig15_heldout_predictions", P[P.dataset.isin(["eff_p", "eff_n"]) & (P.model == PROP)].groupby(["dataset", "structure"]).agg(reference=("y_true", "first"), prediction=("y_pred", "mean"), sigma=("y_sigma", "mean")).reset_index())
    save(fig, "fig15_eff_predictions_n_vs_p_doping")


def fig16_17():
    PR = pd.read_csv(CSV / "curves_oof_predictions.csv")
    PW = pd.read_csv(CSV / "curves_pointwise_mse.csv")
    CS = pd.read_csv(CSV / "metrics_curves_summary.csv")
    bm, pm_ = "Indep-GP-original", "Shared-GP-comp"
    sub = PR[PR.model.isin([bm, pm_])]
    err = sub.assign(e=(sub.y_pred_eV - sub.y_true_eV) ** 2).groupby(["model", "structure"]).e.mean().unstack(0)
    err["diff"] = err[pm_] - err[bm]
    ex = [err[pm_].sub(err[pm_].median()).abs().idxmin(), err[pm_].idxmax()]
    xax = np.loadtxt(ROOT / "data" / "original" / "xaxisvalue.txt")
    fig, axs = plt.subplots(1, 3, figsize=(11.5, 3.8))
    for ax, s_, ttl in zip(axs[:2], ex, ("median-error structure", "largest-error structure")):
        for br, ls_ in (("CBM", "-"), ("VBM", "-")):
            t = PR[(PR.model == pm_) & (PR.structure == s_) & (PR.branch == br)].sort_values("k_index")
            ax.plot(xax, t.y_true_eV, color=INK, lw=2, label="Reference" if br == "CBM" else None)
            for m, col, ls in ((bm, ORANGE, "--"), (pm_, BLUE, "-")):
                q = PR[(PR.model == m) & (PR.structure == s_) & (PR.branch == br)].sort_values("k_index")
                ax.plot(xax, q.y_pred_eV, color=col, ls=ls, lw=1.3, label=(lab(BASE) if m == bm else "Shared GP, composition") if br == "CBM" else None)
        ax.set_title(f"{s_} ({ttl})", fontsize=8); ax.set_xlabel("Path coordinate (reciprocal units)"); ax.set_ylabel("Energy (eV)")
    axs[0].legend(fontsize=6.5)
    ax = axs[2]
    pw = PW.groupby(["model", "point"]).sq_err.mean().apply(np.sqrt).reset_index()
    for m, col in ((bm, ORANGE), (pm_, BLUE), ("ET-comp", AQUA), ("PCA6-GP-comp", VIOLET)):
        g = pw[pw.model == m]
        ax.plot(g.point, g.sq_err, color=col, label=m, marker="o", ms=2.5)
    ax.axvline(29.5, color=INK2, lw=0.6, ls=":"); ax.text(14, ax.get_ylim()[1] * 0.97, "CBM", ha="center", fontsize=7, va="top"); ax.text(44, ax.get_ylim()[1] * 0.97, "VBM", ha="center", fontsize=7, va="top")
    ax.set_xlabel("Band-point index (0–29 CBM, 30–59 VBM)"); ax.set_ylabel("RMSE (eV)"); ax.legend(fontsize=6.5)
    for a, s in zip(axs, "abc"): panel_label(a, s)
    fig.tight_layout(); export("fig16_pointwise_rmse", pw); export("fig16_example_curves", PR[PR.structure.isin(ex) & PR.model.isin([bm, pm_])]); save(fig, "fig16_band_structure_curve_predictions")
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.6))
    cs = CS.sort_values("RMSE", ascending=False)
    for ax, col_, ttl in zip(axs, ("RMSE", "gap_MAE", "fit_time_s"), ("Curve RMSE (eV)", "Band-gap MAE from curves (eV)", "Mean fit time (s)")):
        colors = [ORANGE if m == bm else BLUE if m == pm_ else "#9a9993" for m in cs.model]
        ax.barh(cs.model, cs[col_], color=colors); ax.set_xlabel(ttl)
        if col_ == "fit_time_s": ax.set_xscale("log")
    for a, s in zip(axs, "abc"): panel_label(a, s)
    fig.tight_layout(); export("fig17_curve_model_comparison", CS); save(fig, "fig17_curve_model_comparison")


def fig18():
    from data_preprocessing import load_dataset
    bg, en = load_dataset("band_gap"), load_dataset("eff_n")
    tw = pd.read_csv(CSV / "data_audit_twin_consistency.csv")
    cc = pd.read_csv(CSV / "data_audit_bandstructure_vs_gap.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.6, 7))
    ax = axs[0, 0]; ax.hist(bg.y, bins=30, color=BLUE); ax.set_xlabel("Band gap (eV)"); ax.set_ylabel("Structures")
    ax.set_title(f"{int((bg.y == 0).sum())} of {len(bg.y)} gaps are exactly 0 (clamped)", fontsize=8)
    ax = axs[0, 1]; ax.scatter(tw.gap1, tw.gap2, s=14, color=AQUA, edgecolor="white", lw=0.3); ax.plot([0, 1.6], [0, 1.6], color=INK2, ls="--", lw=0.8)
    ax.set_xlabel("Band gap, stack orientation 1 (eV)"); ax.set_ylabel("Band gap, reversed stack (eV)")
    ax.set_title(f"{len(tw)} reversed-stack twin pairs (median |Δ| = {tw.abs_diff.median():.3f} eV)", fontsize=8)
    ax = axs[1, 0]; ax.hist(np.log10(en.y), bins=40, color=ORANGE); ax.set_xlabel("log$_{10}$ N-doped EFF$_{max}$"); ax.set_ylabel("Structures")
    for v in (946.467, 26710.05): ax.axvline(np.log10(v), color=INK, ls=":", lw=1)
    ax.set_title("Two extreme N-doped values (946 and 26710)", fontsize=8)
    ax = axs[1, 1]; ax.scatter(cc.gap_file, cc.gap_from_curves, s=14, color=VIOLET, edgecolor="white", lw=0.3)
    ax.plot([-0.9, 1.6], [-0.9, 1.6], color=INK2, ls="--", lw=0.8); ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xlabel("Band gap in 3-layer-band_gap.txt (eV)"); ax.set_ylabel("min(CBM) − max(VBM) from curve file (eV)")
    ax.set_title("File gap = max(0, curve gap)", fontsize=8)
    for a, s in zip(axs.ravel(), "abcd"): panel_label(a, s)
    fig.tight_layout(); export("fig18_band_gap_values", pd.DataFrame(dict(structure=bg.frame["structure"].values, band_gap=bg.y)))
    export("fig18_twin_pairs", tw); export("fig18_gap_file_vs_curves", cc); export("fig18_eff_n_values", pd.DataFrame(dict(structure=en.frame["structure"].values, eff_n=en.y)))
    save(fig, "fig18_data_audit")


def fig19():
    Sn = pd.read_csv(CSV / "metrics_bo_sensitivity.csv")
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.5))
    for ax, pref, xs, xl in ((axs[0], "ei_xi", None, "EI exploration offset $\\xi$ (fraction of sd of observed y)"), (axs[1], "ucb_beta", None, "UCB $\\beta$")):
        for d, col in zip(BO_DS, (BLUE, ORANGE, AQUA)):
            g = Sn[(Sn.dataset == d) & Sn.label.str.startswith(pref)].copy()
            g["x"] = g.label.str.replace(pref, "", regex=False).astype(float); g = g.sort_values("x")
            ax.plot(range(len(g)), g.p_optimum, marker="o", color=col, label=BO_DS_TITLE[d].split(" (")[0])
            ax.set_xticks(range(len(g))); ax.set_xticklabels(g.x.astype(str))
        ax.set_xlabel(xl); ax.set_ylim(0, 1.05)
    axs[0].set_ylabel("P(global optimum evaluated)"); axs[0].legend(fontsize=7)
    for a, s in zip(axs, "ab"): panel_label(a, s)
    fig.tight_layout(); export("fig19_bo_hyperparameter_sensitivity", Sn); save(fig, "fig19_bo_hyperparameter_sensitivity")


if __name__ == "__main__":
    which = sys.argv[1:] or ["1", "2", "3", "4", "5", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "18", "19"]
    fn = {"1": fig01, "2": fig02, "3": fig03, "4": fig04, "5": fig05_06, "7": fig07, "8": fig08, "9": fig09, "10": fig10, "11": fig11,
          "12": fig12, "13": fig13, "14": fig14, "15": fig15, "16": fig16_17, "18": fig18, "19": fig19}
    for k in which:
        try:
            fn[k](); print("figure", k, "ok", flush=True)
        except Exception as e:
            import traceback; traceback.print_exc(); print("figure", k, "FAILED", e, flush=True)
