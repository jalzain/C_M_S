#!/usr/bin/env python3
"""Bayesian-optimisation experiments (pool-based, paired seeds).  Resumable (per-run cache in results/csv/raw_bo/).

    python scripts/run_bo_experiments.py [--stages main sensitivity ablation] [--jobs 2] [--quick]
"""
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(v, "1")
import argparse, sys, time, warnings
from pathlib import Path
import numpy as np, pandas as pd, yaml
from joblib import Parallel, delayed

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
from data_preprocessing import load_dataset, build_features
from improved_models import canonical_orientation
from bayesian_optimization import run_bo, summarise_history

RAW = Path(os.environ.get("LMR_RAW_BO", ROOT / "results" / "csv" / "raw_bo"))
RAW.mkdir(parents=True, exist_ok=True)

# objective transform for the *surrogate* only (all reported values are raw)
Y_TRANSFORM = {"band_gap": "identity", "eff_p": "identity", "eff_n_full": "log10"}


def get_pool(name):
    """Candidate pool.  band_gap: 105 stack-reversal-unique structures (twin values averaged)."""
    if name == "band_gap":
        ds = load_dataset("band_gap")
        f = canonical_orientation(ds.frame).copy()
        f["target"] = ds.y
        g = f.groupby("canonical", sort=False)
        frame = g.first().reset_index()
        y = g["target"].mean().loc[frame["canonical"]].values
        frame["structure"] = frame["canonical"]
    else:
        ds = load_dataset("eff_p" if name == "eff_p" else "eff_n")
        frame, y = ds.frame.reset_index(drop=True), ds.y
    return frame, np.asarray(y, float)


def features(frame, kind):
    return build_features(frame, {"comp": "composition", "pos": "positional"}[kind])


def one_run(tag, dataset, method, seed, n_iter, n_init_frac, feat="comp", ard=False, xi_frac=0.01, beta=2.0,
            restarts=1, orig_restarts=40, label=None):
    label = label or method
    path = RAW / f"{tag}__{dataset}__{label}__seed{seed}.csv"
    if path.exists():
        return
    warnings.filterwarnings("ignore")
    frame, y = get_pool(dataset)
    X = features(frame, "pos" if method == "orig_ei" else feat)
    n_init = int(n_init_frac * len(y))
    H = run_bo(X, y, frame["structure"].values, method, n_init, n_iter, seed, Y_TRANSFORM[dataset], xi_frac, beta,
               restarts, orig_restarts, ard=ard)
    S = summarise_history(H, y)
    H["dataset"], H["tag"], H["label"] = dataset, tag, label
    H["pool_size"] = len(y)
    for k in ("xi_frac", "beta"):
        H[k] = locals()[k]
    H["reported_best_original"] = H.attrs.get("reported_best_original", np.nan)
    H.to_csv(path, index=False)


def stage_main(cfg, jobs, quick=False):
    b = cfg["bayesian_optimization"]
    tasks = []
    for d in b["datasets"]:
        for m in b["methods"]:
            ns = b["random_seeds"] if m == "random" else (b["orig_seeds"] if m == "orig_ei" else b["seeds"])
            for s in range(ns):
                tasks.append(("main", d, m, s, b["n_iterations"], b["n_init_fraction"]))
    # long (orig) tasks first for better load balancing
    tasks.sort(key=lambda t: 0 if t[2] == "orig_ei" else 1)
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(one_run)(*t) for t in tasks)


def stage_sensitivity(cfg, jobs, quick=False):
    b = cfg["bayesian_optimization"]
    tasks = []
    for d in b["datasets"]:
        for s in range(b["sensitivity_seeds"]):
            for xi in b["xi_fracs"]:
                tasks.append(("sens", d, "ei", s, b["n_iterations"], b["n_init_fraction"], "comp", False, xi, 2.0, 1, 40, f"ei_xi{xi}"))
            for be in b["betas"]:
                tasks.append(("sens", d, "ucb", s, b["n_iterations"], b["n_init_fraction"], "comp", False, 0.01, be, 1, 40, f"ucb_beta{be}"))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(one_run)(*t) for t in tasks)


def stage_ablation(cfg, jobs, quick=False):
    """Separate surrogate effects from acquisition-logic effects."""
    b = cfg["bayesian_optimization"]
    tasks = []
    for d in b["datasets"]:
        for s in range(b["seeds"]):
            tasks.append(("abl", d, "orig_ei_impgp", s, b["n_iterations"], b["n_init_fraction"], "comp", False, 0.01, 2.0, 1, 40, "origacq_on_improvedGP"))
        for s in range(b["positional_seeds"]):
            tasks.append(("abl", d, "ei", s, b["n_iterations"], b["n_init_fraction"], "pos", True, 0.01, 2.0, 1, 40, "ei_positionalARD"))
        for s in range(b["seeds"]):
            tasks.append(("abl", d, "ei", s, b["n_iterations"], b["n_init_fraction"], "comp", True, 0.01, 2.0, 1, 40, "ei_compARD"))
            tasks.append(("abl", d, "ucb", s, b["n_iterations"], b["n_init_fraction"], "comp", True, 0.01, 2.0, 1, 40, "ucb_compARD"))
            tasks.append(("abl", d, "ts", s, b["n_iterations"], b["n_init_fraction"], "comp", True, 0.01, 2.0, 1, 40, "ts_compARD"))
    Parallel(n_jobs=jobs, verbose=5 if jobs > 1 else 0)(delayed(one_run)(*t) for t in tasks)


def consolidate():
    out = ROOT / "results" / "csv"
    hist, summ = [], []
    for f in sorted(RAW.glob("*__seed*.csv")):
        H = pd.read_csv(f)
        hist.append(H)
        y_all = get_pool(H["dataset"].iloc[0])[1]
        Hs = H.copy(); Hs["method"] = H["label"]
        S = summarise_history(Hs, y_all)
        S.update(dataset=H["dataset"].iloc[0], tag=H["tag"].iloc[0], label=H["label"].iloc[0],
                 xi_frac=H["xi_frac"].iloc[0], beta=H["beta"].iloc[0],
                 reported_best_original=H["reported_best_original"].iloc[0])
        if np.isfinite(S["reported_best_original"]):
            S["reported_minus_evaluated"] = S["reported_best_original"] - S["final_best"]
        summ.append(S)
    if hist:
        pd.concat(hist, ignore_index=True).to_csv(out / "bo_histories.csv", index=False)
        pd.DataFrame(summ).to_csv(out / "bo_run_summaries.csv", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", nargs="+", default=["main", "sensitivity", "ablation"])
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--config", default=str(ROOT / "config" / "experiment_config.yaml"))
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    if a.quick:
        if "LMR_RAW_BO" not in os.environ:
            sys.exit("--quick needs LMR_RAW_BO=<scratch dir>")
        b = cfg["bayesian_optimization"]
        b.update(datasets=["eff_p"], seeds=2, orig_seeds=1, n_iterations=4, sensitivity_seeds=1, positional_seeds=1,
                 methods=["random", "orig_ei", "ei", "pi", "ucb", "greedy", "ts"], xi_fracs=[0.0], betas=[1.0], random_seeds=3)
    fn = dict(main=stage_main, sensitivity=stage_sensitivity, ablation=stage_ablation)
    for s in a.stages:
        t0 = time.time(); print("=== BO stage", s, flush=True)
        fn[s](cfg, a.jobs)
        print(f"=== BO stage {s} done in {time.time()-t0:.0f}s", flush=True)
    if not a.quick:
        consolidate()


if __name__ == "__main__":
    main()
