#!/usr/bin/env python3
"""Execute the *unmodified* original scripts (baseline_original/) under a fixed RNG seed.

The original scripts use the global NumPy RNG without seeding, call ``plt.show()`` and write
figures into the working directory.  This wrapper (i) seeds the global RNG, (ii) selects the
non-interactive Agg backend, (iii) runs each script in a throw-away copy of the repository so the
original files are never touched, and (iv) stores stdout and a parsed summary in results/.

Usage:  python scripts/run_original_baseline.py [--seeds 0 1 2] [--which maxval bo structure]
"""
import argparse, os, re, runpy, shutil, sys, tempfile, time, io, contextlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ORIG = ROOT / "baseline_original"
DATA = ROOT / "data" / "original"
HDR = ROOT / "data" / "processed"
LOGS = ROOT / "results" / "logs"


def run_script(script, argv, seed, workdir):
    import matplotlib
    matplotlib.use("Agg")
    import numpy as np
    np.random.seed(seed)
    # NumPy >= 2.0 removed the top-level alias np.chararray used by the original scripts.
    # Compatibility shim only; the original source files are executed unmodified.
    if not hasattr(np, "chararray"):
        np.chararray = np.char.chararray
    old_cwd, old_argv = os.getcwd(), sys.argv
    os.chdir(workdir)
    sys.argv = [script] + argv
    buf = io.StringIO()
    t0 = time.time()
    status = "ok"
    try:
        with contextlib.redirect_stdout(buf):
            runpy.run_path(script, run_name="__main__")
    except Exception as e:  # record, do not hide
        status = f"{type(e).__name__}: {e}"
    finally:
        os.chdir(old_cwd)
        sys.argv = old_argv
    return buf.getvalue(), time.time() - t0, status


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--which", nargs="+", default=["maxval", "bo", "structure"])
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    summary = []
    for seed in a.seeds:
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            for f in list(ORIG.glob("*.py")) + list(DATA.glob("*.txt")):
                shutil.copy(f, td)
            for f in HDR.glob("*_with_header.txt"):
                shutil.copy(f, td)
            (td / "Bandstructure").mkdir()
            jobs = []
            if "maxval" in a.which:
                jobs.append(("predict_maxval", "predict_maxval.py", []))
            if "bo" in a.which:
                jobs.append(("BO_bandgap", "Bayesian_opt.py", ["3-layer-band_gap.txt"]))
                jobs.append(("BO_N_as_shipped", "Bayesian_opt.py", ["N_doped_EFF_max.txt"]))
                jobs.append(("BO_N", "Bayesian_opt.py", ["N_doped_EFF_max_with_header.txt"]))
                jobs.append(("BO_P", "Bayesian_opt.py", ["P_doped_EFF_max.txt"]))
            if "structure" in a.which:
                jobs.append(("predict_structure", "predict_structure.py", []))
            for name, script, argv in jobs:
                out, dt, status = run_script(script, argv, seed, td)
                (LOGS / f"original_{name}_seed{seed}.log").write_text(out)
                rec = dict(job=name, seed=seed, runtime_s=round(dt, 1), status=status)
                m = re.search(r"toterr  prediction loss :\s+([\d.eE+-]+)\s+([\d.eE+-]+)", out)
                if m:
                    rec["test_MAE"] = float(m.group(2))
                m = re.search(r"Total prediction errror:\s+([\d.eE+-]+)", out)
                if m:
                    rec["test_RMSE"] = float(m.group(1))
                m = re.search(r"Initial Best Strucuture:\s+(.+?)\s+has value:\s+([\d.eE+-]+)\s+Final Optimal Strucuture:\s+(.+?)\s+has value:\s+([\d.eE+-]+)", out)
                if m:
                    rec.update(init_struct=m.group(1), init_value=float(m.group(2)),
                               final_struct=m.group(3), final_value=float(m.group(4)))
                summary.append(rec)
                print(rec, flush=True)
    import pandas as pd
    out = ROOT / "results" / "csv" / "original_baseline_runs.csv"
    df = pd.DataFrame(summary)
    if out.exists():
        df = pd.concat([pd.read_csv(out), df]).drop_duplicates(["job", "seed"], keep="last")
    df.to_csv(out, index=False)


if __name__ == "__main__":
    main()
