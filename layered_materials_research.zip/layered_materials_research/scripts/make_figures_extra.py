#!/usr/bin/env python3
"""Additional figures 20-27 (workflow, structure schematic, correlations, distributions, fold-level statistics,
configuration heat maps, band dispersion + band-gap comparison, scaling).

Figures 20 and 21 are CONCEPTUAL illustrations (no measured data are plotted; panel 21c uses the feature code on two real
stacks).  All other figures are quantitative and are generated from files in results/csv or data/original; the numbers behind
each plot are written to figures/data/.   Run after analyze_results.py:   python scripts/make_figures_extra.py [20 21 ...]
"""
import sys, warnings
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
warnings.filterwarnings("ignore")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from scipy import stats
from plotting import *
from registry import get_dataset
from data_preprocessing import build_features, load_dataset
from statistical_analysis import bootstrap_ci

style()
CSV = ROOT / "results" / "csv"
BASE, PROP = "GP-original", "GP-comp-ARD-M15"
DS = ("band_gap", "eff_p", "eff_n")
COMP_NAMES = ["metal mean EN", "metal mean IP", "metal range EN", "metal range IP", "chalc. mean EN", "chalc. mean IP",
              "chalc. range EN", "chalc. range IP", "frac. W", "frac. S", "frac. Se"]
EL_COL = {"Mo": "#6250d6", "W": "#52514e", "S": "#eda100", "Se": "#1baf7a", "Te": "#e34948"}
TMD = ["MoS", "MoSe", "MoTe", "WS", "WSe", "WTe"]
F = pd.read_csv(CSV / "regression_main_folds.csv")
P = pd.read_csv(CSV / "regression_main_pred.csv")


def box(ax, xy, w, h, text, fc="#eef3fb", ec=BLUE, fs=7.5):
    ax.add_patch(FancyBboxPatch(xy, w, h, boxstyle="round,pad=0.012,rounding_size=0.015", fc=fc, ec=ec, lw=1.1))
    ax.text(xy[0] + w / 2, xy[1] + h / 2, text, ha="center", va="center", fontsize=fs, wrap=True)


def arrow(ax, a, b, **kw):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=10, lw=1.0, color=INK2, **kw))


# ------------------------------------------------------------------ 20 workflow (conceptual)
def fig20():
    fig, ax = plt.subplots(figsize=(11.5, 6.4)); ax.set_axis_off(); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.text(0.005, 0.995, "Conceptual workflow (no data plotted)", fontsize=8, style="italic", va="top", color=INK2)
    W, H = 0.172, 0.15
    top = [(0.005, "Original data files\n(band gap, band structure,\nN-/P-doped EFF$_{max}$)", "#eef3fb", BLUE),
           (0.205, "Data audit\ntwins, clamped gaps,\noutliers, headers", "#fdf1e9", ORANGE),
           (0.405, "Representations\npositional | symmetric |\ncomposition (11-D)", "#eef3fb", BLUE),
           (0.605, "Validation protocols\ntwin-aware | composition-\nheld-out | random", "#eef3fb", BLUE),
           (0.805, "Models\nGP variants, RF/ET/GBR,\nSVR/KRR/ridge/kNN", "#eef3fb", BLUE)]
    for x, t, fc, ec in top: box(ax, (x, 0.80), W, H, t, fc=fc, ec=ec, fs=7)
    for x in (0.005, 0.205, 0.405, 0.605): arrow(ax, (x + W + 0.002, 0.875), (x + 0.2 - 0.002, 0.875))
    box(ax, (0.605, 0.575), W, H, "Metrics and statistics\nMAE, RMSE, $R^2$, NLL,\ncoverage; Wilcoxon-Holm,\nNadeau-Bengio", fc="#e8f6f0", ec=AQUA, fs=7)
    box(ax, (0.805, 0.575), W, H, "Regression experiments\nablation, kernels, learning\ncurves, restarts, scaling,\nband curves", fc="#e8f6f0", ec=AQUA, fs=7)
    arrow(ax, (0.891, 0.80), (0.891, 0.727)); arrow(ax, (0.805, 0.65), (0.779, 0.65))
    ax.plot([0.005, 0.995], [0.505, 0.505], color="#d8d7d1", lw=0.8)
    ax.text(0.005, 0.475, "Pool-based Bayesian optimisation (paired seeds)", fontsize=8, weight="bold")
    bo = [(0.005, "Finite candidate pool\n(105 / 115 / 116 stacks)"), (0.205, "Random initial design\n(10% of the pool)"), (0.405, "Fit GP surrogate\n(composition features)"),
          (0.605, "Acquisition: EI, PI, UCB,\ngreedy, Thompson; random;\noriginal-EI replica"), (0.805, "Evaluate selected stack\n(look-up of the\nreference value)")]
    for x, t in bo: box(ax, (x, 0.27), W, H, t, fc="#f1eefb", ec=VIOLET, fs=7)
    for x in (0.005, 0.205, 0.405, 0.605): arrow(ax, (x + W + 0.002, 0.345), (x + 0.2 - 0.002, 0.345))
    ax.add_patch(FancyArrowPatch((0.891, 0.268), (0.491, 0.268), connectionstyle="arc3,rad=-0.3", arrowstyle="-|>", mutation_scale=10, lw=1.0, color=INK2, ls="--"))
    ax.text(0.69, 0.185, "repeat for 30 iterations", fontsize=7, ha="center", color=INK2)
    arrow(ax, (0.091, 0.80), (0.091, 0.42)); ax.text(0.10, 0.62, "pool built\nfrom data", fontsize=6.5, color=INK2)
    box(ax, (0.005, 0.02), 0.30, 0.10, "BO metrics: P(optimum evaluated), rank of best,\nevaluations to optimum; Wilson CIs; Holm tests", fc="#e8f6f0", ec=AQUA, fs=7)
    box(ax, (0.335, 0.02), 0.30, 0.10, "BO ablations: surrogate vs acquisition,\nARD, $\\xi$ and $\\beta$ sensitivity", fc="#e8f6f0", ec=AQUA, fs=7)
    box(ax, (0.665, 0.02), 0.33, 0.10, "Tables, figures (PNG/PDF), CSV,\nLaTeX manuscript", fc="#f5f4f0", ec=GREY, fs=7)
    save(fig, "fig20_workflow_flowchart")


# ------------------------------------------------------------------ 21 structure schematic (conceptual)
def draw_layer(ax, y0, metal, chal, n=4, a=1.0, h=0.55):
    for k in range(n):
        xm = k * a
        ax.add_patch(Circle((xm, y0), 0.17, color=EL_COL[metal], zorder=3))
        if k < n - 1 or True:
            xc = xm + a / 2
            for dy in (h, -h):
                ax.add_patch(Circle((xc, y0 + dy), 0.13, color=EL_COL[chal], zorder=3))
                for xx in (xm, xm + a):
                    if xx <= (n - 1) * a + 1e-9:
                        ax.plot([xx, xc], [y0, y0 + dy], color="#b9b8b2", lw=1.0, zorder=1)


def split_name(s):
    return ("Mo" if s.startswith("Mo") else "W", s[2:] if s.startswith("Mo") else s[1:])


def fig21():
    bg = load_dataset("band_gap").frame
    tw = bg.groupby("canonical").filter(lambda g: len(g) == 2 and g.structure.nunique() == 2)
    c = "MoS-WSe-MoTe" if "MoS-WSe-MoTe" in set(tw.canonical) else tw.canonical.iloc[0]
    pair = tw[tw.canonical == c].sort_values("structure").drop_duplicates("structure")
    names = list(pair.structure)
    Xp = build_features(pair.reset_index(drop=True), "positional"); Xc = build_features(pair.reset_index(drop=True), "composition")
    fig = plt.figure(figsize=(11.5, 4.2)); gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.0, 1.5], wspace=0.4)
    ax = fig.add_subplot(gs[0]); ax.set_aspect("equal"); ax.set_axis_off(); ax.grid(False)
    stack = names[0].split("-")
    for i, (s, y0) in enumerate(zip(stack, (4.3, 2.2, 0.1))):
        m, ch = split_name(s); draw_layer(ax, y0, m, ch)
        ax.text(3.9, y0, s, fontsize=8, va="center")
        if i < 2: ax.plot([-0.3, 3.8], [y0 - 1.05] * 2, color=GREY, lw=0.6, ls=":")
    ax.text(-0.3, -0.9, "van der Waals gaps (dotted)", fontsize=6.5, color=INK2)
    ax.set_xlim(-0.5, 5.2); ax.set_ylim(-1.1, 5.2)
    ax.set_title(f"Side-view schematic of {names[0]}\n(conceptual, not a DFT geometry)", fontsize=8)
    ax.legend(handles=[Circle((0, 0), 1, color=EL_COL[e], label=e) for e in EL_COL], fontsize=6.5, ncol=5, loc="lower center", bbox_to_anchor=(0.5, -0.12), handletextpad=0.2, columnspacing=0.6)
    ax2 = fig.add_subplot(gs[1]); ax2.set_axis_off(); ax2.set_xlim(0, 1); ax2.set_ylim(0, 1)
    for k, (nm, x0) in enumerate(zip(names, (0.05, 0.55))):
        for i, (s, y0) in enumerate(zip(nm.split("-"), (0.62, 0.40, 0.18))):
            m, ch = split_name(s)
            ax2.add_patch(FancyBboxPatch((x0, y0), 0.38, 0.16, boxstyle="round,pad=0.01", fc=EL_COL[ch], ec=EL_COL[m], lw=2.5, alpha=0.85))
            ax2.text(x0 + 0.19, y0 + 0.08, s, ha="center", va="center", fontsize=7.5, color="white", weight="bold")
        ax2.text(x0 + 0.19, 0.85, f"orientation {k+1}", ha="center", fontsize=7.5)
    ax2.text(0.5, 0.06, "reversed stacks: same physical structure", ha="center", fontsize=7.5, style="italic")
    ax2.set_title("Layer-reversal twins", fontsize=8)
    ax3 = fig.add_subplot(gs[2])
    pad = np.full((2, 1), np.nan); Zp = np.hstack([np.vstack([Xc[0], Xc[1]]), pad])
    M = np.vstack([np.vstack([Xp[0], Xp[1]]), Zp])
    im = ax3.imshow(M, aspect="auto", cmap="viridis"); ax3.grid(False)
    cb = fig.colorbar(im, ax=ax3, fraction=0.05, pad=0.02); cb.set_label("min-max scaled descriptor value", fontsize=7); cb.ax.tick_params(labelsize=6.5)
    ax3.axhline(1.5, color="white", lw=3)
    ax3.set_yticks(range(4)); ax3.set_yticklabels(["positional 1", "positional 2", "composition 1", "composition 2"], fontsize=7)
    ax3.set_xticks(range(12)); ax3.set_xticklabels(range(1, 13), fontsize=6.5)
    same = np.allclose(Xc[0], Xc[1]); diff = not np.allclose(Xp[0], Xp[1])
    assert same and diff
    ax3.set_title("Feature vectors of the two orientations\n(composition rows coincide; positional rows differ)", fontsize=8)
    ax3.set_xlabel("feature index (positional: 1-12; composition: 1-11)", fontsize=7.5)
    for a, s in zip((ax, ax2, ax3), "abc"): panel_label(a, s)
    export("fig21_feature_vectors_example", pd.DataFrame(dict(stack=[names[0]] * 12 + [names[1]] * 12, kind="positional", index=list(range(12)) * 2, value=np.concatenate([Xp[0], Xp[1]])))
           .pipe(lambda d: pd.concat([d, pd.DataFrame(dict(stack=[names[0]] * 11 + [names[1]] * 11, kind="composition", index=list(range(11)) * 2, value=np.concatenate([Xc[0], Xc[1]])))])))
    save(fig, "fig21_stack_schematic_and_twins")


# ------------------------------------------------------------------ 22 correlations
def fig22():
    bg = get_dataset("band_gap"); fr = bg.frame.drop_duplicates("canonical").reset_index(drop=True)
    Xf = pd.DataFrame(build_features(fr, "composition"), columns=COMP_NAMES)
    Cf = Xf.corr(method="spearman").fillna(0)
    rows, T = [], {}
    for d in DS:
        ds = get_dataset(d); X = pd.DataFrame(build_features(ds.frame, "composition"), columns=COMP_NAMES)
        T[d] = [stats.spearmanr(X[c], ds.y)[0] if X[c].std() > 0 else np.nan for c in COMP_NAMES]
        rows += [dict(dataset=d, feature=c, spearman=v, n=len(ds.y)) for c, v in zip(COMP_NAMES, T[d])]
    fig = plt.figure(figsize=(13, 4.6)); gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.15, 0.9], wspace=0.9)
    ax = fig.add_subplot(gs[0]); im = ax.imshow(Cf.values, cmap="RdBu_r", vmin=-1, vmax=1); ax.grid(False)
    ax.set_xticks(range(11)); ax.set_xticklabels(COMP_NAMES, rotation=70, ha="right", fontsize=6.5); ax.set_yticks(range(11)); ax.set_yticklabels(COMP_NAMES, fontsize=6.5)
    fig.colorbar(im, ax=ax, fraction=0.046, label="Spearman $\\rho$"); ax.set_title("Composition descriptors (105 stacks)", fontsize=8)
    ax = fig.add_subplot(gs[1]); Tm = np.array([T[d] for d in DS]); im = ax.imshow(Tm, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto"); ax.grid(False)
    ax.set_xticks(range(11)); ax.set_xticklabels(COMP_NAMES, rotation=70, ha="right", fontsize=6.5)
    ax.set_yticks(range(3)); ax.set_yticklabels(["band gap", "P-doped EFF", "N-doped EFF"], fontsize=7)
    for i in range(3):
        for j in range(11):
            if np.isfinite(Tm[i, j]): ax.text(j, i, f"{Tm[i,j]:.2f}", ha="center", va="center", fontsize=5.5, color="white" if abs(Tm[i, j]) > 0.6 else INK)
    ax.set_title("Descriptor-target correlation", fontsize=8); fig.colorbar(im, ax=ax, fraction=0.046, label="Spearman $\\rho$")
    ax = fig.add_subplot(gs[2]); ep, en = get_dataset("eff_p"), get_dataset("eff_n")
    m = pd.DataFrame(dict(structure=ep.frame.structure, p=ep.y, te=ep.frame.has_Te)).merge(pd.DataFrame(dict(structure=en.frame.structure, n=en.y)), on="structure")
    rho = stats.spearmanr(m.p, m.n)[0]
    for te, col, nm in ((False, BLUE, "no Te"), (True, ORANGE, "contains Te")):
        g = m[m.te == te]; ax.scatter(g.n, g.p, s=14, color=col, alpha=0.8, edgecolor="white", lw=0.3, label=nm)
    ax.set_xlabel("N-doped EFF$_{max}$ (reference)"); ax.set_ylabel("P-doped EFF$_{max}$ (reference)")
    ax.set_title(f"{len(m)} common stacks\nSpearman $\\rho$ = {rho:.2f}", fontsize=8, pad=14); ax.legend(fontsize=6.5)
    for a, s in zip(fig.axes[::1], "a bcd"[:0]): pass
    for a, s in zip([fig.axes[0], fig.axes[2], fig.axes[4]], "abc"): panel_label(a, s)
    export("fig22_descriptor_correlation_matrix", Cf.reset_index(names="feature")); export("fig22_descriptor_target_correlation", pd.DataFrame(rows))
    export("fig22_eff_n_vs_p_reference", m); save(fig, "fig22_correlation_analysis")


# ------------------------------------------------------------------ 23 distributions
def metal_class(s):
    ms = [("Mo" if p.startswith("Mo") else "W") for p in s.split("-")]
    return "all Mo" if set(ms) == {"Mo"} else "all W" if set(ms) == {"W"} else "mixed Mo/W"


def fig23():
    fig, axs = plt.subplots(2, 3, figsize=(11, 6.4)); rows = []
    ttl = {"band_gap": "Band gap (eV)", "eff_p": "P-doped EFF$_{max}$", "eff_n": "N-doped EFF$_{max}$ (outliers removed)"}
    for j, d in enumerate(DS):
        ds = get_dataset(d); f = ds.frame.copy(); f["y"] = ds.y
        if d == "band_gap": f = f.drop_duplicates("canonical")
        f["nTe"] = f[["X1", "X2", "X3"]].eq("Te").sum(1); f["mc"] = f.structure.map(metal_class)
        ax = axs[0, j]; groups = [f[f.nTe == k].y.values for k in range(4)]; ok = [k for k, g in enumerate(groups) if len(g) > 1]
        vp = ax.violinplot([groups[k] for k in ok], positions=ok, showextrema=False, widths=0.8)
        for b in vp["bodies"]: b.set_facecolor(BLUE); b.set_alpha(0.3)
        ax.boxplot([groups[k] for k in ok], positions=ok, widths=0.22, showfliers=True, flierprops=dict(ms=2.5), medianprops=dict(color=ORANGE), boxprops=dict(color=INK2), whiskerprops=dict(color=INK2), capprops=dict(color=INK2))
        ax.set_xticks(range(4)); ax.set_xticklabels([f"{k}\n(n={len(groups[k])})" for k in range(4)], fontsize=7); ax.set_xlabel("Number of Te-containing layers"); ax.set_title(ttl[d], fontsize=9)
        ax = axs[1, j]; xs = np.linspace(f.y.min(), f.y.max(), 200)
        for mc, col in (("all Mo", VIOLET), ("all W", GREY), ("mixed Mo/W", AQUA)):
            v = f[f.mc == mc].y.values
            if len(v) > 3 and v.std() > 0:
                ax.plot(xs, stats.gaussian_kde(v)(xs), color=col, label=f"{mc} (n={len(v)})"); ax.fill_between(xs, stats.gaussian_kde(v)(xs), color=col, alpha=0.12)
        ax.set_xlabel(ttl[d]); ax.legend(fontsize=6.5)
        rows.append(f[["structure", "y", "nTe", "mc"]].assign(dataset=d))
        if j == 0: axs[0, 0].set_ylabel("Target value"); axs[1, 0].set_ylabel("Kernel density estimate")
    for a, s in zip(axs.ravel(), "abcdef"): panel_label(a, s)
    fig.tight_layout(); export("fig23_target_distributions", pd.concat(rows)); save(fig, "fig23_target_distributions")


# ------------------------------------------------------------------ 24 fold-level distributions
def fig24():
    st = pd.read_csv(CSV / "stats_main_paired_vs_original_MAE.csv")
    models = [BASE, PROP, "RF-comp", "ET-comp", "GBR-comp"]; cmp_ = [PROP, "RF-comp", "GBR-comp"]
    fig, axs = plt.subplots(2, 3, figsize=(11, 6.2)); rows, drows = [], []
    for j, d in enumerate(DS):
        f = F[(F.dataset == d) & (F.scheme == "grouped_canonical")]
        ax = axs[0, j]; data = [f[f.model == m].MAE.values for m in models]
        vp = ax.violinplot(data, showextrema=False, widths=0.8)
        for b, m in zip(vp["bodies"], models): b.set_facecolor(ROLE[m][0]); b.set_alpha(0.35)
        ax.boxplot(data, widths=0.2, showfliers=False, medianprops=dict(color=INK), boxprops=dict(color=INK2), whiskerprops=dict(color=INK2), capprops=dict(color=INK2))
        ax.set_xticks(range(1, 6)); ax.set_xticklabels(["GP\noriginal", "GP\ncomp.", "RF", "ET", "GBR"], fontsize=7); ax.set_title({"band_gap": "Band gap", "eff_p": "P-doped EFF", "eff_n": "N-doped EFF"}[d], fontsize=9)
        rows += [dict(dataset=d, model=m, MAE=v) for m, vs in zip(models, data) for v in vs]
        ax = axs[1, j]; b0 = f[f.model == BASE].set_index(["repeat", "fold"]).MAE
        for k, m in enumerate(cmp_):
            diff = (f[f.model == m].set_index(["repeat", "fold"]).MAE - b0).dropna()
            ax.scatter(np.full(len(diff), k) + np.random.RandomState(k).uniform(-0.15, 0.15, len(diff)), diff.values, s=10, color=ROLE[m][0], alpha=0.7)
            lo, hi = bootstrap_ci(diff.values); ax.plot([k, k], [lo, hi], color=INK, lw=2); ax.plot([k - 0.2, k + 0.2], [diff.mean()] * 2, color=INK, lw=1.4)
            r = st[(st.dataset == d) & (st.model == m)]
            if not r.empty: ax.text(k, ax.get_ylim()[1], f"$p_{{NB}}$={r.p_corrected_t.iloc[0]:.2f}\n$p_{{Holm}}$={r.p_wilcoxon_holm.iloc[0]:.3f}", ha="center", va="bottom", fontsize=6)
            drows += [dict(dataset=d, model=m, repeat=a, fold=b, delta_MAE=v) for (a, b), v in diff.items()]
        ax.axhline(0, color=INK2, lw=0.8, ls="--"); ax.set_xticks(range(3)); ax.set_xticklabels(["GP comp.", "RF", "GBR"], fontsize=7)
        if j == 0: axs[0, 0].set_ylabel("Fold MAE (25 folds)"); axs[1, 0].set_ylabel("$\\Delta$MAE vs original GP\n(negative = better)")
    for a, s in zip(axs.ravel(), "abcdef"): panel_label(a, s)
    fig.tight_layout(h_pad=2.2); export("fig24_fold_mae", pd.DataFrame(rows)); export("fig24_paired_differences", pd.DataFrame(drows)); save(fig, "fig24_fold_distributions_and_paired_differences")


# ------------------------------------------------------------------ 25 configuration heat maps
def fig25():
    cols = [(a, b) for i, a in enumerate(TMD) for b in TMD[i:]]
    fig, axs = plt.subplots(3, 2, figsize=(11, 8.6)); rows = []
    for i, d in enumerate(DS):
        g = P[(P.dataset == d) & (P.model == PROP)].groupby("structure").agg(y=("y_true", "first"), p=("y_pred", "mean")).reset_index()
        g["ae"] = (g.p - g.y).abs(); parts = g.structure.str.split("-", expand=True)
        g["centre"] = parts[1]; g["outer"] = [tuple(sorted((a, c), key=TMD.index)) for a, c in zip(parts[0], parts[2])]
        T = np.full((6, len(cols)), np.nan); E = T.copy()
        for r in g.groupby(["centre", "outer"]).agg(y=("y", "mean"), ae=("ae", "mean")).reset_index().itertuples():
            T[TMD.index(r.centre), cols.index(r.outer)] = r.y; E[TMD.index(r.centre), cols.index(r.outer)] = r.ae
            rows.append(dict(dataset=d, centre=r.centre, outer="+".join(r.outer), mean_reference=r.y, mean_abs_error=r.ae))
        for k, (M, lab_, cm) in enumerate(((T, "Reference value", "viridis"), (E, "Mean |error| (proposed GP)", "magma"))):
            ax = axs[i, k]; im = ax.imshow(M, aspect="auto", cmap=cm); ax.grid(False)
            ax.set_yticks(range(6)); ax.set_yticklabels(TMD, fontsize=7); ax.set_xticks(range(len(cols))); ax.set_xticklabels(["+".join(c) for c in cols], rotation=80, ha="right", fontsize=5.5)
            fig.colorbar(im, ax=ax, fraction=0.03, label=lab_ + (" (eV)" if d == "band_gap" else ""))
            ax.set_title(f"{ {'band_gap':'Band gap','eff_p':'P-doped EFF','eff_n':'N-doped EFF'}[d] }: {lab_}", fontsize=8)
            if k == 0: ax.set_ylabel("Centre layer")
            if i == 2: ax.set_xlabel("Unordered pair of outer layers")
    for a, s in zip(axs.ravel(), "abcdef"): panel_label(a, s)
    fig.tight_layout(); export("fig25_configuration_heatmaps", pd.DataFrame(rows)); save(fig, "fig25_configuration_heatmaps")


# ------------------------------------------------------------------ 26 dispersion + band-gap comparison
def fig26():
    bs = load_dataset("band_structure"); names = list(bs.frame.structure); Y = bs.y; xax = np.loadtxt(ROOT / "data" / "original" / "xaxisvalue.txt")
    homo = {"MoS": "MoS-MoS-MoS", "MoSe": "MoSe-MoSe-MoSe", "MoTe": "MoTe-MoTe-MoTe", "WS": "WS-WS-WS", "WSe": "WSe-WSe-WSe", "WTe": "WTe-WTe-WTe"}
    fig, axs = plt.subplots(1, 3, figsize=(11.5, 3.9)); rows = []
    for ax, grp, ttl in ((axs[0], ["MoS", "MoSe", "MoTe"], "Mo-based homogeneous trilayers"), (axs[1], ["WS", "WSe", "WTe"], "W-based homogeneous trilayers")):
        for t, col in zip(grp, (EL_COL["S"], EL_COL["Se"], EL_COL["Te"])):
            if homo[t] not in names: continue
            y = Y[names.index(homo[t])]
            ax.plot(xax, y[:30], color=col, lw=1.6, label=homo[t].split("-")[0]); ax.plot(xax, y[30:], color=col, lw=1.6)
            rows += [dict(structure=homo[t], branch=b, k_index=k, x=xax[k], energy_eV=y[(0 if b == "CBM" else 30) + k]) for b in ("CBM", "VBM") for k in range(30)]
        ax.axhline(0, color=INK2, lw=0.5, ls=":"); ax.set_xlabel("Path coordinate (reciprocal units)"); ax.set_ylabel("Energy (eV)"); ax.set_title(ttl + "\n(upper: CBM, lower: VBM; reference data)", fontsize=8); ax.legend(fontsize=7)
    bgp = P[(P.dataset == "band_gap") & P.model.isin([BASE, PROP])].groupby(["structure", "model"]).y_pred.mean().unstack()
    gf = get_dataset("band_gap"); ref = pd.Series(gf.y, index=gf.frame.structure.values)
    ax = axs[2]; w = 0.2; recs = []
    for k, t in enumerate(TMD):
        s = homo[t]
        if s not in names: continue
        yy = Y[names.index(s)]; gcur = yy[:30].min() - yy[30:].max()
        vals = [ref.get(s, np.nan), gcur, bgp[BASE].get(s, np.nan), bgp[PROP].get(s, np.nan)]
        recs.append(dict(structure=s, gap_file=vals[0], gap_from_curves=vals[1], oof_original_GP=vals[2], oof_proposed_GP=vals[3]))
        for q, (v, col) in enumerate(zip(vals, (INK, GREY, ORANGE, BLUE))):
            ax.bar(k + (q - 1.5) * w, v, w, color=col, label=["Reference (file)", "From curve file", "GP original", "GP proposed"][q] if k == 0 else None)
    ax.axhline(0, color=INK2, lw=0.6); ax.set_xticks(range(6)); ax.set_xticklabels(TMD, fontsize=7); ax.set_ylabel("Band gap (eV)"); ax.set_ylim(0, 2.0); ax.legend(fontsize=6.5, ncol=2, loc="upper center")
    ax.set_title("Band gap of homogeneous stacks:\nreference and out-of-fold predictions", fontsize=8)
    for a, s in zip(axs, "abc"): panel_label(a, s)
    fig.tight_layout(); export("fig26_homogeneous_dispersion_curves", pd.DataFrame(rows)); export("fig26_homogeneous_band_gaps", pd.DataFrame(recs)); save(fig, "fig26_dispersion_and_band_gap_comparison")


# ------------------------------------------------------------------ 27 scaling
def fig27():
    S = pd.read_csv(CSV / "scaling.csv"); fig, axs = plt.subplots(1, 2, figsize=(9.2, 3.8)); rows = []
    for ax, col, ttl in ((axs[0], "fit_time_s", "Fit time (s)"), (axs[1], "predict_time_s", "Prediction time for the test set (s)")):
        for m in S.model.unique():
            g = S[S.model == m].groupby("n_train")[col].agg(["mean", "std"]).reset_index()
            c, mk = ROLE.get(m, (GREY, "o")); slope = np.polyfit(np.log(g.n_train), np.log(g["mean"]), 1)[0]
            ax.errorbar(g.n_train, g["mean"], yerr=g["std"], marker=mk, color=c, ms=4, capsize=2, label=f"{m} (slope {slope:.2f})")
            rows += [dict(quantity=col, model=m, n_train=r.n_train, mean_s=r["mean"], sd_s=r["std"], loglog_slope=slope) for _, r in g.iterrows()]
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("Training structures"); ax.set_ylabel(ttl)
    axs[0].legend(fontsize=6); axs[1].set_title("Prediction time (mean $\\pm$ sd, 3 repeats)", fontsize=8); axs[0].set_title("Fit time (mean $\\pm$ sd, 3 repeats; GPs: 2 restarts)", fontsize=8)
    for a, s in zip(axs, "ab"): panel_label(a, s)
    fig.tight_layout(); export("fig27_scaling", pd.DataFrame(rows)); save(fig, "fig27_computational_scaling")


if __name__ == "__main__":
    fn = {"20": fig20, "21": fig21, "22": fig22, "23": fig23, "24": fig24, "25": fig25, "26": fig26, "27": fig27}
    for k in sys.argv[1:] or list(fn):
        try:
            fn[k](); print("figure", k, "ok", flush=True)
        except Exception as e:
            import traceback; traceback.print_exc(); print("figure", k, "FAILED", e, flush=True)
