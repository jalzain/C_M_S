#!/usr/bin/env python3
"""Summaries, stack-level paired bootstrap, tables and figures for the extension experiments.
Reads results/csv/ext/* and the cached main/protocol results; writes results/csv/ext_*.csv, results/tables/table_ext_*.tex
and figures fig28-fig30."""
import sys, glob, warnings
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src")); sys.path.insert(0, str(ROOT / "scripts"))
warnings.filterwarnings("ignore")
import matplotlib.pyplot as plt
from plotting import *
from registry import get_dataset
from analyze_results import tex as _tex, TAB


def tex(*a, **k):
    _tex(*a, **k)
    f = TAB / f"{a[1]}.tex"
    f.write_text(f.read_text().replace("\\$p\\_\\{boot\\}\\$", "$p_{\\mathrm{boot}}$"))

CSV = ROOT / "results" / "csv"; EXT = CSV / "ext"
DS = ["band_gap", "eff_p", "eff_n"]
SCH = ["grouped_canonical", "grouped_composition"]
SCH_LABEL = {"grouped_canonical": "twin-aware", "grouped_composition": "composition-held-out"}
REF = ["GP-original", "GP-comp-ARD-M15", "GP-comp-iso-M25"]


def load_all():
    F, P = [], []
    for f in glob.glob(str(EXT / "cv__*.csv")):
        (P if f.endswith("__pred.csv") else F).append(pd.read_csv(f))
    F_ext, P_ext = pd.concat(F), pd.concat(P)
    mf = pd.read_csv(CSV / "regression_main_folds.csv"); mp = pd.read_csv(CSV / "regression_main_pred.csv")
    pf = pd.read_csv(CSV / "regression_protocol_folds.csv"); pp = pd.read_csv(CSV / "regression_protocol_pred.csv")
    keep = lambda d: d[(d.model.isin(REF)) & (d.scheme.isin(SCH))]
    Fall = pd.concat([F_ext, keep(mf), keep(pf)], ignore_index=True)
    Pall = pd.concat([P_ext, keep(mp), keep(pp)], ignore_index=True)
    return Fall, Pall


def cv_summary(F):
    g = F.groupby(["dataset", "scheme", "model"])
    S = g.agg(MAE=("MAE", "mean"), MAE_sd=("MAE", "std"), RMSE=("RMSE", "mean"), R2=("R2", "mean"),
              coverage95=("coverage95", "mean"), n_folds=("MAE", "size")).reset_index()
    S.to_csv(CSV / "ext_cv_summary.csv", index=False)
    return S


def stack_bootstrap(P, B=10000, seed=0):
    """Paired bootstrap over distinct stacks (units of sampling = canonical stack groups).
    Per-stack error = mean absolute out-of-fold error over repeats; difference in mean over stacks."""
    rows = []
    rs = np.random.RandomState(seed)
    for d in DS:
        ds = get_dataset(d)
        canon = dict(zip(ds.frame["structure"], ds.frame["canonical"]))
        for sch in SCH:
            sub = P[(P.dataset == d) & (P.scheme == sch)].copy()
            sub["canon"] = sub["structure"].map(canon)
            sub["ae"] = (sub.y_pred - sub.y_true).abs()
            tab = sub.groupby(["canon", "model", "structure"]).ae.mean().groupby(["canon", "model"]).mean().unstack("model")
            for ref in ("GP-original", "GP-comp-ARD-M15"):
                if ref not in tab: continue
                for m in tab.columns:
                    if m == ref: continue
                    dd = (tab[m] - tab[ref]).dropna().values
                    if len(dd) < 5: continue
                    bs = np.array([dd[rs.randint(len(dd), size=len(dd))].mean() for _ in range(B)])
                    p = 2 * min((bs <= 0).mean(), (bs >= 0).mean())
                    rows.append(dict(dataset=d, scheme=sch, model=m, reference=ref, n_stacks=len(dd), delta_MAE=dd.mean(),
                                     ci_lo=np.quantile(bs, 0.025), ci_hi=np.quantile(bs, 0.975), p_boot=max(p, 1 / B),
                                     frac_stacks_better=(dd < 0).mean()))
    R = pd.DataFrame(rows)
    R.to_csv(CSV / "ext_stack_bootstrap.csv", index=False)
    return R


def conformal_summary():
    fs = glob.glob(str(EXT / "conformal__*.csv"))
    if not fs: return None
    C = pd.concat([pd.read_csv(f) for f in fs])
    S = C.groupby(["dataset", "scheme", "model", "method", "alpha"]).apply(
        lambda g: pd.Series(dict(coverage=np.average(g.coverage, weights=g.n_test), halfwidth=g.mean_halfwidth.mean(), n_folds=len(g)))).reset_index()
    S.to_csv(CSV / "ext_conformal_summary.csv", index=False)
    return S


def nested_summary():
    fs = glob.glob(str(EXT / "nested__*.csv"))
    if not fs: return None, None
    N = pd.concat([pd.read_csv(f) for f in fs])
    rows, sel = [], []
    for d, g in N.groupby("dataset"):
        per = g.groupby("candidate").outer_MAE.mean()
        chosen = g[g.chosen].groupby(["repeat", "fold"]).outer_MAE.first()
        best = per.idxmin()
        rows.append(dict(dataset=d, nested_MAE=chosen.mean(), best_fixed=best, best_fixed_MAE=per.min(),
                         worst_fixed_MAE=per.max(), n_folds=len(chosen)))
        for k, v in g[g.chosen].candidate.value_counts().items():
            sel.append(dict(dataset=d, candidate=k, times_selected=int(v), n_folds=len(chosen)))
        for k, v in per.items():
            sel.append(dict(dataset=d, candidate=k, mean_outer_MAE=v))
    A, B = pd.DataFrame(rows), pd.DataFrame(sel)
    A.to_csv(CSV / "ext_nested_summary.csv", index=False); B.to_csv(CSV / "ext_nested_selection.csv", index=False)
    return A, B


def tables(S, R, C, NA, NB):
    nm = {"band_gap": "Band gap", "eff_p": "P-doped EFF", "eff_n": "N-doped EFF"}
    T = S.copy(); T["dataset"] = T.dataset.map(nm); T["scheme"] = T.scheme.map(SCH_LABEL)
    T["MAE (sd)"] = T.MAE.map("{:.3f}".format) + " (" + T.MAE_sd.map("{:.3f}".format) + ")"
    T = T[["dataset", "scheme", "model", "MAE (sd)", "RMSE", "R2", "coverage95"]].rename(columns={"R2": "$R^2$", "coverage95": "Cov95"})
    T = T.sort_values(["dataset", "scheme", "model"])
    tex(T, "table_ext_models", "Accuracy of the extension models and the reference GPs (mean and standard deviation of the fold MAE; RMSE, $R^2$ and empirical 95\\% coverage are fold means). Twin-aware: $5\\times5$ folds; composition-held-out: $5\\times3$ folds, same folds for all models. The auxiliary-task GPs are defined in the text; two-task models are evaluated on the EFF targets only.", "tab:extmodels")
    if R is not None and len(R):
        U = R[R.reference == "GP-original"].copy(); U["dataset"] = U.dataset.map(nm); U["scheme"] = U.scheme.map(SCH_LABEL)
        U["$\\Delta$MAE [95\\% CI]"] = U.delta_MAE.map("{:+.3f}".format) + " [" + U.ci_lo.map("{:+.3f}".format) + ", " + U.ci_hi.map("{:+.3f}".format) + "]"
        U = U[["dataset", "scheme", "model", "n_stacks", "$\\Delta$MAE [95\\% CI]", "p_boot", "frac_stacks_better"]].rename(columns={"p_boot": "$p_{boot}$", "frac_stacks_better": "stacks better"})
        U = U.sort_values(["dataset", "scheme", "model"])
        tex(U, "table_ext_bootstrap", "Stack-level paired bootstrap against the original GP: mean difference of the out-of-fold absolute error per distinct stack (negative values favour the model in the row), 95\\% percentile interval over $10^4$ resamples of stacks, two-sided bootstrap $p$-value (floored at $10^{-4}$) and fraction of stacks with a smaller error.", "tab:extboot", float_fmt="%.3f")
    if C is not None:
        V = C[C.alpha == 0.05].copy(); V["dataset"] = V.dataset.map(nm); V["scheme"] = V.scheme.map(SCH_LABEL)
        V = V.pivot_table(index=["dataset", "scheme", "model"], columns="method", values=["coverage", "halfwidth"]).reset_index()
        V.columns = [" ".join(c).strip() if c[1] else c[0] for c in V.columns]
        tex(V, "table_ext_conformal", "Nominal 95\\% intervals: empirical coverage and mean half-width of the Gaussian predictive interval and of cross-conformal intervals (normalised and absolute scores, twin-aware inner folds), $5\\times2$ outer folds.", "tab:extconf", float_fmt="%.3f")
    if NA is not None:
        W = NA.copy(); W["dataset"] = W.dataset.map(nm)
        W = W.rename(columns={"nested_MAE": "nested MAE", "best_fixed": "best fixed model", "best_fixed_MAE": "its MAE", "worst_fixed_MAE": "worst candidate MAE"})
        tex(W[["dataset", "nested MAE", "best fixed model", "its MAE", "worst candidate MAE", "n_folds"]], "table_ext_nested", "Nested model selection among six candidate models: the model is chosen by twin-aware inner cross-validation on each training set only, and the outer test MAE of the chosen model is averaged over the outer folds ($5\\times2$). ``Best fixed model'' is the candidate with the smallest mean outer MAE, which is an optimistic estimate because it was selected on the outer folds themselves.", "tab:extnested", float_fmt="%.3f")


def fig28(S):
    style()
    fig, axs = plt.subplots(2, 3, figsize=(11, 6.2), sharey="col")
    models = ["GP-original", "GP-comp-ARD-M15", "GP-comp-iso-M25", "GP-additive", "GP-censored", "GP-2task-none", "GP-2task-train", "GP-2task-all"]
    cols = {"GP-original": ORANGE, "GP-comp-ARD-M15": BLUE, "GP-comp-iso-M25": AQUA, "GP-additive": VIOLET, "GP-censored": MAGENTA,
            "GP-2task-none": GREY, "GP-2task-train": YELLOW, "GP-2task-all": GREEN}
    rows = []
    for i, sch in enumerate(SCH):
        for j, d in enumerate(DS):
            ax = axs[i, j]
            sub = S[(S.dataset == d) & (S.scheme == sch)].set_index("model")
            ms = [m for m in models if m in sub.index]
            for k, m in enumerate(ms):
                ax.bar(k, sub.loc[m, "MAE"], yerr=sub.loc[m, "MAE_sd"] / np.sqrt(sub.loc[m, "n_folds"]), color=cols[m], capsize=2)
                rows.append(dict(dataset=d, scheme=sch, model=m, MAE=sub.loc[m, "MAE"], se=sub.loc[m, "MAE_sd"] / np.sqrt(sub.loc[m, "n_folds"])))
            ax.set_xticks(range(len(ms))); ax.set_xticklabels([m.replace("GP-", "") for m in ms], rotation=60, ha="right", fontsize=7)
            ax.set_title(f"{DATASET_SHORT[d]}, {SCH_LABEL[sch]}", fontsize=9)
            if j == 0: ax.set_ylabel("MAE (mean $\\pm$ s.e. over folds)")
            panel_label(ax, "abcdef"[3 * i + j])
    fig.tight_layout(); export("fig28_extension_models", pd.DataFrame(rows)); save(fig, "fig28_extension_models")


def fig29(R):
    style()
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.6), sharex=False)
    show = ["GP-comp-ARD-M15", "GP-comp-iso-M25", "GP-additive", "GP-censored", "GP-2task-none", "GP-2task-all"]
    rows = []
    for j, d in enumerate(DS):
        ax = axs[j]
        sub = R[(R.dataset == d) & (R.reference == "GP-original") & (R.model.isin(show))]
        y = 0
        for sch, mk in zip(SCH, ("o", "s")):
            for _, r in sub[sub.scheme == sch].iterrows():
                ax.errorbar(r.delta_MAE, y, xerr=[[r.delta_MAE - r.ci_lo], [r.ci_hi - r.delta_MAE]], fmt=mk, color=BLUE if sch == SCH[0] else RED, capsize=2, ms=4)
                ax.text(ax.get_xlim()[0], y, "", fontsize=6)
                rows.append(dict(dataset=d, scheme=sch, model=r.model, delta=r.delta_MAE, lo=r.ci_lo, hi=r.ci_hi))
                y += 1
        labels = [f"{m.replace('GP-','')} ({SCH_LABEL[s][:4]}.)" for s in SCH for m in sub[sub.scheme == s].model]
        ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels, fontsize=6.5); ax.axvline(0, color=INK2, lw=0.8)
        ax.set_xlabel("$\\Delta$MAE vs original GP"); ax.set_title(DATASET_SHORT[d], fontsize=9); panel_label(ax, "abc"[j])
    fig.tight_layout(); export("fig29_stack_level_bootstrap", pd.DataFrame(rows)); save(fig, "fig29_stack_level_bootstrap")


def fig30(C):
    style()
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.6), sharey=True)
    rows = []
    meth = ["gaussian", "conformal-normalised", "conformal-absolute"]
    colr = {"gaussian": ORANGE, "conformal-normalised": BLUE, "conformal-absolute": AQUA}
    for j, d in enumerate(DS):
        ax = axs[j]
        for k, sch in enumerate(SCH):
            for q, m in enumerate(meth):
                v = C[(C.dataset == d) & (C.scheme == sch) & (C.model == "GP-comp-ARD-M15") & (C.method == m) & (C.alpha == 0.05)]
                if v.empty: continue
                ax.bar(k * 4 + q, v.coverage.iloc[0], color=colr[m], label=m if (j == 0 and k == 0) else None)
                rows.append(dict(dataset=d, scheme=sch, method=m, coverage=v.coverage.iloc[0], halfwidth=v.halfwidth.iloc[0]))
        ax.axhline(0.95, color=INK, ls="--", lw=1); ax.set_ylim(0.6, 1.0)
        ax.set_xticks([1, 5]); ax.set_xticklabels([SCH_LABEL[s] for s in SCH]); ax.set_title(DATASET_SHORT[d], fontsize=9); panel_label(ax, "abc"[j])
        if j == 0: ax.set_ylabel("empirical coverage (nominal 95%)"); ax.legend(fontsize=7, loc="lower left")
    fig.tight_layout(); export("fig30_conformal_coverage", pd.DataFrame(rows)); save(fig, "fig30_conformal_coverage")


if __name__ == "__main__":
    F, P = load_all()
    S = cv_summary(F); R = stack_bootstrap(P); C = conformal_summary(); NA, NB = nested_summary()
    tables(S, R, C, NA, NB)
    fig28(S); fig29(R)
    if C is not None: fig30(C)
    print(S.round(3).to_string()); print(R.round(3).to_string())
