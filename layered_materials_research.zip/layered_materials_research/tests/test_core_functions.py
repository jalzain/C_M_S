"""Basic automated tests: python -m pytest -q tests"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from data_preprocessing import (load_dataset, canonical_key, composition_key, build_features,
                                reverse_stack_frame, assign_groups)
from evaluation import make_splits, regression_metrics
from improved_models import canonical_orientation, ImprovedGP, TreeEnsemble
from bayesian_optimization import (expected_improvement, probability_of_improvement, original_ei,
                                   upper_confidence_bound, run_bo, summarise_history)
from statistical_analysis import holm_correction, wilson_interval


def test_dataset_shapes():
    assert load_dataset("band_gap").y.shape == (177,)
    assert load_dataset("band_structure").y.shape == (99, 60)
    assert len(load_dataset("eff_n").y) == 116 and len(load_dataset("eff_p").y) == 115


def test_canonical_key_reversal_invariant():
    a = ["Mo", "S", "W", "Se", "W", "Te"]
    b = ["W", "Te", "W", "Se", "Mo", "S"]
    assert canonical_key(a) == canonical_key(b)
    assert composition_key(a) == composition_key(b)


def test_symmetric_features_reversal_invariant():
    ds = load_dataset("band_gap")
    X1 = build_features(ds.frame, "symmetric")
    X2 = build_features(reverse_stack_frame(ds.frame), "symmetric")
    assert np.allclose(X1, X2)


def test_grouped_splits_have_no_twin_leakage():
    ds = load_dataset("band_gap")
    g = assign_groups(ds, "canonical")
    for tr, te in make_splits(ds, "grouped_canonical", 5, 0, 0):
        assert set(g[tr]).isdisjoint(set(g[te]))
    # plain random K-fold *does* leak (documented in the paper)
    leaks = [len(set(g[tr]) & set(g[te])) for tr, te in make_splits(ds, "random", 5, 0, 0)]
    assert max(leaks) > 0


def test_all_models_see_same_splits():
    ds = load_dataset("eff_p")
    a = [te.tolist() for _, te in make_splits(ds, "grouped_canonical", 5, 1, 7)]
    b = [te.tolist() for _, te in make_splits(ds, "grouped_canonical", 5, 1, 7)]
    assert a == b


def test_canonical_orientation_idempotent():
    ds = load_dataset("band_gap")
    c1 = canonical_orientation(ds.frame)
    c2 = canonical_orientation(c1)
    cols = ["M1", "X1", "M2", "X2", "M3", "X3"]
    assert (c1[cols].values == c2[cols].values).all()


def test_regression_metrics_perfect_and_constant():
    y = np.array([1.0, 2.0, 3.0, 4.0])
    m = regression_metrics(y, y)
    assert m["MAE"] == 0 and m["RMSE"] == 0 and abs(m["R2"] - 1) < 1e-12
    m2 = regression_metrics(y, np.full(4, y.mean()))
    assert abs(m2["R2"]) < 1e-12


def test_acquisition_functions_behaviour():
    mu = np.array([0.0, 1.0, 2.0]); sd = np.array([1.0, 1.0, 1.0])
    ei = expected_improvement(mu, sd, best=1.0)
    assert ei[2] > ei[1] > ei[0] >= 0
    pi = probability_of_improvement(mu, sd, best=1.0)
    assert 0 <= pi.min() and pi.max() <= 1 and pi[2] > pi[0]
    assert np.allclose(upper_confidence_bound(mu, sd, 2.0), mu + 2)
    # EI is zero-limit when sigma -> 0 and mean below incumbent
    assert expected_improvement(np.array([0.0]), np.array([1e-12]), 1.0)[0] < 1e-12
    assert np.isfinite(original_ei(mu, sd, 1.0, 0.1)).all()


def test_gp_fit_predict_runs():
    ds = load_dataset("eff_p")
    m = ImprovedGP("matern25_ard", features="symmetric", orient="none", n_restarts=0).fit(ds.frame.iloc[:60], ds.y[:60])
    mu, sd = m.predict(ds.frame.iloc[60:70], return_std=True)
    assert mu.shape == (10,) and (sd > 0).all()


def test_log_transform_back_transform_positive():
    ds = load_dataset("eff_p")
    m = ImprovedGP("matern25_ard", features="symmetric", orient="none", n_restarts=0, y_transform="log10").fit(
        ds.frame.iloc[:60], ds.y[:60])
    mu, sd = m.predict(ds.frame.iloc[60:70], return_std=True)
    assert (mu > 0).all() and (sd > 0).all()


def test_bo_random_and_history_consistency():
    ds = load_dataset("eff_p")
    names = ds.frame["structure"].values
    X = build_features(ds.frame, "symmetric")
    H = run_bo(X, ds.y, names, "random", n_init=10, n_iter=15, seed=3)
    assert len(H) == 25 and H["structure"].is_unique
    assert (np.diff(H["best_so_far"]) >= 0).all()
    s = summarise_history(H, ds.y)
    assert 1 <= s["final_rank"] <= len(ds.y)


def test_bo_ei_finds_better_than_initial_design():
    ds = load_dataset("eff_p")
    names = ds.frame["structure"].values
    X = build_features(ds.frame, "symmetric")
    H = run_bo(X, ds.y, names, "ei", n_init=10, n_iter=6, seed=0, restarts=0)
    assert H["best_so_far"].iloc[-1] >= H["best_so_far"].iloc[9]


def test_stats_helpers():
    adj = holm_correction([0.01, 0.04, 0.03])
    assert np.all(adj >= np.array([0.01, 0.04, 0.03]) - 1e-12) and adj.max() <= 1
    lo, hi = wilson_interval(5, 10)
    assert lo < 0.5 < hi
