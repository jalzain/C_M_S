"""Central registry of datasets and model configurations used by all experiments."""
from __future__ import annotations
import numpy as np
from data_preprocessing import load_dataset, Dataset
from baseline_models import BaselineGP
from improved_models import ImprovedGP, TreeEnsemble, SklearnPoint, CurveModel

EFF_OUTLIER_THRESHOLD = 100.0     # N-doped EFF: 946.5 and 26710 vs. next largest 21.2 (see audit)
BASELINE_RESTARTS = 2             # reduced from 40-100 in the original for tractability (see restart study)
IMPROVED_RESTARTS = 2


def get_dataset(name: str) -> Dataset:
    """band_gap | eff_p | eff_n (outliers removed) | eff_n_full | band_structure"""
    if name == "eff_n":
        ds = load_dataset("eff_n")
        keep = ds.y < EFF_OUTLIER_THRESHOLD
        ds.frame = ds.frame[keep].reset_index(drop=True)
        ds.y = ds.y[keep]
        ds.name = "eff_n"
        return ds
    if name == "eff_n_full":
        return load_dataset("eff_n")
    return load_dataset(name)


def regression_models(dataset: str, restarts: int = IMPROVED_RESTARTS, base_restarts: int = BASELINE_RESTARTS):
    """name -> zero-argument factory.  Physical lower bound (gap >= 0) is applied to improved models only."""
    clip = 0.0 if dataset == "band_gap" else None
    R = restarts
    m = {
        # ---- baseline (original design) ----
        "GP-original": lambda: BaselineGP("maxval", n_restarts=base_restarts),
        # ---- proposed ----
        "GP-comp-ARD-M15": lambda: ImprovedGP("matern15_ard", "composition", "none", clip_min=clip, n_restarts=R),
        # ---- GP variants (kernel / representation study) ----
        "GP-comp-ARD-M25": lambda: ImprovedGP("matern25_ard", "composition", "none", clip_min=clip, n_restarts=R),
        "GP-comp-ARD-RBF": lambda: ImprovedGP("rbf_ard", "composition", "none", clip_min=clip, n_restarts=R),
        "GP-comp-iso-M25": lambda: ImprovedGP("matern25_iso", "composition", "none", clip_min=clip, n_restarts=R),
        "GP-comp-iso-RBF": lambda: ImprovedGP("rbf_iso", "composition", "none", clip_min=clip, n_restarts=R),
        "GP-comp-iso-RQ": lambda: ImprovedGP("rq_iso", "composition", "none", clip_min=clip, n_restarts=R),
        "GP-sym-ARD-M25": lambda: ImprovedGP("matern25_ard", "symmetric", "none", clip_min=clip, n_restarts=R),
        "GP-pos-ARD-M25": lambda: ImprovedGP("matern25_ard", "positional", "canonical", clip_min=clip, n_restarts=R),
        # ---- alternative regressors ----
        "RF-pos": lambda: TreeEnsemble("rf", "positional", "canonical", clip_min=clip),
        "ET-pos": lambda: TreeEnsemble("et", "positional", "canonical", clip_min=clip),
        "RF-comp": lambda: TreeEnsemble("rf", "composition", "none", clip_min=clip),
        "ET-comp": lambda: TreeEnsemble("et", "composition", "none", clip_min=clip),
        "GBR-comp": lambda: SklearnPoint("gbr", "composition", "none", clip_min=clip),
        "SVR-comp": lambda: SklearnPoint("svr", "composition", "none", clip_min=clip),
        "KRR-comp": lambda: SklearnPoint("krr", "composition", "none", clip_min=clip),
        "kNN-comp": lambda: SklearnPoint("knn", "composition", "none", clip_min=clip),
        "Ridge-comp": lambda: SklearnPoint("ridge", "composition", "none", clip_min=clip),
        "Mean-predictor": lambda: SklearnPoint("mean"),
    }
    if dataset.startswith("eff"):
        m["GP-comp-ARD-M15-log10"] = lambda: ImprovedGP("matern15_ard", "composition", "none", y_transform="log10",
                                                        n_restarts=R)
    return m


# Ablation chain for the GP (each step adds one change to the previous step)
def ablation_models(dataset: str, R: int = IMPROVED_RESTARTS, base_restarts: int = BASELINE_RESTARTS):
    clip = 0.0 if dataset == "band_gap" else None
    wide = (1e-3, 1e3)
    return {
        "A0 original GP": lambda: BaselineGP("maxval", n_restarts=base_restarts),
        "A1 +narrower length-scale bounds, new kernel code (min-max pos.)":
            lambda: ImprovedGP("matern15_ard", "positional", "none", normalize_y=False, n_restarts=R),
        "A2 +target normalisation": lambda: ImprovedGP("matern15_ard", "positional", "none", normalize_y=True, n_restarts=R),
        "A3 +canonical stack orientation": lambda: ImprovedGP("matern15_ard", "positional", "canonical", n_restarts=R),
        "A4 symmetric representation": lambda: ImprovedGP("matern15_ard", "symmetric", "none", n_restarts=R),
        "A5 composition representation": lambda: ImprovedGP("matern15_ard", "composition", "none", n_restarts=R),
        "A6 +physical post-processing (clip / none)": lambda: ImprovedGP("matern15_ard", "composition", "none", clip_min=clip, n_restarts=R),
        "A7 composition, no white-noise term": lambda: ImprovedGP("matern15_ard", "composition", "none", clip_min=clip, n_restarts=R, white=False),
        "A8 composition, isotropic kernel": lambda: ImprovedGP("matern15_iso", "composition", "none", clip_min=clip, n_restarts=R),
    }


def curve_models(restarts: int = 0):
    return {
        "Indep-GP-original": lambda: CurveModel("indep_gp", "positional", "none", original_kernel=True, n_restarts=restarts),
        "Indep-GP-comp": lambda: CurveModel("indep_gp", "composition", "none", n_restarts=restarts),
        "Shared-GP-positional": lambda: CurveModel("shared_gp", "positional", "none", n_restarts=restarts),
        "Shared-GP-comp": lambda: CurveModel("shared_gp", "composition", "none", n_restarts=restarts),
        "PCA6-GP-comp": lambda: CurveModel("pca_gp", "composition", "none", n_components=6, n_restarts=restarts),
        "PCA3-GP-comp": lambda: CurveModel("pca_gp", "composition", "none", n_components=3, n_restarts=restarts),
        "ET-comp": lambda: CurveModel("et", "composition", "none"),
        "RF-comp": lambda: CurveModel("rf", "composition", "none"),
        "KRR-comp": lambda: CurveModel("krr", "composition", "none"),
    }
