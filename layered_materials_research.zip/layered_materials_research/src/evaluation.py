"""Validation protocols, metrics and the common cross-validation runner."""
from __future__ import annotations
import time, warnings
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import GroupKFold, KFold
from data_preprocessing import assign_groups

warnings.filterwarnings("ignore")


# ----------------------------------------------------------------------------- splits
def make_splits(ds, scheme: str, n_splits: int, repeat: int, seed: int):
    """Yield (train_idx, test_idx).  All models see exactly the same splits for a given (scheme, repeat, seed).

    scheme:
      'random'             - plain shuffled K-fold (the protocol of the original scripts; leaks stack-reversed twins)
      'grouped_canonical'  - twins (stack-reversal equivalents) are kept in the same fold
      'grouped_composition'- all stacks with the same multiset of TMD layers are kept together
                             (tests generalisation to unseen compositions)
    """
    n = len(ds.frame)
    rs = np.random.RandomState(10_000 * seed + repeat)
    if scheme == "random":
        yield from KFold(n_splits, shuffle=True, random_state=rs.randint(2**31 - 1)).split(np.arange(n))
        return
    kind = {"grouped_canonical": "canonical", "grouped_composition": "composition"}[scheme]
    g = assign_groups(ds, kind)
    # randomise group labels per repeat so GroupKFold gives different partitions
    perm = rs.permutation(g.max() + 1)
    yield from GroupKFold(n_splits).split(np.arange(n), groups=perm[g])


def holdout_split(ds, scheme: str, train_fraction: float, seed: int, nested_sizes=None):
    """Single grouped hold-out split (used for learning curves)."""
    n = len(ds.frame)
    kind = {"random": None, "grouped_canonical": "canonical", "grouped_composition": "composition"}[scheme]
    rs = np.random.RandomState(seed)
    if kind is None:
        perm = rs.permutation(n)
        k = int(round(train_fraction * n))
        return perm[:k], perm[k:]
    g = assign_groups(ds, kind)
    ug = rs.permutation(g.max() + 1)
    k = int(round(train_fraction * len(ug)))
    tr_groups = set(ug[:k])
    mask = np.array([gi in tr_groups for gi in g])
    return np.where(mask)[0], np.where(~mask)[0]


# ----------------------------------------------------------------------------- metrics
def regression_metrics(y, mu, sd=None, mape=False, prob=True) -> dict:
    y, mu = np.asarray(y, float), np.asarray(mu, float)
    err = mu - y
    out = dict(MAE=np.mean(np.abs(err)), RMSE=np.sqrt(np.mean(err ** 2)),
               R2=1 - np.sum(err ** 2) / max(np.sum((y - y.mean()) ** 2), 1e-12),
               MedAE=np.median(np.abs(err)),
               spearman=stats.spearmanr(y, mu)[0] if np.std(mu) > 0 and len(y) > 2 else np.nan)
    if mape and np.all(y > 0):
        out["MAPE_pct"] = 100 * np.mean(np.abs(err) / y)
    if sd is not None and np.all(np.isfinite(sd)):
        s = np.maximum(sd, 1e-9)
        z = err / s
        out["mean_sigma"] = np.mean(s)
        out["sigma_err_spearman"] = stats.spearmanr(s, np.abs(err))[0] if np.std(s) > 0 else np.nan
        if not prob:
            return out
        out["NLL"] = np.mean(0.5 * np.log(2 * np.pi * s ** 2) + 0.5 * z ** 2)
        out["coverage95"] = np.mean(np.abs(z) <= 1.959964)
        out["coverage68"] = np.mean(np.abs(z) <= 1.0)
        out["z_std"] = np.std(z)
    return out


# ----------------------------------------------------------------------------- runner
def run_cv(ds, model_factory, scheme="grouped_canonical", n_splits=5, n_repeats=3, seed=0,
           target=None, model_name=None, mape=False, eval_transform=None):
    """Cross-validate one model.  Returns (predictions DataFrame, per-fold metrics DataFrame).

    ``target`` defaults to ds.y (1-D).  ``eval_transform`` maps predictions and truth to the evaluation scale
    (e.g. log10 for the heavy-tailed N-doped EFF) *after* prediction.
    """
    y = ds.y if target is None else target
    frame = ds.frame
    preds, folds = [], []
    for rep in range(n_repeats):
        for fold, (tr, te) in enumerate(make_splits(ds, scheme, n_splits, rep, seed)):
            m = model_factory()
            t0 = time.perf_counter()
            m.fit(frame.iloc[tr].reset_index(drop=True), y[tr])
            t_fit = time.perf_counter() - t0
            t0 = time.perf_counter()
            mu, sd = m.predict(frame.iloc[te].reset_index(drop=True), return_std=True)
            t_pred = time.perf_counter() - t0
            yt = y[te]
            if eval_transform is not None:
                yt_e, mu_e = eval_transform(yt), eval_transform(np.maximum(mu, 1e-9))
                sd_e = np.full_like(sd, np.nan)   # uncertainty not transformed here
            else:
                yt_e, mu_e, sd_e = yt, mu, sd
            met = regression_metrics(yt_e, mu_e, sd_e, mape=mape, prob=getattr(m, "calibrated_uncertainty", True))
            met.update(repeat=rep, fold=fold, n_train=len(tr), n_test=len(te), fit_time_s=t_fit, predict_time_s=t_pred)
            folds.append(met)
            preds.append(pd.DataFrame(dict(structure=frame["structure"].values[te], repeat=rep, fold=fold,
                                           y_true=yt, y_pred=mu, y_sigma=sd)))
    P = pd.concat(preds, ignore_index=True)
    F = pd.DataFrame(folds)
    name = model_name or getattr(m, "name", "model")
    P.insert(0, "model", name); F.insert(0, "model", name)
    P.insert(0, "scheme", scheme); F.insert(0, "scheme", scheme)
    return P, F
