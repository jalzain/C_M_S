"""Improved and alternative surrogate models operating on structure DataFrames.

Improvements over the original (each is switchable so it can be ablated):
  * ``orient='canonical'``   : stack-reversal canonical orientation (physically equivalent structures
                               map to identical inputs)
  * ``normalize_y``          : zero-mean/unit-variance target scaling inside the GP
  * ``y_transform``          : 'identity' | 'log10' (heavy-tailed positive targets such as EFF)
  * ``clip_min``             : physical lower bound (band gap >= 0)
  * kernel family / ARD      : Matern-1.5/2.5, RBF, RationalQuadratic, isotropic or ARD
  * ``features``             : positional | composition | hybrid
  * ``n_restarts``           : optimiser restarts (accuracy vs. cost)
"""
from __future__ import annotations
import time
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import (ConstantKernel as C, Matern, RBF, RationalQuadratic as RQ,
                                              WhiteKernel)
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import RidgeCV
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.dummy import DummyRegressor
from sklearn.model_selection import GridSearchCV, KFold
from data_preprocessing import build_features, reverse_stack_frame

_METALS_STACK = ["M1", "X1", "M2", "X2", "M3", "X3"]


def canonical_orientation(frame: pd.DataFrame) -> pd.DataFrame:
    """Return the frame with every stack written in its lexicographically smallest orientation."""
    f = frame.copy()
    pairs = [[f"{r.M1}{r.X1}", f"{r.M2}{r.X2}", f"{r.M3}{r.X3}"] for r in f.itertuples()]
    flip = np.array([p[::-1] < p for p in pairs])
    if flip.any():
        rev = reverse_stack_frame(f)
        f.loc[flip, _METALS_STACK] = rev.loc[flip, _METALS_STACK].values
    return f


def make_kernel(name: str, dim: int, ls_bounds=(1e-2, 1e2), white=True):
    """Kernel factory: ``<family>_<ard|iso>`` e.g. ``matern25_ard``; includes a white-noise term by default."""
    fam, mode = name.rsplit("_", 1)
    ls = [1.0] * dim if mode == "ard" else 1.0
    lb = [ls_bounds] * dim if mode == "ard" else ls_bounds
    if fam == "matern15":
        base = Matern(ls, lb, 1.5)
    elif fam == "matern25":
        base = Matern(ls, lb, 2.5)
    elif fam == "rbf":
        base = RBF(ls, lb)
    elif fam == "rq":
        base = RQ(1.0, 1.0, (1e-2, 1e2), (1e-2, 1e2))   # isotropic RQ (sklearn RQ has no ARD)
    else:
        raise ValueError(name)
    k = C(1.0, (1e-2, 1e2)) * base
    return k + WhiteKernel(1e-2, (1e-6, 1e0)) if white else k


class ImprovedGP:
    """Gaussian-process regressor with the improvements listed in the module docstring."""

    def __init__(self, kernel="matern25_ard", features="positional", orient="canonical", normalize_y=True,
                 y_transform="identity", clip_min=None, n_restarts=2, seed=0, name=None,
                 ls_bounds=(1e-2, 1e2), white=True):
        self.ls_bounds, self.white = ls_bounds, white
        self.kernel, self.features, self.orient = kernel, features, orient
        self.normalize_y, self.y_transform, self.clip_min = normalize_y, y_transform, clip_min
        self.n_restarts, self.seed = n_restarts, seed
        self.name = name or f"GP[{kernel},{features},{orient},ny={normalize_y},{y_transform}]"

    # -- helpers
    def _X(self, frame):
        f = canonical_orientation(frame) if self.orient == "canonical" else frame
        return build_features(f, self.features)

    def _fwd(self, y):
        return np.log10(y) if self.y_transform == "log10" else y

    def _inv(self, z):
        return 10.0 ** z if self.y_transform == "log10" else z

    def fit(self, frame, y, warm_theta=None):
        X = self._X(frame)
        self.dim_ = X.shape[1]
        k = make_kernel(self.kernel, self.dim_, self.ls_bounds, self.white)
        if warm_theta is not None and len(warm_theta) == len(k.theta):
            k = k.clone_with_theta(warm_theta)
        self.gp = GaussianProcessRegressor(k, n_restarts_optimizer=self.n_restarts,
                                           normalize_y=self.normalize_y, random_state=self.seed)
        self.gp.fit(X, self._fwd(np.asarray(y, float)))
        return self

    def predict_latent(self, frame):
        """Mean/std on the *transformed* target scale."""
        return self.gp.predict(self._X(frame), return_std=True)

    def predict(self, frame, return_std=False):
        mu, sd = self.predict_latent(frame)
        if self.y_transform == "log10":
            # moment-matched back-transform of a log-normal predictive distribution
            ln10 = np.log(10.0)
            m = np.exp(ln10 * mu + 0.5 * (ln10 * sd) ** 2)
            s = m * np.sqrt(np.expm1((ln10 * sd) ** 2))
            mu, sd = m, s
        if self.clip_min is not None:
            mu = np.maximum(mu, self.clip_min)
        return (mu, sd) if return_std else mu

    @property
    def length_scales(self):
        """Fitted ARD length scales (None for isotropic kernels would return a 1-element array)."""
        k = self.gp.kernel_
        base = k.k1.k2 if hasattr(k, "k1") and hasattr(k.k1, "k2") else k.k2
        return np.atleast_1d(base.length_scale)


class TreeEnsemble:
    """RF / ExtraTrees with predictive std from the spread of the individual trees.

    The tree-spread is *not* a calibrated predictive distribution, so probabilistic scores (NLL, coverage)
    are not computed for it (``calibrated_uncertainty = False``); its rank-correlation with |error| is kept.
    """
    calibrated_uncertainty = False

    def __init__(self, kind="rf", features="positional", orient="canonical", y_transform="identity",
                 clip_min=None, n_estimators=300, seed=0, name=None):
        self.kind, self.features, self.orient = kind, features, orient
        self.y_transform, self.clip_min, self.n_estimators, self.seed = y_transform, clip_min, n_estimators, seed
        self.name = name or {"rf": "RandomForest", "et": "ExtraTrees"}[kind]

    def _X(self, frame):
        f = canonical_orientation(frame) if self.orient == "canonical" else frame
        return build_features(f, self.features)

    def fit(self, frame, y):
        cls = RandomForestRegressor if self.kind == "rf" else ExtraTreesRegressor
        self.m = cls(n_estimators=self.n_estimators, random_state=self.seed, n_jobs=1, min_samples_leaf=1)
        yy = np.log10(y) if self.y_transform == "log10" else np.asarray(y, float)
        self.m.fit(self._X(frame), yy)
        return self

    def predict(self, frame, return_std=False):
        X = self._X(frame)
        P = np.stack([t.predict(X) for t in self.m.estimators_])
        mu, sd = P.mean(0), P.std(0)
        if self.y_transform == "log10":
            mu, sd = 10 ** mu, np.log(10) * 10 ** mu * sd          # delta method
        if self.clip_min is not None:
            mu = np.maximum(mu, self.clip_min)
        return (mu, sd) if return_std else mu


class SklearnPoint:
    """Wrapper for point-prediction sklearn regressors with inner-CV hyper-parameter search (no leakage)."""

    def __init__(self, kind, features="positional", orient="canonical", y_transform="identity", clip_min=None,
                 seed=0, name=None):
        self.kind, self.features, self.orient = kind, features, orient
        self.y_transform, self.clip_min, self.seed = y_transform, clip_min, seed
        self.name = name or {"svr": "SVR-RBF", "gbr": "GradientBoosting", "krr": "KernelRidge-RBF",
                             "ridge": "Ridge", "knn": "kNN", "mean": "Mean-predictor"}[kind]

    def _X(self, frame):
        f = canonical_orientation(frame) if self.orient == "canonical" else frame
        return build_features(f, self.features)

    def _estimator(self, n):
        k = self.kind
        inner = KFold(min(5, n), shuffle=True, random_state=self.seed)
        if k == "svr":
            return GridSearchCV(SVR(kernel="rbf"), {"C": [0.3, 1, 3, 10, 30], "gamma": [0.03, 0.1, 0.3, 1.0],
                                                    "epsilon": [0.01, 0.05]},
                                cv=inner, scoring="neg_mean_absolute_error")
        if k == "gbr":
            return GridSearchCV(GradientBoostingRegressor(random_state=self.seed, subsample=0.8),
                                {"n_estimators": [100, 300], "max_depth": [2, 3], "learning_rate": [0.05, 0.1]},
                                cv=inner, scoring="neg_mean_absolute_error")
        if k == "krr":
            return GridSearchCV(KernelRidge(kernel="rbf"), {"alpha": [1e-3, 1e-2, 1e-1, 1], "gamma": [0.03, 0.1, 0.3, 1.0]},
                                cv=inner, scoring="neg_mean_absolute_error")
        if k == "ridge":
            return RidgeCV(alphas=np.logspace(-3, 2, 11))
        if k == "knn":
            return GridSearchCV(KNeighborsRegressor(weights="distance"), {"n_neighbors": [2, 3, 5, 8]},
                                cv=inner, scoring="neg_mean_absolute_error")
        if k == "mean":
            return DummyRegressor()
        raise ValueError(k)

    def fit(self, frame, y):
        X = self._X(frame)
        yy = np.log10(y) if self.y_transform == "log10" else np.asarray(y, float)
        self.ymu_, self.ysd_ = yy.mean(), yy.std() + 1e-12
        self.m = self._estimator(len(yy)).fit(X, (yy - self.ymu_) / self.ysd_)
        return self

    def predict(self, frame, return_std=False):
        mu = self.m.predict(self._X(frame)) * self.ysd_ + self.ymu_
        if self.y_transform == "log10":
            mu = 10 ** mu
        if self.clip_min is not None:
            mu = np.maximum(mu, self.clip_min)
        if return_std:
            return mu, np.full_like(mu, np.nan)
        return mu


def timed_fit(model, frame, y):
    t = time.perf_counter()
    model.fit(frame, y)
    return time.perf_counter() - t


# ----------------------------------------------------------------------------- multi-output (band curves)
class CurveModel:
    """Multi-output regressor for the 60-point (CBM+VBM) curves.

    kind:
      'indep_gp' : one independent GP per output (original design of predict_structure.py)
      'shared_gp': one GP with a single shared kernel for all outputs (sklearn multi-output GPR)
      'pca_gp'   : PCA to ``n_components`` scores, one GP per score (dimensionality reduction)
      'et'/'rf'  : multi-output tree ensembles
      'krr'      : kernel ridge (RBF), inner-CV tuned
    """
    calibrated_uncertainty = False

    def __init__(self, kind="shared_gp", features="composition", orient="none", n_components=6, n_restarts=0,
                 kernel="matern25_ard", original_kernel=False, seed=0, name=None):
        self.kind, self.features, self.orient = kind, features, orient
        self.n_components, self.n_restarts, self.kernel, self.seed = n_components, n_restarts, kernel, seed
        self.original_kernel = original_kernel
        self.name = name or f"Curve[{kind},{features}]"

    def _X(self, frame):
        f = canonical_orientation(frame) if self.orient == "canonical" else frame
        return build_features(f, self.features)

    def _gp(self, d):
        if self.original_kernel:     # predict_structure.py: C*Matern(2.5, ARD, wide bounds)+White
            k = C(1.0, (1e-3, 1e3)) * Matern([1.0] * d, [(1e-3, 1e4)] * d, 2.5) + WhiteKernel(1.0, (1e-3, 1e3))
            return GaussianProcessRegressor(k, n_restarts_optimizer=self.n_restarts, normalize_y=False,
                                            random_state=self.seed)
        return GaussianProcessRegressor(make_kernel(self.kernel, d), n_restarts_optimizer=self.n_restarts,
                                        normalize_y=True, random_state=self.seed)

    def fit(self, frame, Y):
        X = self._X(frame)
        Y = np.asarray(Y, float)
        d = X.shape[1]
        if self.kind == "indep_gp":
            self.models = [self._gp(d).fit(X, Y[:, j]) for j in range(Y.shape[1])]
        elif self.kind == "shared_gp":
            self.m = self._gp(d).fit(X, Y)
        elif self.kind == "pca_gp":
            from sklearn.decomposition import PCA
            self.mu_ = Y.mean(0)
            self.pca = PCA(n_components=min(self.n_components, Y.shape[0] - 1)).fit(Y - self.mu_)
            S = self.pca.transform(Y - self.mu_)
            self.models = [self._gp(d).fit(X, S[:, j]) for j in range(S.shape[1])]
        elif self.kind in ("et", "rf"):
            cls = ExtraTreesRegressor if self.kind == "et" else RandomForestRegressor
            self.m = cls(n_estimators=300, random_state=self.seed, n_jobs=1).fit(X, Y)
        elif self.kind == "krr":
            self.mu_, self.sd_ = Y.mean(0), Y.std(0) + 1e-9
            self.m = GridSearchCV(KernelRidge(kernel="rbf"), {"alpha": [1e-3, 1e-2, 1e-1], "gamma": [0.03, 0.1, 0.3, 1.0]},
                                  cv=KFold(5, shuffle=True, random_state=self.seed),
                                  scoring="neg_mean_absolute_error").fit(X, (Y - self.mu_) / self.sd_)
        else:
            raise ValueError(self.kind)
        return self

    def predict(self, frame, return_std=False):
        X = self._X(frame)
        if self.kind == "indep_gp":
            out = np.column_stack([m.predict(X) for m in self.models])
        elif self.kind == "shared_gp":
            out = self.m.predict(X)
        elif self.kind == "pca_gp":
            S = np.column_stack([m.predict(X) for m in self.models])
            out = self.pca.inverse_transform(S) + self.mu_
        elif self.kind in ("et", "rf"):
            out = self.m.predict(X)
        else:
            out = self.m.predict(X) * self.sd_ + self.mu_
        return (out, None) if return_std else out
