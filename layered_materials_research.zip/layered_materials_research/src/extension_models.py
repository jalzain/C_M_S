"""Extension models: additive composition+order GP, censored (zero-clamped) GP, cross-conformal wrapper,
and a two-task (intrinsic-coregionalisation) GP that uses the band gap as an auxiliary property.

All classes follow the ``fit(frame, y) / predict(frame, return_std)`` interface of improved_models.
The numpy GPs use an isotropic Matern-5/2 kernel on min-max scaled descriptors; hyper-parameters are
obtained by maximising the log marginal likelihood (L-BFGS-B, a few random restarts, fixed seed).
"""
from __future__ import annotations
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.model_selection import GroupKFold
from sklearn.gaussian_process import GaussianProcessRegressor
from data_preprocessing import build_features, load_dataset
from improved_models import canonical_orientation, make_kernel


def _m52(A, B, ell):
    d = np.sqrt(np.maximum(((A[:, None, :] - B[None, :, :]) ** 2).sum(-1), 0)) / ell
    s5 = np.sqrt(5.0) * d
    return (1 + s5 + 5.0 * d ** 2 / 3.0) * np.exp(-s5)


def _nlml_and_solve(K, y):
    try:
        c = cho_factor(K, lower=True)
    except Exception:
        return 1e10, None, None
    a = cho_solve(c, y)
    return 0.5 * y @ a + np.log(np.diag(c[0])).sum() + 0.5 * len(y) * np.log(2 * np.pi), c, a


def _optimise(fun, lo, hi, n_restarts, seed):
    rs = np.random.RandomState(seed)
    lo, hi = np.log(np.asarray(lo, float)), np.log(np.asarray(hi, float))
    best = None
    for r in range(n_restarts + 1):
        x0 = (lo + hi) / 2 if r == 0 else rs.uniform(lo, hi)
        res = minimize(fun, x0, method="L-BFGS-B", bounds=list(zip(lo, hi)))
        if best is None or res.fun < best.fun:
            best = res
    return best.x


# ----------------------------------------------------------------------------- additive GP
class AdditiveGP:
    """k = s1^2 M52(x_comp; l1) + s2^2 M52(x_pos; l2) + noise: composition kernel plus a stacking-order kernel."""
    calibrated_uncertainty = True

    def __init__(self, order="positional", n_restarts=3, seed=0, clip_min=None, name="GP-additive"):
        self.order, self.n_restarts, self.seed, self.clip_min, self.name = order, n_restarts, seed, clip_min, name

    def _feats(self, frame):
        f = canonical_orientation(frame)
        return build_features(frame, "composition"), build_features(f, self.order)

    def _K(self, th, A, B, same):
        s1, l1, s2, l2, sn = np.exp(th)
        K = s1 ** 2 * _m52(A[0], B[0], l1) + s2 ** 2 * _m52(A[1], B[1], l2)
        return K + (sn ** 2 * np.eye(len(A[0])) if same else 0)

    def fit(self, frame, y):
        self.X = self._feats(frame)
        y = np.asarray(y, float)
        self.mu_, self.sd_ = y.mean(), y.std() + 1e-12
        z = (y - self.mu_) / self.sd_
        f = lambda th: _nlml_and_solve(self._K(th, self.X, self.X, True), z)[0]
        self.th = _optimise(f, [1e-2, 1e-1, 1e-2, 1e-1, 1e-3], [1e1, 1e2, 1e1, 1e2, 1.0], self.n_restarts, self.seed)
        _, self.c, self.a = _nlml_and_solve(self._K(self.th, self.X, self.X, True), z)
        return self

    def predict(self, frame, return_std=False):
        Xs = self._feats(frame)
        Ks = self._K(self.th, Xs, self.X, False)
        mu = Ks @ self.a
        v = np.exp(self.th[0]) ** 2 + np.exp(self.th[2]) ** 2 + np.exp(self.th[4]) ** 2 - np.sum(Ks * cho_solve(self.c, Ks.T).T, 1)
        mu, sd = self.mu_ + self.sd_ * mu, self.sd_ * np.sqrt(np.maximum(v, 1e-12))
        if self.clip_min is not None:
            mu = np.maximum(mu, self.clip_min)
        return (mu, sd) if return_std else mu

    @property
    def scales(self):
        return np.exp(self.th)


# ----------------------------------------------------------------------------- censored GP
class CensoredGP:
    """GP for a target that is clamped at ``lower`` (zeros are censored values: true latent value <= lower).

    Approximate imputation scheme: censored targets are replaced by the conditional expectation of a
    left-truncated predictive normal given all other points (leave-one-out predictive of the current GP),
    and the GP is refitted; ``n_iter`` rounds.  Predictions are the mean and standard deviation of
    max(latent, lower).  This is an approximation of the Tobit-GP, not an exact likelihood treatment.
    """
    calibrated_uncertainty = True

    def __init__(self, kernel="matern15_ard", features="composition", n_iter=5, lower=0.0, n_restarts=2, seed=0,
                 name="GP-censored"):
        self.kernel, self.features, self.n_iter, self.lower = kernel, features, n_iter, lower
        self.n_restarts, self.seed, self.name = n_restarts, seed, name

    def fit(self, frame, y):
        X = build_features(frame, self.features)
        y = np.asarray(y, float)
        cens = y <= self.lower + 1e-9
        z = y.copy()
        self.n_cens_ = int(cens.sum())
        kern = make_kernel(self.kernel, X.shape[1], (1e-2, 1e2), True)
        gp = GaussianProcessRegressor(kern, n_restarts_optimizer=self.n_restarts, normalize_y=True, random_state=self.seed)
        gp.fit(X, z)
        for _ in range(self.n_iter if cens.any() else 0):
            K = gp.kernel_(X)
            Ki = np.linalg.inv(K)
            m_ = z.mean(); a = Ki @ (z - m_)
            loo_m = z - a / np.diag(Ki) ; loo_s = np.sqrt(1.0 / np.diag(Ki))
            # (sklearn's normalize_y rescales; the kernel is on the normalised scale, so rescale the LOO std)
            loo_s = loo_s * z.std()
            al = (self.lower - loo_m[cens]) / loo_s[cens]
            z[cens] = loo_m[cens] - loo_s[cens] * norm.pdf(al) / np.maximum(norm.cdf(al), 1e-12)
            gp = GaussianProcessRegressor(gp.kernel_, optimizer=None, normalize_y=True)
            gp.fit(X, z)
        self.gp, self.z_ = gp, z
        return self

    def predict(self, frame, return_std=False):
        mu, s = self.gp.predict(build_features(frame, self.features), return_std=True)
        s = np.maximum(s, 1e-9); a = mu / s
        # moments of max(N(mu, s^2), 0)
        m1 = mu * norm.cdf(a) + s * norm.pdf(a)
        m2 = (mu ** 2 + s ** 2) * norm.cdf(a) + mu * s * norm.pdf(a)
        sd = np.sqrt(np.maximum(m2 - m1 ** 2, 1e-12))
        return (m1, sd) if return_std else m1


# ----------------------------------------------------------------------------- conformal wrapper
class ConformalWrapper:
    """Cross-conformal (CV+-style, twin-aware inner folds) intervals around any model with predict(return_std).

    Scores are |y - mu| / sd (normalised) or |y - mu|.  ``half_width(frame, alpha)`` returns the interval half-width.
    """
    def __init__(self, factory, inner=5, normalised=True, name="conformal"):
        self.factory, self.inner, self.normalised, self.name = factory, inner, normalised, name

    def fit(self, frame, y):
        y = np.asarray(y, float)
        g = frame["canonical"].astype("category").cat.codes.values
        k = min(self.inner, len(set(g)))
        sc = []
        for tr, te in GroupKFold(k).split(frame, groups=g):
            m = self.factory().fit(frame.iloc[tr].reset_index(drop=True), y[tr])
            mu, sd = m.predict(frame.iloc[te].reset_index(drop=True), return_std=True)
            sc.append(np.abs(y[te] - mu) / (np.maximum(sd, 1e-9) if self.normalised else 1.0))
        self.scores_ = np.concatenate(sc)
        self.model = self.factory().fit(frame, y)
        return self

    def q(self, alpha):
        n = len(self.scores_)
        lvl = min(1.0, np.ceil((n + 1) * (1 - alpha)) / n)
        return float(np.quantile(self.scores_, lvl, method="higher"))

    def predict(self, frame, return_std=False):
        mu, sd = self.model.predict(frame, return_std=True)
        return (mu, sd) if return_std else mu

    def half_width(self, frame, alpha=0.05):
        _, sd = self.model.predict(frame, return_std=True)
        return self.q(alpha) * (np.maximum(sd, 1e-9) if self.normalised else 1.0)


# ----------------------------------------------------------------------------- two-task GP
class TwoTaskGP:
    """Intrinsic-coregionalisation GP: target task (EFF) plus auxiliary task (band gap, unique stacks).

    k((x,t),(x',t')) = B[t,t'] M52(x,x';l) + delta_{tt'} noise_t,  B = L L^T (2x2).  ``aux_scope``:
    'all' uses the auxiliary values of every stack in the band-gap data, 'train' only those of stacks present in
    the training frame, 'none' reduces to a single-task GP with the same kernel code.
    """
    calibrated_uncertainty = True

    def __init__(self, aux_scope="all", n_restarts=3, seed=0, name=None):
        self.aux_scope, self.n_restarts, self.seed = aux_scope, n_restarts, seed
        self.name = name or f"GP-2task[{aux_scope}]"
        bg = load_dataset("band_gap")
        fr = bg.frame.copy(); fr["gap"] = bg.y
        fr = fr.groupby("canonical", as_index=False).agg({**{c: "first" for c in ("M1", "X1", "M2", "X2", "M3", "X3", "structure")}, "gap": "mean"})
        self.aux_frame = canonical_orientation(fr).assign(canonical=fr["canonical"].values)

    def _X(self, frame):
        return build_features(frame, "composition")

    def _unpack(self, th):
        l, l11, l21, l22, s1, s2 = np.exp(th[0]), np.exp(th[1]), th[2], np.exp(th[3]), np.exp(th[4]), np.exp(th[5])
        L = np.array([[l11, 0.0], [l21, l22]])
        return l, L @ L.T, s1, s2

    def _K(self, th, X1, t1, X2, t2, same):
        l, B, s1, s2 = self._unpack(th)
        K = B[np.ix_(t1, t2)] * _m52(X1, X2, l)
        if same:
            K = K + np.diag(np.where(t1 == 0, s1 ** 2, s2 ** 2))
        return K

    def fit(self, frame, y):
        y = np.asarray(y, float)
        X = self._X(frame)
        t = np.zeros(len(y), int); yy = y.copy()
        if self.aux_scope != "none":
            aux = self.aux_frame
            if self.aux_scope == "train":
                aux = aux[aux["canonical"].isin(set(frame["canonical"]))]
            Xa = self._X(aux.reset_index(drop=True)); ya = aux["gap"].values
            X = np.vstack([X, Xa]); yy = np.concatenate([y, ya]); t = np.concatenate([t, np.ones(len(ya), int)])
        self.m_ = np.array([yy[t == 0].mean(), yy[t == 1].mean() if (t == 1).any() else 0.0])
        self.s_ = np.array([yy[t == 0].std() + 1e-12, yy[t == 1].std() + 1e-12 if (t == 1).any() else 1.0])
        z = (yy - self.m_[t]) / self.s_[t]
        self.X, self.t, self.z = X, t, z

        def f(th):
            return _nlml_and_solve(self._K(th, X, t, X, t, True), z)[0]
        rs = np.random.RandomState(self.seed)
        lo = np.log([1e-1, 1e-2, 1e-8, 1e-2, 1e-3, 1e-3]); hi = np.log([1e2, 1e1, 1e1, 1e1, 1.0, 1.0])
        lo[2], hi[2] = -3.0, 3.0   # l21 is not log-transformed
        best = None
        for r in range(self.n_restarts + 1):
            x0 = (lo + hi) / 2 if r == 0 else rs.uniform(lo, hi)
            if r == 0:
                x0[2] = 0.0
            res = minimize(f, x0, method="L-BFGS-B", bounds=list(zip(lo, hi)))
            best = res if best is None or res.fun < best.fun else best
        self.th = best.x
        _, self.c, self.a = _nlml_and_solve(self._K(self.th, X, t, X, t, True), z)
        return self

    def predict(self, frame, return_std=False):
        Xs = self._X(frame); ts = np.zeros(len(Xs), int)
        Ks = self._K(self.th, Xs, ts, self.X, self.t, False)
        l, B, s1, s2 = self._unpack(self.th)
        mu = Ks @ self.a
        v = B[0, 0] + s1 ** 2 - np.sum(Ks * cho_solve(self.c, Ks.T).T, 1)
        mu, sd = self.m_[0] + self.s_[0] * mu, self.s_[0] * np.sqrt(np.maximum(v, 1e-12))
        return (mu, sd) if return_std else mu

    @property
    def task_correlation(self):
        _, B, _, _ = self._unpack(self.th)
        return B[0, 1] / np.sqrt(B[0, 0] * B[1, 1])
