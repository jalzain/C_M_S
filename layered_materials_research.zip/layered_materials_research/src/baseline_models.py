"""Faithful re-implementations of the *original* surrogate models (settings copied from the scripts).

These classes reproduce the modelling choices of ``predict_maxval.py``, ``predict_structure.py`` and
``Bayesian_opt.py`` behind the same ``fit(frame, y) / predict(frame)`` interface used by the improved
models, so that baseline and improved methods are evaluated under one protocol.  The unmodified
original scripts are additionally executed by ``scripts/run_original_baseline.py``.

Original settings
-----------------
predict_maxval.py   : 12-D positional features (z-score), kernel C*Matern(nu=1.5, ARD)+White, 100 restarts,
                      normalize_y=False, random 60/40 split (no grouping)
predict_structure.py: 12-D positional features (min-max), C*Matern(nu=2.5, ARD)+White, 50 restarts,
                      one independent GP per band point (60 GPs)
Bayesian_opt.py     : 12-D positional features (min-max), C*Matern(nu=1.5, ARD) (no noise term), 40 restarts
"""
from __future__ import annotations
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel as C, Matern, WhiteKernel
from data_preprocessing import build_features

ORIGINAL_SETTINGS = {
    "maxval":    dict(features="positional_z", nu=1.5, white=True,  restarts=100),
    "structure": dict(features="positional",   nu=2.5, white=True,  restarts=50),
    "bo":        dict(features="positional",   nu=1.5, white=False, restarts=40),
}


def original_kernel(nu: float, white: bool, dim: int = 12):
    k = C(1.0, (1e-3, 1e3)) * Matern([1.0] * dim, [(1e-3, 1e3)] * dim, nu)
    return k + WhiteKernel(1.0, (1e-3, 1e3)) if white else k


class BaselineGP:
    """Original Gaussian-process surrogate (no target normalisation, no grouping, positional features)."""
    name = "GP-original"

    def __init__(self, variant: str = "maxval", n_restarts: int | None = None, seed: int = 0):
        s = ORIGINAL_SETTINGS[variant]
        self.variant, self.s, self.seed = variant, s, seed
        self.n_restarts = s["restarts"] if n_restarts is None else n_restarts

    def fit(self, frame, y):
        X = build_features(frame, self.s["features"])
        self.gp = GaussianProcessRegressor(original_kernel(self.s["nu"], self.s["white"]),
                                           n_restarts_optimizer=self.n_restarts, normalize_y=False,
                                           random_state=self.seed)
        self.gp.fit(X, np.asarray(y, float))
        return self

    def predict(self, frame, return_std=False):
        X = build_features(frame, self.s["features"])
        mu, sd = self.gp.predict(X, return_std=True)
        return (mu, sd) if return_std else mu
