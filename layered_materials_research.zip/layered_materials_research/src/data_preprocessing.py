"""Data loading, auditing and feature construction for the layered-TMDC datasets.

All four datasets describe tri-layer stacks ``M1 X1 M2 X2 M3 X3`` (M in {Mo, W}; X in {S, Se, Te}).
Original file formats (see baseline_original/README.md):

* 3-layer-band_gap.txt        : header (N) + ``M X M X M X gap_eV``
* 3-layer-band_structure.txt  : header (N) + ``M X M X M X`` + 30 CBM energies + 30 VBM energies (eV)
* N_doped_EFF_max.txt / P_doped_EFF_max.txt : *no header*, ``M X M X M X EFF_max`` (dimensionless
  figure of merit as defined by the original authors; units are not documented in the repository)
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "original"

METALS = ("Mo", "W")
CHALC = ("S", "Se", "Te")

# Per-element descriptors copied verbatim from the original scripts.
# Column 0: Pauling electronegativity; column 1: ionisation-potential-like quantity (kJ/mol scale).
# Column 2 is defined in predict_structure.py / Bayesian_opt.py but is *never used* there because
# totfea_atom = 2 truncates the feature vector (documented in the audit).  Its physical meaning
# is not stated in the repository, so it is exposed here under a neutral name.
ELEMENT_DESCRIPTORS = {
    "Mo": (2.16, 684.3, 190.0),
    "W": (2.36, 770.0, 193.0),
    "S": (2.58, 999.6, 88.8),
    "Se": (2.55, 941.0, 103.0),
    "Te": (2.10, 869.3, 123.0),
}
DESC_NAMES = ("electronegativity", "ionisation_potential", "undocumented_descriptor_3")


@dataclass
class Dataset:
    name: str
    frame: pd.DataFrame            # one row per structure: layers, structure, group ids, target(s)
    y: np.ndarray                  # (n,) or (n, 60) for band structure
    target_name: str
    units: str


# ----------------------------------------------------------------------------- parsing
def _split_structure(tokens):
    return list(tokens[:6])


def canonical_key(layers: list[str]) -> str:
    """Stack-reversal canonical form: a stack read bottom->top equals the reversed stack top->bottom."""
    pairs = [f"{layers[2*i]}{layers[2*i+1]}" for i in range(3)]
    return "-".join(min(pairs, pairs[::-1]))


def composition_key(layers: list[str]) -> str:
    """Order-independent composition (multiset of constituent TMD layers)."""
    pairs = sorted(f"{layers[2*i]}{layers[2*i+1]}" for i in range(3))
    return "-".join(pairs)


def _read_lines(path: Path):
    lines = [l.split() for l in path.read_text().splitlines() if l.strip()]
    declared = None
    if len(lines[0]) == 1:  # header with the number of records
        declared = int(lines[0][0])
        lines = lines[1:]
    return declared, lines


def _base_frame(rows):
    recs = []
    for r in rows:
        L = _split_structure(r)
        pairs = [f"{L[2*i]}{L[2*i+1]}" for i in range(3)]
        recs.append(dict(
            structure="-".join(pairs),
            M1=L[0], X1=L[1], M2=L[2], X2=L[3], M3=L[4], X3=L[5],
            canonical=canonical_key(L), composition=composition_key(L),
            palindromic=(pairs == pairs[::-1]),
            n_distinct_layers=len(set(pairs)),
            has_Te=any(x == "Te" for x in L[1::2]),
            has_W=any(m == "W" for m in L[0::2]),
        ))
    return pd.DataFrame(recs)


def load_dataset(name: str, data_dir: Path = DATA_DIR) -> Dataset:
    if name == "band_gap":
        _, rows = _read_lines(data_dir / "3-layer-band_gap.txt")
        df = _base_frame(rows)
        y = np.array([float(r[6]) for r in rows])
        df["target"] = y
        return Dataset(name, df, y, "band_gap", "eV")
    if name == "band_structure":
        _, rows = _read_lines(data_dir / "3-layer-band_structure.txt")
        df = _base_frame(rows)
        Y = np.array([[float(v) for v in r[6:66]] for r in rows])
        return Dataset(name, df, Y, "CBM_VBM_curves", "eV")
    if name in ("eff_n", "eff_p"):
        fn = "N_doped_EFF_max.txt" if name == "eff_n" else "P_doped_EFF_max.txt"
        _, rows = _read_lines(data_dir / fn)
        df = _base_frame(rows)
        y = np.array([float(r[6]) for r in rows])
        df["target"] = y
        return Dataset(name, df, y, "EFF_max", "dimensionless (units not documented)")
    raise ValueError(name)


def assign_groups(ds: Dataset, kind: str = "canonical") -> np.ndarray:
    """Integer group labels used by grouped cross-validation (prevents leakage between twins)."""
    col = {"canonical": "canonical", "composition": "composition"}[kind]
    return pd.factorize(ds.frame[col])[0]


# ----------------------------------------------------------------------------- features
def _norm_table(kind: str, ncols: int):
    arr = np.array([ELEMENT_DESCRIPTORS[k][:ncols] for k in ELEMENT_DESCRIPTORS], float)
    if kind == "minmax":
        lo, hi = arr.min(0), arr.max(0)
        return {k: (np.array(ELEMENT_DESCRIPTORS[k][:ncols]) - lo) / (hi - lo) for k in ELEMENT_DESCRIPTORS}
    if kind == "zscore":
        mu, sd = arr.mean(0), arr.std(0)
        return {k: (np.array(ELEMENT_DESCRIPTORS[k][:ncols]) - mu) / sd for k in ELEMENT_DESCRIPTORS}
    raise ValueError(kind)


def positional_features(frame: pd.DataFrame, norm: str = "minmax", ncols: int = 2) -> np.ndarray:
    """Original representation: 6 atoms x ``ncols`` descriptors, in stacking order (12-D for ncols=2)."""
    tab = _norm_table(norm, ncols)
    cols = ["M1", "X1", "M2", "X2", "M3", "X3"]
    return np.array([np.concatenate([tab[row[c]] for c in cols]) for _, row in frame.iterrows()])


def reverse_stack_frame(frame: pd.DataFrame) -> pd.DataFrame:
    f = frame.copy()
    f[["M1", "X1", "M2", "X2", "M3", "X3"]] = frame[["M3", "X3", "M2", "X2", "M1", "X1"]].values
    return f


def layer_features(frame: pd.DataFrame, norm: str = "minmax", ncols: int = 2) -> np.ndarray:
    """Per-layer (metal,chalcogen) descriptors: identical to positional layout (kept for clarity)."""
    return positional_features(frame, norm, ncols)


def composition_features(frame: pd.DataFrame, norm: str = "minmax", ncols: int = 2) -> np.ndarray:
    """Permutation-invariant composition descriptors of the whole stack.

    mean and spread (max-min) of each normalised descriptor over metals and over chalcogens,
    plus the metal W fraction and chalcogen S/Se/Te fractions (10-ish dims, order independent).
    """
    tab = _norm_table(norm, ncols)
    out = []
    for _, r in frame.iterrows():
        mets = np.array([tab[r[c]] for c in ("M1", "M2", "M3")])
        chs = np.array([tab[r[c]] for c in ("X1", "X2", "X3")])
        fr = [np.mean([r[c] == "W" for c in ("M1", "M2", "M3")])]
        fr += [np.mean([r[c] == x for c in ("X1", "X2", "X3")]) for x in ("S", "Se")]
        out.append(np.concatenate([mets.mean(0), mets.max(0) - mets.min(0),
                                   chs.mean(0), chs.max(0) - chs.min(0), fr]))
    return np.array(out)


def symmetric_features(frame: pd.DataFrame, norm: str = "minmax", ncols: int = 2) -> np.ndarray:
    """Exactly stack-reversal-invariant, order-aware representation.

    [descriptors of the central layer (M2,X2)] + [mean of the two outer layers] + [|difference| of the outer
    layers], each with the (metal, chalcogen) normalised descriptors -> 3 x 2 x ncols dimensions (12-D for
    ncols=2, i.e. the same dimensionality as the original positional vector).
    """
    tab = _norm_table(norm, ncols)
    out = []
    for _, r in frame.iterrows():
        l1 = np.concatenate([tab[r["M1"]], tab[r["X1"]]])
        l2 = np.concatenate([tab[r["M2"]], tab[r["X2"]]])
        l3 = np.concatenate([tab[r["M3"]], tab[r["X3"]]])
        out.append(np.concatenate([l2, 0.5 * (l1 + l3), np.abs(l1 - l3)]))
    return np.array(out)


def hybrid_features(frame, norm="minmax", ncols=2):
    return np.hstack([positional_features(frame, norm, ncols), composition_features(frame, norm, ncols)])


def build_features(frame: pd.DataFrame, kind: str = "positional") -> np.ndarray:
    if kind == "positional":          # original baseline for BO / structure scripts
        return positional_features(frame, "minmax", 2)
    if kind == "positional_z":        # original baseline for predict_maxval.py
        return positional_features(frame, "zscore", 2)
    if kind == "composition":
        return composition_features(frame)
    if kind == "symmetric":
        return symmetric_features(frame)
    if kind == "symmetric_comp":
        return np.hstack([symmetric_features(frame), composition_features(frame)])
    if kind == "hybrid":
        return hybrid_features(frame)
    if kind == "positional3":
        return positional_features(frame, "minmax", 3)
    raise ValueError(kind)


# ----------------------------------------------------------------------------- audit
def audit_all() -> pd.DataFrame:
    rows = []
    for name in ("band_gap", "band_structure", "eff_n", "eff_p"):
        ds = load_dataset(name)
        f = ds.frame
        rec = dict(dataset=name, n_records=len(f), n_unique_structures=f["structure"].nunique(),
                   n_unique_under_reversal=f["canonical"].nunique(),
                   n_records_with_reversed_twin=int(f.groupby("canonical")["structure"].transform("size").gt(1).sum()),
                   n_palindromic=int(f["palindromic"].sum()),
                   n_unique_compositions=f["composition"].nunique())
        if ds.y.ndim == 1:
            y = ds.y
            q1, q3 = np.percentile(y, [25, 75])
            rec.update(y_min=y.min(), y_median=float(np.median(y)), y_mean=y.mean(), y_max=y.max(), y_std=y.std(),
                       n_nan=int(np.isnan(y).sum()), n_zero=int((y == 0).sum()),
                       n_outliers_3IQR=int((y > q3 + 3 * (q3 - q1)).sum()),
                       skewness=float(pd.Series(y).skew()))
        else:
            rec.update(y_min=ds.y.min(), y_max=ds.y.max(), n_nan=int(np.isnan(ds.y).sum()))
        rows.append(rec)
    return pd.DataFrame(rows)


def twin_consistency() -> pd.DataFrame:
    """Band-gap difference between stack-reversed twins (same physical structure up to orientation)."""
    ds = load_dataset("band_gap")
    f = ds.frame
    rows = []
    for key, g in f.groupby("canonical"):
        if len(g) == 2:
            a, b = g["target"].values
            rows.append(dict(canonical=key, s1=g.iloc[0]["structure"], s2=g.iloc[1]["structure"], gap1=a, gap2=b, abs_diff=abs(a - b)))
    return pd.DataFrame(rows)


def bandstructure_gap_consistency() -> pd.DataFrame:
    """Compare gap = min(CBM) - max(VBM) from the curves against the band-gap file."""
    bs, bg = load_dataset("band_structure"), load_dataset("band_gap")
    gap_map = dict(zip(bg.frame["structure"], bg.y))
    rows = []
    for i, s in enumerate(bs.frame["structure"]):
        cbm, vbm = bs.y[i, :30], bs.y[i, 30:]
        d = cbm.min() - vbm.max()
        rows.append(dict(structure=s, gap_from_curves=d, gap_file=gap_map.get(s, np.nan), vbm_max=vbm.max()))
    out = pd.DataFrame(rows)
    out["abs_diff"] = (out["gap_from_curves"] - out["gap_file"]).abs()
    return out


def overlap_between_datasets() -> pd.DataFrame:
    names = ["band_gap", "band_structure", "eff_n", "eff_p"]
    sets = {n: set(load_dataset(n).frame["canonical"]) for n in names}
    return pd.DataFrame([[len(sets[a] & sets[b]) for b in names] for a in names], index=names, columns=names)


if __name__ == "__main__":
    pd.set_option("display.width", 200)
    print(audit_all().T)
    t = twin_consistency(); print(len(t), t["abs_diff"].describe())
    c = bandstructure_gap_consistency(); print(c["abs_diff"].describe(), c["vbm_max"].describe())
    print(overlap_between_datasets())
