"""Shared figure style and helpers (Matplotlib; light surface, print-safe, colour+marker redundancy)."""
from __future__ import annotations
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FIG_PNG = ROOT / "figures" / "png"
FIG_PDF = ROOT / "figures" / "pdf"
MS_FIG = ROOT / "manuscript" / "figures"
FIG_DATA = ROOT / "figures" / "data"

# categorical slots (validated reference palette, fixed order) and role colours
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                                                              "#e87ba4", "#008300", "#6250d6", "#e34948")
GREY = "#7a7975"
INK, INK2 = "#0b0b0b", "#52514e"

DATASET_LABEL = {"band_gap": "Band gap (eV)", "eff_p": "P-doped EFF$_{max}$", "eff_n": "N-doped EFF$_{max}$ (outliers removed)",
                 "eff_n_full": "N-doped EFF$_{max}$ (all 116)"}
DATASET_SHORT = {"band_gap": "Band gap", "eff_p": "P-doped EFF", "eff_n": "N-doped EFF", "eff_n_full": "N-doped EFF (full)"}

ROLE = {   # model -> (colour, marker)
    "GP-original": (ORANGE, "o"), "GP-comp-ARD-M15": (BLUE, "s"), "GP-comp-ARD-M25": (BLUE, "D"),
    "GP-comp-ARD-RBF": (VIOLET, "^"), "GP-comp-iso-M25": (AQUA, "v"), "GP-comp-iso-RBF": (MAGENTA, "P"),
    "GP-comp-iso-RQ": (YELLOW, "X"), "GP-sym-ARD-M25": (GREEN, "<"), "GP-pos-ARD-M25": (RED, ">"),
    "RF-comp": (AQUA, "h"), "ET-comp": (GREEN, "p"), "RF-pos": (GREY, "h"), "ET-pos": (GREY, "p"),
    "GBR-comp": (VIOLET, "*"), "SVR-comp": (MAGENTA, "d"), "KRR-comp": (YELLOW, "8"), "kNN-comp": (GREY, "1"),
    "Ridge-comp": (GREY, "2"), "Mean-predictor": ("#b9b8b2", "_"), "GP-comp-ARD-M15-log10": (BLUE, "o"),
}


def style():
    plt.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 300, "font.family": "DejaVu Sans", "font.size": 9,
        "axes.titlesize": 10, "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": INK2, "axes.labelcolor": INK,
        "text.color": INK, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": "#e4e3de",
        "grid.linewidth": 0.6, "axes.axisbelow": True, "lines.linewidth": 1.6, "legend.frameon": False,
        "pdf.fonttype": 42, "ps.fonttype": 42, "figure.facecolor": "white", "axes.facecolor": "white",
    })


def save(fig, name: str):
    for d in (FIG_PNG, FIG_PDF, MS_FIG):
        d.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_PNG / f"{name}.png", bbox_inches="tight")
    fig.savefig(FIG_PDF / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(MS_FIG / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)


def export(name: str, df):
    """Write the exact numbers behind a quantitative figure to figures/data/<name>.csv."""
    FIG_DATA.mkdir(parents=True, exist_ok=True)
    df.to_csv(FIG_DATA / f"{name}.csv", index=False)


def panel_label(ax, s):
    ax.text(-0.02, 1.06, s, transform=ax.transAxes, fontsize=11, fontweight="bold", va="bottom", ha="right")


def mean_ci(x, n_boot=2000, seed=0):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return (x.mean() if len(x) else np.nan,) * 3
    rs = np.random.RandomState(seed)
    bs = np.array([x[rs.randint(len(x), size=len(x))].mean() for _ in range(n_boot)])
    return x.mean(), *np.quantile(bs, [0.025, 0.975])
