"""Statistical comparison utilities (paired tests, bootstrap CIs, multiple-comparison correction)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats


def bootstrap_ci(x, stat=np.mean, n_boot=5000, alpha=0.05, seed=0):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return (np.nan, np.nan)
    rs = np.random.RandomState(seed)
    bs = np.array([stat(x[rs.randint(len(x), size=len(x))]) for _ in range(n_boot)])
    return tuple(np.quantile(bs, [alpha / 2, 1 - alpha / 2]))


def wilson_interval(k, n, z=1.959964):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (c - h, c + h)


def holm_correction(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def corrected_resampled_ttest(diff, n_train, n_test):
    """Nadeau & Bengio (2003) corrected t-test for differences from repeated CV (variance inflation)."""
    d = np.asarray(diff, float)
    k = len(d)
    if k < 3 or np.std(d, ddof=1) == 0:
        return np.nan, np.nan
    var = np.var(d, ddof=1) * (1.0 / k + n_test / n_train)
    t = np.mean(d) / np.sqrt(var)
    p = 2 * stats.t.sf(abs(t), df=k - 1)
    return t, p


def paired_model_comparison(folds: pd.DataFrame, reference: str, metric="MAE", group_cols=("dataset", "scheme"),
                            key_cols=("repeat", "fold")) -> pd.DataFrame:
    """Compare every model with ``reference`` on identical folds.

    Reports mean paired difference (model - reference; negative = model better for error metrics), bootstrap
    95% CI, Wilcoxon signed-rank p (Holm-adjusted within each group) and Nadeau-Bengio corrected t-test p.
    """
    rows = []
    for gkey, G in folds.groupby(list(group_cols)):
        ref = G[G.model == reference].set_index(list(key_cols))[metric]
        pvals, tmp = [], []
        for m, M in G.groupby("model"):
            if m == reference:
                continue
            cur = M.set_index(list(key_cols))[metric]
            idx = ref.index.intersection(cur.index)
            if len(idx) < 3:
                continue
            d = (cur.loc[idx] - ref.loc[idx]).values
            try:
                w = stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0
            except ValueError:
                w = np.nan
            ntr = M["n_train"].mean(); nte = M["n_test"].mean()
            t, pt = corrected_resampled_ttest(d, ntr, nte)
            lo, hi = bootstrap_ci(d)
            tmp.append(dict(zip(group_cols, gkey if isinstance(gkey, tuple) else (gkey,)),
                            model=m, reference=reference, metric=metric, n_pairs=len(d),
                            mean_ref=ref.loc[idx].mean(), mean_model=cur.loc[idx].mean(),
                            mean_diff=d.mean(), ci95_lo=lo, ci95_hi=hi,
                            rel_change_pct=100 * d.mean() / max(ref.loc[idx].mean(), 1e-12),
                            p_wilcoxon=w, p_corrected_t=pt))
            pvals.append(w)
        if tmp:
            adj = holm_correction(np.nan_to_num(pvals, nan=1.0))
            for r, a in zip(tmp, adj):
                r["p_wilcoxon_holm"] = a
            rows.extend(tmp)
    return pd.DataFrame(rows)


def friedman_ranks(folds: pd.DataFrame, metric="MAE", group_cols=("dataset", "scheme"), key_cols=("repeat", "fold")):
    """Average rank of each model (1 = best) and Friedman chi-square p-value, per group."""
    rows = []
    for gkey, G in folds.groupby(list(group_cols)):
        W = G.pivot_table(index=list(key_cols), columns="model", values=metric).dropna()
        if W.shape[1] < 3 or W.shape[0] < 3:
            continue
        chi, p = stats.friedmanchisquare(*[W[c].values for c in W.columns])
        ranks = W.rank(axis=1).mean()
        for m, r in ranks.items():
            rows.append(dict(zip(group_cols, gkey if isinstance(gkey, tuple) else (gkey,)), model=m,
                             mean_rank=r, friedman_chi2=chi, friedman_p=p, n_blocks=W.shape[0]))
    return pd.DataFrame(rows)


def summarise_folds(folds: pd.DataFrame, metrics=("MAE", "RMSE", "R2"), group_cols=("dataset", "scheme", "model")):
    rows = []
    for gkey, G in folds.groupby(list(group_cols)):
        rec = dict(zip(group_cols, gkey))
        for m in metrics:
            if m in G:
                v = G[m].dropna().values
                lo, hi = bootstrap_ci(v)
                rec[f"{m}_mean"], rec[f"{m}_std"], rec[f"{m}_ci_lo"], rec[f"{m}_ci_hi"] = v.mean(), v.std(ddof=1) if len(v) > 1 else np.nan, lo, hi
        for extra in ("NLL", "coverage95", "sigma_err_spearman", "fit_time_s", "spearman"):
            if extra in G and G[extra].notna().any():
                rec[f"{extra}_mean"] = G[extra].mean()
        rec["n_folds"] = len(G)
        rows.append(rec)
    return pd.DataFrame(rows)
