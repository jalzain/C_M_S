"""Pool-based Bayesian optimisation over a finite set of candidate layered structures.

The material space is a finite pool (all structures in a dataset).  An "evaluation" reveals the stored
target value of one pool member (a stand-in for an expensive first-principles calculation).  Starting from a
random initial design, a GP surrogate is refit after each evaluation and an acquisition function selects the
next structure.  Everything is paired across methods: for a given seed all methods start from the same
initial design.

Methods (``method`` argument of :func:`run_bo`)
  orig_ei   : logic of the original Bayesian_opt.py (see below), optionally with reduced restarts
  ei, pi, ucb, greedy, ts : improved-surrogate GP with the named acquisition
  orig_ei_impgp : original acquisition logic evaluated on the improved surrogate (isolates acquisition vs surrogate)
  random    : uniform random search without replacement

Original logic reproduced by ``orig_ei`` (all deviations from textbook EI are intentional replicas):
  * surrogate  : C*Matern(nu=1.5, ARD), NO noise term, normalize_y=False, raw objective, n_restarts=40
  * incumbent  : ybest = max of the GP *predictions at the training points* (not the best observed value)
  * improvement: EI = (mu-ybest-eps)*Phi(z) + sigma*phi(z) with z=(mu-ybest)/sigma  (eps not inside z)
  * eps        : 0.1 for iterations 0..15, 0.01 afterwards
  * reporting  : the "best structure so far" value is updated from the *predicted* ybest, i.e. the reported
                 optimum can be a surrogate prediction rather than an evaluated value.  We therefore record
                 both the evaluated best and the originally reported best.
"""
from __future__ import annotations
import time, warnings
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel as C, Matern, RBF, WhiteKernel

warnings.filterwarnings("ignore")


# ----------------------------------------------------------------------------- surrogates
class GPSurrogate:
    """Thin GP wrapper with warm-started hyper-parameters (improved) or original settings."""

    def __init__(self, kind="improved", nu=2.5, restarts=1, seed=0, white=True, normalize_y=True,
                 bounds=(1e-2, 1e2), ard=True):
        self.kind, self.nu, self.restarts, self.seed, self.ard = kind, nu, restarts, seed, ard
        self.white, self.normalize_y, self.bounds = white, normalize_y, bounds
        self.theta_ = None
        self.fit_time_total = 0.0

    def _kernel(self, d):
        if self.kind == "orig":
            k = C(1.0, (1e-3, 1e3)) * Matern([1.0] * d, [(1e-3, 1e3)] * d, 1.5)
            return k
        ls, lb = ([1.0] * d, [self.bounds] * d) if self.ard else (1.0, self.bounds)
        return C(1.0, (1e-2, 1e2)) * Matern(ls, lb, self.nu) + WhiteKernel(1e-2, (1e-6, 1.0))

    def fit(self, X, y):
        t = time.perf_counter()
        k = self._kernel(X.shape[1])
        if self.theta_ is not None and self.kind != "orig":
            k = k.clone_with_theta(self.theta_)
        self.gp = GaussianProcessRegressor(k, n_restarts_optimizer=self.restarts, normalize_y=self.normalize_y,
                                           random_state=self.seed)
        self.gp.fit(X, y)
        if self.kind != "orig":
            self.theta_ = self.gp.kernel_.theta
        self.fit_time_total += time.perf_counter() - t
        return self

    def predict(self, X):
        mu, sd = self.gp.predict(X, return_std=True)
        return mu, np.maximum(sd, 1e-12)

    def sample(self, X, rng):
        """Joint posterior sample over the pool (eigen-decomposition; robust to near-singular covariance)."""
        mu, cov = self.gp.predict(X, return_cov=True)
        mu = np.ravel(mu)
        cov = np.nan_to_num(0.5 * (cov + cov.T))
        w, v = np.linalg.eigh(cov)
        return mu + v @ (np.sqrt(np.clip(w, 0.0, None)) * rng.standard_normal(len(mu)))


# ----------------------------------------------------------------------------- acquisition functions
def expected_improvement(mu, sd, best, xi=0.0):
    z = (mu - best - xi) / sd
    return (mu - best - xi) * norm.cdf(z) + sd * norm.pdf(z)


def probability_of_improvement(mu, sd, best, xi=0.0):
    return norm.cdf((mu - best - xi) / sd)


def upper_confidence_bound(mu, sd, beta=2.0):
    return mu + beta * sd


def original_ei(mu, sd, ybest, eps):
    """Expression used in the original script (itag = +1)."""
    z = (mu - ybest) / sd
    return (mu - ybest - eps) * norm.cdf(z) + sd * norm.pdf(z)


# ----------------------------------------------------------------------------- main loop
def run_bo(X, y, names, method, n_init, n_iter, seed, y_transform="identity", xi_frac=0.01, beta=2.0,
           restarts=1, orig_restarts=40, nu=2.5, ard=True):
    """Run one BO campaign.  Returns a history DataFrame (one row per evaluated structure).

    ``X``: (N, d) candidate features, ``y``: (N,) objective to maximise (raw units).
    The surrogate is fit on ``y_transform(y)`` (log10 for heavy-tailed EFF); all reported values are raw.
    """
    N = len(y)
    z = np.log10(y) if y_transform == "log10" else np.asarray(y, float)
    rng = np.random.RandomState(seed)
    perm = rng.permutation(N)                      # identical initial design for every method (same seed)
    train = list(perm[:n_init])
    remain = list(perm[n_init:])
    ts_rng = np.random.RandomState(seed + 12345)
    rnd_rng = np.random.RandomState(seed + 999)
    # "orig_ei": original logic + original surrogate; "orig_ei_impgp": original acquisition logic on the improved GP
    orig_logic = method in ("orig_ei", "orig_ei_impgp")
    sur = GPSurrogate("orig" if method == "orig_ei" else "improved", nu=nu,
                      restarts=orig_restarts if method == "orig_ei" else restarts, seed=seed, ard=ard)
    rows = []
    best_obs = np.max(y[train])
    reported = best_obs
    for i in train:                                 # log the initial design
        rows.append(dict(step=0, idx=i, structure=names[i], y=y[i], phase="init"))
    t_start = time.perf_counter()
    for it in range(n_iter):
        if method == "random":
            j = rnd_rng.randint(len(remain))
            nxt = remain[j]
        else:
            Xt, zt = X[train], z[train]
            sur.fit(Xt, zt)
            Xr = X[remain]
            mu, sd = sur.predict(Xr)
            if orig_logic:
                mu_tr, _ = sur.predict(Xt)
                ybest = mu_tr.max()
                eps = 0.1 if it <= int(0.5 * n_iter) else 0.01
                reported = max(reported, ybest)     # replicates reporting from predicted values
                a = original_ei(mu, sd, ybest, eps)
            else:
                zbest = zt.max()
                scale = np.std(zt) if np.std(zt) > 0 else 1.0
                if method == "ei":
                    a = expected_improvement(mu, sd, zbest, xi_frac * scale)
                elif method == "pi":
                    a = probability_of_improvement(mu, sd, zbest, xi_frac * scale)
                elif method == "ucb":
                    a = upper_confidence_bound(mu, sd, beta)
                elif method == "greedy":
                    a = mu
                elif method == "ts":
                    a = sur.sample(Xr, ts_rng)
                else:
                    raise ValueError(method)
            # tie-break deterministically (first max); for flat EI fall back to highest sigma
            if np.allclose(a, a[0]) and method in ("ei", "pi"):
                a = sd
            j = int(np.argmax(a))
            nxt = remain[j]
        train.append(nxt)
        remain.pop(j)
        best_obs = max(best_obs, y[nxt])
        reported = max(reported, y[nxt])
        rows.append(dict(step=it + 1, idx=nxt, structure=names[nxt], y=y[nxt], phase="bo"))
    H = pd.DataFrame(rows)
    H["n_evaluated"] = np.arange(1, len(H) + 1)
    H["best_so_far"] = np.maximum.accumulate(H["y"].values)
    H["method"] = method
    H["seed"] = seed
    H["runtime_s"] = time.perf_counter() - t_start
    H["surrogate_fit_s"] = sur.fit_time_total
    if orig_logic:
        H.attrs["reported_best_original"] = reported
    return H


def summarise_history(H: pd.DataFrame, y_all: np.ndarray, top_fracs=(0.05,)) -> dict:
    """Run-level metrics: final best, rank of the best (1 = global optimum), evaluations to reach targets."""
    N = len(y_all)
    order = np.sort(y_all)[::-1]
    ymax = order[0]
    final = H["best_so_far"].iloc[-1]
    rank = int(np.sum(y_all > final + 1e-12)) + 1
    out = dict(method=H["method"].iloc[0], seed=H["seed"].iloc[0], n_evaluated=len(H), N_pool=N,
               final_best=final, final_rank=rank, found_global=bool(rank == 1),
               regret_log10=float(np.log10(ymax) - np.log10(max(final, 1e-12))) if ymax > 0 and final > 0 else np.nan,
               normalised_regret=float((ymax - final) / (ymax - np.min(y_all) + 1e-12)),
               runtime_s=H["runtime_s"].iloc[0], surrogate_fit_s=H["surrogate_fit_s"].iloc[0])
    cur = H["best_so_far"].values
    n_init = int((H["phase"] == "init").sum())
    out["n_init"] = n_init
    out["evals_to_global"] = int(np.argmax(cur >= ymax - 1e-12) + 1) if np.any(cur >= ymax - 1e-12) else np.nan
    out["extra_evals_to_global"] = out["evals_to_global"] - n_init if np.isfinite(out["evals_to_global"]) else np.nan
    for f in top_fracs:
        k = max(1, int(np.ceil(f * N)))
        thr = order[k - 1]
        hit = cur >= thr - 1e-12
        out[f"evals_to_top{int(f*100)}pct"] = int(np.argmax(hit) + 1) if hit.any() else np.nan
        out[f"hit_top{int(f*100)}pct"] = bool(hit.any())
    if "reported_best_original" in H.attrs:
        out["reported_best_original"] = H.attrs["reported_best_original"]
        out["reported_minus_evaluated"] = H.attrs["reported_best_original"] - final
    return out
